import * as mc from "@minecraft/server";
import * as general from "./modules/general.js";

mc.system.runInterval(() => {
  for (const player of mc.world.getPlayers()) {
    if (player.hasTag("finish_mission")) {
      const
        aaa = player.hasTag("bandit_mission") ? "bandit" : player.hasTag("dabi_mission") ? "dabi" : player.hasTag("overhaul_mission") ? "overhaul" : player.hasTag("shigaraki_mission") ? "shigaraki" : player.hasTag("police_mission") ? "police" : player.hasTag("shoto_mission") ? "shoto" : player.hasTag("bakugo_mission") ? "bakugo" : player.hasTag("deku_dark_mission") ? "deku_dark" : player.hasTag("all_might_mission") ? "all_might" : "";
      switch (aaa) {
        case 'bandit':
          player.removeTag(`bandit_mission`);
          player.removeTag(`finish_mission`);
          player.runCommandAsync(`give @s wesl3y:money 3 0`);
          player.runCommandAsync(`tellraw @s {"rawtext":[{"text":"§a"},{"translate":"text.finish_mission"},{"text":"\n+$20 Money"},{"text":"\n+$1 Point"}]}`);
          player.runCommandAsync(`scoreboard players add @s points 1`);
          player.runCommandAsync(`scoreboard players reset @s missions`);
        break;
        case 'dabi':
          player.removeTag(`dabi_mission`);
          player.removeTag(`finish_mission`);
          player.runCommandAsync(`give @s wesl3y:money 10 0`);
          player.runCommandAsync(`tellraw @s {"rawtext":[{"text":"§a"},{"translate":"text.finish_mission"},{"text":"\n+$10 Money"},{"text":"\n+$1 Point"}]}`);
          player.runCommandAsync(`scoreboard players add @s points 1`);
          player.runCommandAsync(`scoreboard players reset @s missions`);
        break;
        case 'overhaul':
          player.removeTag(`overhaul_mission`);
          player.removeTag(`finish_mission`);
          player.runCommandAsync(`give @s wesl3y:money 20 0`);
          player.runCommandAsync(`tellraw @s {"rawtext":[{"text":"§a"},{"translate":"text.finish_mission"},{"text":"\n+$20 Money"},{"text":"\n+$1 Point"}]}`);
          player.runCommandAsync(`scoreboard players add @s points 1`);
          player.runCommandAsync(`scoreboard players reset @s missions`);
        break;
        case 'shigaraki':
          player.removeTag(`shigaraki_mission`);
          player.removeTag(`finish_mission`);
          player.runCommandAsync(`give @s wesl3y:money 25 0`);
          player.runCommandAsync(`tellraw @s {"rawtext":[{"text":"§a"},{"translate":"text.finish_mission"},{"text":"\n+$25 Money"},{"text":"\n+$1 Point"}]}`);
          player.runCommandAsync(`scoreboard players add @s points 1`);
          player.runCommandAsync(`scoreboard players reset @s missions`);
        break;
        case 'nomu':
          player.removeTag(`nomu_mission`);
          player.removeTag(`finish_mission`);
          player.runCommandAsync(`give @s wesl3y:money 30 0`);
          player.runCommandAsync(`tellraw @s {"rawtext":[{"text":"§a"},{"translate":"text.finish_mission"},{"text":"\n+$30 Money"},{"text":"\n+$2 Point"}]}`);
          player.runCommandAsync(`scoreboard players add @s points 2`);
          player.runCommandAsync(`scoreboard players reset @s missions`);
        break;
        case 'police':
          player.removeTag(`police_mission`);
          player.removeTag(`finish_mission`);
          player.runCommandAsync(`give @s wesl3y:money 6 0`);
          player.runCommandAsync(`tellraw @s {"rawtext":[{"text":"§a"},{"translate":"text.finish_mission"},{"text":"\n+$6 Money"},{"text":"\n+$1 Point"}]}`);
          player.runCommandAsync(`scoreboard players add @s points 1`);
          player.runCommandAsync(`scoreboard players reset @s missions`);
        break;
        case 'shoto':
          player.removeTag(`shoto_mission`);
          player.removeTag(`finish_mission`);
          player.runCommandAsync(`give @s wesl3y:money 10 0`);
          player.runCommandAsync(`tellraw @s {"rawtext":[{"text":"§a"},{"translate":"text.finish_mission"},{"text":"\n+$10 Money"},{"text":"\n+$1 Point"}]}`);
          player.runCommandAsync(`scoreboard players add @s points 1`);
          player.runCommandAsync(`scoreboard players reset @s missions`);
        break;
        case 'bakugo':
          player.removeTag(`bakugo_mission`);
          player.removeTag(`finish_mission`);
          player.runCommandAsync(`give @s wesl3y:money 15 0`);
          player.runCommandAsync(`tellraw @s {"rawtext":[{"text":"§a"},{"translate":"text.finish_mission"},{"text":"\n+$15 Money"},{"text":"\n+$1 Point"}]}`);
          player.runCommandAsync(`scoreboard players add @s points 1`);
          player.runCommandAsync(`scoreboard players reset @s missions`);
        break;
        case 'deku_dark':
          player.removeTag(`deku_dark_mission`);
          player.removeTag(`finish_mission`);
          player.runCommandAsync(`give @s wesl3y:money 20 0`);
          player.runCommandAsync(`tellraw @s {"rawtext":[{"text":"§a"},{"translate":"text.finish_mission"},{"text":"\n+$20 Money"},{"text":"\n+$1 Point"}]}`);
          player.runCommandAsync(`scoreboard players add @s points 1`);
          player.runCommandAsync(`scoreboard players reset @s missions`);
        break;
        case 'all_might':
          player.removeTag(`all_might_mission`);
          player.removeTag(`finish_mission`);
          player.runCommandAsync(`give @s wesl3y:money 40 0`);
          player.runCommandAsync(`tellraw @s {"rawtext":[{"text":"§a"},{"translate":"text.finish_mission"},{"text":"\n+$40 Money"},{"text":"\n+$2 Point"}]}`);
          player.runCommandAsync(`scoreboard players add @s points 2`);
          player.runCommandAsync(`scoreboard players reset @s missions`);
        break;
        case '':
          player.removeTag(`finish_mission`);
          player.runCommandAsync(`scoreboard players reset @s missions`);
        break;
      }
    }
  }
}, 0.5);