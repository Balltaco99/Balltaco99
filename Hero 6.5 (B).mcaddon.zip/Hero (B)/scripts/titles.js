import * as mc from "@minecraft/server";
import * as general from "./modules/general.js";

mc.system.beforeEvents.watchdogTerminate.subscribe(data => data.cancel = true);

let ITEMS = {
  "wesl3y:quirk_black_whip": [ "[2quirk_black_whip]" ],
  "wesl3y:quirk_clones": [ "[2quirk_clones]" ],
  "wesl3y:quirk_cremation": [ "[3quirk_cremation]" ],
  "wesl3y:quirk_dark_shadow": [ "[5quirk_dark_shadow]" ],
  "wesl3y:quirk_decay": [ "[3quirk_decay]" ],
  "wesl3y:quirk_electrification": [ "[3quirk_electrification]" ],
  "wesl3y:quirk_explosion": [ "[4quirk_explosion]" ],
  "wesl3y:quirk_fierce_wings2": [ "[4quirk_fierce_wings]" ],
  "wesl3y:quirk_halfcold_halfhot": [ "[7quirk_halfcold_halfhot]" ],
  "wesl3y:quirk_hell_flame": [ "[7quirk_hell_flame]" ],
  "wesl3y:quirk_ice": [ "[5quirk_ice]" ],
  "wesl3y:quirk_muscle": [ "[3quirk_muscle]" ],
  "wesl3y:quirk_one_for_all": [ "[5quirk_one_for_all]" ],
  "wesl3y:quirk_overhaul": [ "[4quirk_overhaul]" ],
  "wesl3y:quirk_rabbit2": [ "[3quirk_rabbit]" ],
  "wesl3y:quirk_size": [ "[4quirk_size]" ],
  "wesl3y:quirk_zero_gravity": [ "[3quirk_zero_gravity]" ]
}

mc.system.runInterval(() => {
  for (const player of mc.world.getPlayers()) {
    let inventory = player.getComponent("inventory");
    let container = inventory.container;
    let hand = container.getItem( player.selectedSlot );
    let text;
    const
	  id = hand && hand.typeId != "wesl3y:enma" ? hand.typeId : hand && hand.typeId == "wesl3y:enma" && player.hasTag("ame_no_habakiri") ? hand.typeId : "",
	  quirk = [ text ] = id in ITEMS ? ITEMS[ id ] : [ "sla" ],
      stamina = general.getScore("stamina", player) < 9 ? "[stamina_0]" : general.getScore("stamina", player) < 49 ? "[stamina_1]" : general.getScore("stamina", player) < 99 ? "[stamina_2]" : general.getScore("stamina", player) < 149 ? "[stamina_3]" : general.getScore("stamina", player) < 199 ? "[stamina_4]" : general.getScore("stamina", player) < 249 ? "[stamina_5]" : general.getScore("stamina", player) < 299 ? "[stamina_6]" : general.getScore("stamina", player) < 349 ? "[stamina_7]" : general.getScore("stamina", player) < 399 ? "[stamina_8]" : general.getScore("stamina", player) < 449 ? "[stamina_9]" : general.getScore("stamina", player) < 499 ? "[stamina_10]" : general.getScore("stamina", player) < 549 ? "[stamina_11]" : general.getScore("stamina", player) < 599 ? "[stamina_12]" : general.getScore("stamina", player) < 649 ? "[stamina_13]" : general.getScore("stamina", player) < 699 ? "[stamina_14]" : general.getScore("stamina", player) < 749 ? "[stamina_15]" : general.getScore("stamina", player) < 799 ? "[stamina_16]" : general.getScore("stamina", player) < 849 ? "[stamina_17]" : general.getScore("stamina", player) < 899 ? "[stamina_18]" : general.getScore("stamina", player) < 949 ? "[stamina_19]" : "[stamina_20]",
      slot = general.getScore("skills", player) == 0 ? "[slot1]" : general.getScore("skills", player) == 1 ? "[slot2]" : general.getScore("skills", player) == 2 ? "[slot3]" : general.getScore("skills", player) == 3 ? "[slot4]" : general.getScore("skills", player) == 4 ? "[slot5]" : general.getScore("skills", player) == 5 ? "[slot6]" : general.getScore("skills", player) == 6 ? "[slot7]" : general.getScore("skills", player) == 7 ? "[slot8]" : "[slot1]",
      danger = player.hasTag("danger_sensor") ? `Dodge: ${general.getScore("danger_sensor", player)}` : ``;
    if (player.hasTag("gm0")) {
      player.onScreenDisplay.setActionBar(`${detect(player)} ${danger}\nHp: §c${Math.round(player.getComponent("health").currentValue)}/${player.getComponent("health").defaultValue}\n`);
      player.onScreenDisplay.setTitle(`[hp_${Math.round(player.getComponent("health").currentValue * 20 / player.getComponent("health").defaultValue)}]\n${stamina}\n${quirk}\n${slot}\n[cooldown1:${general.getScore('cooldown1', player) > 0 ? `1` : ``}][cooldown2:${general.getScore('cooldown2', player) > 0 ? `1` : ``}][cooldown3:${general.getScore('cooldown3', player) > 0 ? `1` : ``}][cooldown4:${general.getScore('cooldown4', player) > 0 ? `1` : ``}][cooldown5:${general.getScore('cooldown5', player) > 0 ? `1` : ``}]\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\\n\n\n\n\n\n\n\n\n`);
    }
    if (!player.hasTag("gm0")) {
      player.onScreenDisplay.setActionBar(`${detect(player)} ${danger}`);
      player.onScreenDisplay.setTitle(`${stamina}\n${quirk}\n${slot}\n\n[cooldown1:${general.getScore('cooldown1', player) > 0 ? `1` : ``}][cooldown2:${general.getScore('cooldown2', player) > 0 ? `1` : ``}][cooldown3:${general.getScore('cooldown3', player) > 0 ? `1` : ``}][cooldown4:${general.getScore('cooldown4', player) > 0 ? `1` : ``}][cooldown5:${general.getScore('cooldown5', player) > 0 ? `1` : ``}]\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n`);
    }
    player.runCommandAsync(`tag @s[scores={xp=${general.getScore("xpmax", player)}..,xpmax=${general.getScore("xpmax", player)}}] add level`);
    if (player.hasTag("level")) {
      player.removeTag("level");
      player.runCommandAsync(`function level_up`);
      player.runCommandAsync(`scoreboard players remove @s xp ${general.getScore("xpmax", player)}`);
    }
  };
}, 11);

function detect(player) {
  const filter = {
    location: player.location,
    minDistance: 1,
    maxDistance: 16,
    excludeFamilies: ["inanimate","attack","despawn"]
  };
  try {
    for (const entity of [...player.dimension.getEntities(filter)].filter(entity => entity.typeId.startsWith("wesl3y:"))) {
      const quirk = general.getScore("cooldown1", entity) > 1 ? `: §cDeleted§r` : entity.hasTag("quirk_blood_curdle2") ? `: §gBlood Curdle§r` : entity.hasTag("quirk_cremation2") ? `: §gCremation§r` : entity.hasTag("quirk_decay2") ? `: §eDecay§r` : entity.hasTag("quirk_explosion2") ? `: §aExplosion§r` : entity.hasTag("quirk_halfcold_halfhot2") ? `: §aHalfcold Halfhot§r` : entity.hasTag("quirk_muscle2") ? `: §eMuscle§r` : entity.hasTag("quirk_overhaul2") ? `: §gOverhaul§r` : entity.hasTag("quirk_regeneration2") ? `: §gRegeneration§r` : entity.hasTag("quirk_one_for_all2") ? `: §aOne for All§r` : `: §cno Quirk§r`;
      return `${entity.typeId.replace(`wesl3y:`, '')}${quirk}`;
    }
  } catch (error) {} return "";
}