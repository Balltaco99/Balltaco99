import {
    world
} from "@minecraft/server";



export function getScore(target, objective) {
    try {
        return world.scoreboard.getObjective(objective).getScore(target.scoreboardIdentity);
    } catch (error) {
        return 0;
    }
};
