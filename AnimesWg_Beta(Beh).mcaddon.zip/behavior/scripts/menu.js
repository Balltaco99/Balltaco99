import * as mc from "@minecraft/server";
import * as ui from "@minecraft/server-ui";

mc.world.beforeEvents.itemUse.subscribe(data => {
  let { itemStack, source } = data
  const plr = data.source
  if (itemStack.typeId == "wesl3y:characters") {
    mc.system.run(() => {
      animes(plr);
    })
  }
});

function animes(player) {
  const form = new ui.ActionFormData();
  form.title("Choose Character");
  form.body(``);
  form.button("");//Magna
  form.button("");//Todoroki
  form.button("");//Kuririn
  form.button("");//Geto
  form.button("");//Yamamoto
  form.button("");//Yamamoto Bankai
  form.button("");//Kakashi
  form.button("");//Kakashi Sharingan
  form.button("");//Escanor
  form.button("");//Escanor The One
  form.button("");//Luffy
  form.button("");//Luffy Gear2
  form.button("");//Luffy Gear 5
  form.show(player).then((r) => {
    if (r.selection === 0) {
      magna(player);
    }
    if (r.selection === 1) {
      todoroki(player);
    }
    if (r.selection === 2) {
      kuririn(player);
    }
    if (r.selection === 3) {
      geto(player);
    }
    if (r.selection === 4) {
      player.runCommandAsync("scoreboard players set @s wg:animes 2");
      player.runCommandAsync("scoreboard players set @s wg:characters 1");
      player.runCommandAsync(`tellraw @s {"rawtext": [{"text":"No skills\nSem skills"}]}`);
      //yamamoto(player);
    }
    if (r.selection === 5) {
      player.runCommandAsync("scoreboard players set @s wg:animes 2");
      player.runCommandAsync("scoreboard players set @s wg:characters 2");
      player.runCommandAsync(`tellraw @s {"rawtext": [{"text":"No skills\nSem skills"}]}`);
      //yamamoto_bankai(player);
    }
    if (r.selection === 6) {
      kakashi(player);
    }
    if (r.selection === 7) {
      kakashi_sharingan(player);
    }
    if (r.selection === 8) {
      player.runCommandAsync("scoreboard players set @s wg:animes 6");
      player.runCommandAsync("scoreboard players set @s wg:characters 1");
      player.runCommandAsync(`tellraw @s {"rawtext": [{"text":"No skills\nSem skills"}]}`);
      //escanor(player);
    }
    if (r.selection === 9) {
      escanor_the_one(player);
    }
    if (r.selection === 10) {
      luffy(player);
    }
    if (r.selection === 11) {
      luffy_gear2(player);
    }
    if (r.selection === 12) {
      luffy_gear5(player);
    }
  });
}

function todoroki(player) {
  const form = new ui.ActionFormData();
  form.title("Todoroki");
  form.body(`Name: §bTodoroki§r\nHealth: §e80§r\nDamage: §e5§r\n\n           Ice Wall\n           Distance: Short\n           Damage: 5 to 25\n\n           Jet Burn\n           Distance: Long\n           Damage: 20 to 40\n\nInf: Todoroki spawns in the ice biome, defeat him to unlock.\n\n\n                                          Rarity: Common`);
  form.button("Selected");
  form.button("Level Up");
  form.button("<-");
  form.show(player).then((r) => {
    if (r.selection === 0) {
      player.runCommandAsync("scoreboard players set @s wg:animes 3");
      player.runCommandAsync("scoreboard players set @s wg:characters 1");
    }
    if (r.selection === 2) {
      animes(player);
    }
  });
}

function yamamoto(player) {
  const form = new ui.ActionFormData();
  form.title("Yamamoto");
  form.body(`Name: §eYamamoto§r\nHealth: §e100 to 150§r\nDamage: §e5§r\n\n           Fire Dash\n           Distance: Short\n           Damage: 5 to 25\n\n           Fire Cuts\n           Distance: Long\n           Damage: 20 to 40\n\nInf: Yamamoto spawns in the nether, defeat him to unlock.\n\n\n                                      Rarity: §eUncommon`);
  form.button("Selected");
  form.button("Level Up");
  form.button("<-");
  form.show(player).then((r) => {
    if (r.selection === 0) {
      player.runCommandAsync("scoreboard players set @s wg:animes 2");
      player.runCommandAsync("scoreboard players set @s wg:characters 1");
    }
    if (r.selection === 2) {
      animes(player);
    }
  });
}

function yamamoto_bankai(player) {
  const form = new ui.ActionFormData();
  form.title("Yamamoto Bankai");
  form.body(`Name: §eYamamoto Bankai§r\nHealth: §3200 to 250§r\nDamage: §e5§r\n\n           Sul\n           Distance: Short\n            Damage: 5 to 25\n\n           North\n           Distance: Long\n           Damage: 20 to 40\n\n\n             Rarity: §eUncommon`);
  form.button("Selected");
  form.button("Level Up");
  form.button("<-");
  form.show(player).then((r) => {
    if (r.selection === 0) {
      player.runCommandAsync("scoreboard players set @s wg:animes 2");
      player.runCommandAsync("scoreboard players set @s wg:characters 2");
    }
    if (r.selection === 2) {
      animes(player);
    }
  });
}

function luffy(player) {
  const form = new ui.ActionFormData();
  form.title("Luffy");
  form.body(`Name: §eLuffy§r\nHealth: §e200 to 250§r\nDamage: §e12§r\n\n           Gatling Gun\n           Distance: Short\n           Damage: 20 to 40\n\n           Giant Pistol\n           Distance: Short\n           Damage: 30 to 50\n\nInf: Luffy spawns in the plains biome, defeat him to unlock.\n\n\n                                         Rarity: §cMythical`);
  form.button("Selected");
  form.button("Level Up");
  form.button("<-");
  form.show(player).then((r) => {
    if (r.selection === 0) {
      player.runCommandAsync("scoreboard players set @s wg:animes 8");
      player.runCommandAsync("scoreboard players set @s wg:characters 1");
    }
    if (r.selection === 2) {
      animes(player);
    }
  });
}

function luffy_gear2(player) {
  const form = new ui.ActionFormData();
  form.title("Luffy Gear 2");
  form.body(`Name: §eLuffy Gear 2§r\nHealth: §e300 to 350§r\nDamage: §e12§r\n\n           Jet Gatling\n           Distance: Short\n           Damage: 25 to 45\n\n           Red Hawk\n           Distance: Short\n           Damage: 30 to 50\n\n           Red Roc\n           Distance: Short\n           Damage: 35 to 55.\n\n                                         Rarity: §cMythical`);
  form.button("Selected");
  form.button("Level Up");
  form.button("<-");
  form.show(player).then((r) => {
    if (r.selection === 0) {
      player.runCommandAsync("scoreboard players set @s wg:animes 8");
      player.runCommandAsync("scoreboard players set @s wg:characters 2");
    }
    if (r.selection === 2) {
      animes(player);
    }
  });
}

function luffy_gear5(player) {
  const form = new ui.ActionFormData();
  form.title("Luffy Gear 5");
  form.body(`Name: §eLuffy Gear 5§r\nHealth: §e400 to 450§r\nDamage: §e12§r\n\n           Giant Kick\n           Distance: Short\n           Damage: 40 to 60\n\n           Kaminari\n           Distance: Long\n           Damage: 45 to 65\n\n           Bajrang Gun\n           Distance: Long\n           Damage: 50 to 70.\n\n                                         Rarity: §cMythical`);
  form.button("Selected");
  form.button("Level Up");
  form.button("<-");
  form.show(player).then((r) => {
    if (r.selection === 0) {
      player.runCommandAsync("scoreboard players set @s wg:animes 8");
      player.runCommandAsync("scoreboard players set @s wg:characters 3");
    }
    if (r.selection === 2) {
      animes(player);
    }
  });
}