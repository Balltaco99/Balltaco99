import * as mc from "@minecraft/server";

export function getScore(objective, player) { try { return mc.world.scoreboard.getObjective(objective).getScore(player.scoreboardIdentity); } catch (error) { return 0; } }

mc.system.runInterval((data) => {
  for (const player of mc.world.getPlayers()) {
    const
      fury = getScore("wg:power", player) >= 100 ? "[fury9]" : getScore("wg:power", player) >= 90 ? "[fury8]" : getScore("wg:power", player) >= 80 ? "[fury7]" : getScore("wg:power", player) >= 70 ? "[fury6]" : getScore("wg:power", player) >= 60 ? "[fury5]" : getScore("wg:power", player) >= 50 ? "[fury4]" : getScore("wg:power", player) >= 40 ? "[fury3]" : getScore("wg:power", player) >= 30 ? "[fury2]" : getScore("wg:power", player) >= 20 ? "[fury1]" : "[fury0]",
      bleach = getScore("wg:characters", player) == 1 ? "[yamamoto]" : getScore("wg:characters", player) == 2 ? "[yamamoto_bankai]" : "[]",
      boku_no_hero = getScore("wg:characters", player) == 1 ? "[todoroki]" : "[]",
      nanatsu = getScore("wg:characters", player) == 1 ? "[escanor]" : getScore("wg:characters", player) == 2 ? "[escanor_day]" : getScore("wg:characters", player) == 3 ? "[escanor_the_one]" : "[]",
      naruto = getScore("wg:characters", player) == 1 ? "[kakashi]" : getScore("wg:characters", player) == 2 ? "[kakashi_sharingan]" : getScore("wg:characters", player) == 3 ? "[kakashi_mangekyou]" : "[]",
      one_piece = getScore("wg:characters", player) == 1 ? "[luffy]" : getScore("wg:characters", player) == 2 ? "[luffy_gear2]" : getScore("wg:characters", player) == 3 ? "[luffy_gear5]" : "[]";
    player.onScreenDisplay.setTitle(
      `[fury${fury}]\n` +
      `${getScore("wg:animes", player) == 2 ? bleach : getScore("wg:animes", player) == 3 ? boku_no_hero : getScore("wg:animes", player) == 6 ? nanatsu : getScore("wg:animes", player) == 7 ? naruto : getScore("wg:animes", player) == 8 ? one_piece : ""}`
    );
  }
}, 10);