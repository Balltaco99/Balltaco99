import { world, system } from "@minecraft/server";
import { ActionFormData, MessageFormData, ModalFormData } from "@minecraft/server-ui";


//Detects hotbar slots
function hotbarDetect() {
  system.runInterval(eventTick => {
    for (const player of world.getPlayers()) {
      let hotbarSlot = player.selectedSlot
      player.runCommand(`scoreboard players set @s hotbar ${hotbarSlot + 1}`)
    }
  })
}




//TIME DETECTION
//Hours
function hour() {
  system.runInterval(eventTick => {
	const date = new Date();
	const hournumber = date.getHours();
	const hour = `${hournumber}`;
	 for (const player of world.getPlayers()) {
      player.runCommand(`scoreboard players set @s hour ${hour}`)
	 }
  });
}
//Minutes
function minute() {
  system.runInterval(eventTick => {
	const date = new Date();
	const minnumber = date.getMinutes();
	const minute = `${minnumber}`;
	 for (const player of world.getPlayers()) {
      player.runCommand(`scoreboard players set @s minute ${minute}`)
	 }
  });
}
//Seconds
function second() {
  system.runInterval(eventTick => {
	const date = new Date();
	const secnumber = date.getSeconds();
	const second = `${secnumber}`;
	 for (const player of world.getPlayers()) {
      player.runCommand(`scoreboard players set @s second ${second}`)
	 }
  });
}



hotbarDetect()
hour()
minute()
second()