import { world, system } from "@minecraft/server";
import { ActionFormData, MessageFormData, ModalFormData } from "@minecraft/server-ui";





world.beforeEvents.itemUse.subscribe(event => {
	if (event.itemStack.typeId === "minecraft:stick" && event.itemStack.nameTag === "Form Opener") {
		let form = new ActionFormData();
		let effectList = [ "Option1", "Option2", "Option3", "Option4" ]
		form.textField("Text Field", "Text Input")
		form.title("Title");
		form.body("Body");
		form.dropdown("Dropdown", effectList)
		form.slider("Slider", 0, 100, 1)
		form.toggle("Toggle", true)
		form.button(" ", "textures/ui/anit/anit_play.png");
	};
});

