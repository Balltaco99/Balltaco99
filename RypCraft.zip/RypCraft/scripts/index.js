import 'ui/bars.js'
import './getScore.js';