import * as mc from "@minecraft/server"
import * as gs from "../getScore";

mc.system.runInterval(() => {
    for (const player of mc.world.getPlayers()) {
        titles(player);
    }}, 2);

function titles(player) {
    //consts
    const ene_max = gs.getScore(player, "ene_max");
    const xp = gs.getScore(player, "xp");
    const xp_max = gs.getScore(player, "xp_max");
    const hp = player.getComponent("minecraft:health").currentValue;
    const hp_max = player.getComponent("minecraft:health").defaultValue;

    player.onScreenDisplay.setTitle(`[energy_${parseInt(gs.getScore(player, "ene") * 100 / gs.getScore(player, "ene_max"))}] [xp_${parseInt(xp * 100 / xp_max)}] [hp_${parseInt(hp * 100 / hp_max)}]`);
    
    
    if (gs.getScore(player, "ene") > gs.getScore(player, "ene_max")) {
        player.runCommandAsync(`scoreboard players set @s ene ${ene_max}`);
    }
}