import * as mc from '@minecraft/server';
import * as ui from '@minecraft/server-ui';
import * as general from "./modules/general.js";

mc.world.beforeEvents.itemUse.subscribe((data) => {
  let { itemStack, source } = data
  const plr = data.source
  if (itemStack.typeId == "wesl3y:menu") {
    mc.system.run(() => {
      menu(plr);
    });
  };
});

function menu(player) {
  const form = new ui.ActionFormData();
  const
    name = player.hasTag("all_might") ? "All Might" : player.hasTag("bakugou") ? "Bakugou" : player.hasTag("deku") ? "Deku" : player.hasTag("endeavor") ? "Endeavor" : player.hasTag("rule") ? "Rule" : player.hasTag("shoto") ? "Shoto" : player.hasTag("tsukuyomi") ? "Tsukuyomi" : player.hasTag("uravity") ? "Uravity" : player.hasTag("dabi") ? "Dabi" : player.hasTag("shigaraki") ? "Shigaraki" : "",
    rank = player.hasTag("hero") ? "§aHero" : player.hasTag("villain") ? "§cVillain" : "";
  form.title("Menu");
  form.body(`§8Name: §0${name}\n§8Rank: ${rank}\n§8Points: §0${general.getScore("points", player)}\n§8Quirk: §0${general.getScore("quirk", player)}\n§8Level: §0${general.getScore("level", player)}\n§8Exp: §0${general.getScore("xp", player)}/${general.getScore("xpmax", player)}`);
  form.button("Stats");
  form.show(player).then((r) => {
    if (r.selection === 0) {
      stats(player);
    }
  }
);}

function stats(player) {
  const form = new ui.ActionFormData();
  form.title("Stats");
  //form.body(`§8Body Strength: §0${general.getScore("body_strength", player)}\n§8Strength: §0${general.getScore("strength", player)}\n§8Jump: §0${general.getScore("jump", player)}\n§8Speed: §0${general.getScore("speed", player)}`);
  form.button(`Body\n${general.getScore("body_strength", player)}/20`);
  form.button(`Strength\n${general.getScore("strength", player)}/7`);
  form.button(`Jump\n${general.getScore("jump", player)}/10`);
  form.button(`Speed\n${general.getScore("speed", player)}/10`);
  form.show(player).then((r) => {
    if (r.selection === 0) {
      player.runCommandAsync(`tellraw @s[scores={points=!5..}] {"rawtext":[{"text":"§c[Insufficient Points: Min 5]"}]}`);
      player.runCommandAsync(`playsound random.levelup @s[scores={body_strength=..19,points=5..}]`);
      player.runCommandAsync(`scoreboard players add @s[scores={body_strength=..19,points=5..}] body_strength 1`);
      player.runCommandAsync(`tag @s[scores={body_strength=..19,points=5..}] add update_stats`);
      stats(player);
    }
    if (r.selection === 1) {
      player.runCommandAsync(`tellraw @s[scores={points=!5..}] {"rawtext":[{"text":"§c[Insufficient Points: Min 5]"}]}`);
      player.runCommandAsync(`playsound random.levelup @s[scores={strength=..6,points=5..}]`);
      player.runCommandAsync(`scoreboard players add @s[scores={strength=..6,points=5..}] strength 1`);
      player.runCommandAsync(`tag @s[scores={strength=..6,points=5..}] add update_stats`);
      stats(player);
    }
    if (r.selection === 2) {
      player.runCommandAsync(`tellraw @s[scores={points=!5..}] {"rawtext":[{"text":"§c[Insufficient Points: Min 5]"}]}`);
      player.runCommandAsync(`playsound random.levelup @s[scores={jump=..6,points=5..}]`);
      player.runCommandAsync(`scoreboard players add @s[scores={jump=..6,points=5..}] jump 1`);
      player.runCommandAsync(`tag @s[scores={jump=..6,points=5..}] add update_stats`);
      stats(player);
    }
    if (r.selection === 3) {
      player.runCommandAsync(`tellraw @s[scores={points=!5..}] {"rawtext":[{"text":"§c[Insufficient Points: Min 5]"}]}`);
      player.runCommandAsync(`playsound random.levelup @s[scores={speed=..6,points=5..}]`);
      player.runCommandAsync(`scoreboard players add @s[scores={speed=..6,points=5..}] speed 1`);
      player.runCommandAsync(`tag @s[scores={speed=..6,points=5..}] add update_stats`);
      stats(player);
    }
    if (r.canceled) {
      menu(player);
    }
  }
);}


mc.system.runInterval(() => {
  for (const player of mc.world.getPlayers()) {
    if (!player.hasTag("custom") && !(player.hasTag("hero") || player.hasTag("villain"))) custom(player);
  }
}, 5);

function custom(player) {
  player.addTag("custom");
  const form = new ui.ActionFormData();
  form.title("Start");
  form.body(`Derrote vilões para subir de level. Seu nome de heroi é escolhido aleatório, ele não muda em nada, é apenas para deixar mais legal. Fale com aizawa para fazer missões.\n\n\nDerrote heróis para subir de level. Seu nome de vilão e escolhido aleatório, ele não muda em nada, é apenas para deixar mais legal. Fale com o dabi para derrotar Heróis.`);
  form.button("Hero");
  form.button("Villain");
  form.show(player).then((r) => {
    if (r.canceled) {
      custom(player);
    }
    if (r.selection === 0) {
      player.runCommandAsync("event entity @s wesl3y:hero_name");
      player.addTag("hero");
      player.removeTag("custom");
    }
    if (r.selection === 1) {
      player.runCommandAsync("event entity @s wesl3y:villain_name");
      player.addTag("villain");
      player.removeTag("custom");
    }
  }
);}

mc.world.afterEvents.entityHitEntity.subscribe(data => {
  let hit = data.hitEntity;
  let player = data.damagingEntity;
  if(!hit || player.typeId != "minecraft:player") return;
  if(player.typeId == "minecraft:player"){
    if(hit.typeId == "wesl3y:npc" && hit.hasTag("variant1")) mei(player);
    if(hit.typeId == "wesl3y:npc" && hit.hasTag("variant2")) aizawa(player);
    if(hit.typeId == "wesl3y:npc" && hit.hasTag("variant3")) dabi(player);
  }
});

function mei(player) {
  const form = new ui.ActionFormData();
  form.title("Shop");
  form.button("§fAll Might Suit\n§e[30 Money]");
  form.button("§fBakugou Suit\n§e[15 Money]");
  form.button("§fChargezuma Suit\n§e[15 Money]");
  form.button("§fDeku Suit\n§e[15 Money]");
  form.button("§fDeku Dark\n§e[20 Money]");
  form.button("§fEndeavor Suit\n§e[25 Money]");
  form.button("§fEraser Suit\n§e[20 Money]");
  form.button("§fHawks Suit\n§e[20 Money]");
  form.button("§fLemillion Suit\n§e[20 Money]");
  form.button("§fMirko Suit\n§e[20 Money]");
  form.button("§fRed Riot Suit\n§e[15 Money]");
  form.button("§fRule Suit\n§e[15 Money]");
  form.button("§fShoto Suit\n§e[20 Money]");
  form.button("§fTsukuyomi Suit\n§e[15 Money]");
  form.button("§fUravity Suit\n§e[15 Money]");
  form.show(player).then((r) => {
    if (r.selection === 0) {
      player.runCommandAsync(`tellraw @s[hasitem={item=wesl3y:money,quantity=!30..}] {"rawtext":[{"translate":"shop.no_money"}]}`);
      player.runCommandAsync("give @s[hasitem={item=wesl3y:money,quantity=30..}] wesl3y:all_might_suit 1");
      player.runCommandAsync("clear @s[hasitem={item=wesl3y:money,quantity=30..}] wesl3y:money 0 30");
    }
    if (r.selection === 1) {
      player.runCommandAsync(`tellraw @s[hasitem={item=wesl3y:money,quantity=!15..}] {"rawtext":[{"translate":"shop.no_money"}]}`);
      player.runCommandAsync("give @s[hasitem={item=wesl3y:money,quantity=15..}] wesl3y:bakugou_suit 1");
      player.runCommandAsync("clear @s[hasitem={item=wesl3y:money,quantity=15..}] wesl3y:money 0 15");
    }
    if (r.selection === 2) {
      player.runCommandAsync(`tellraw @s[hasitem={item=wesl3y:money,quantity=!15..}] {"rawtext":[{"translate":"shop.no_money"}]}`);
      player.runCommandAsync("give @s[hasitem={item=wesl3y:money,quantity=15..}] wesl3y:chargezuma_suit 1");
      player.runCommandAsync("clear @s[hasitem={item=wesl3y:money,quantity=15..}] wesl3y:money 0 15");
    }
    if (r.selection === 3) {
      player.runCommandAsync(`tellraw @s[hasitem={item=wesl3y:money,quantity=!15..}] {"rawtext":[{"translate":"shop.no_money"}]}`);
      player.runCommandAsync("give @s[hasitem={item=wesl3y:money,quantity=15..}] wesl3y:deku_suit 1");
      player.runCommandAsync("clear @s[hasitem={item=wesl3y:money,quantity=15..}] wesl3y:money 0 15");
    }
    if (r.selection === 4) {
      player.runCommandAsync(`tellraw @s[hasitem={item=wesl3y:money,quantity=!20..}] {"rawtext":[{"translate":"shop.no_money"}]}`);
      player.runCommandAsync("give @s[hasitem={item=wesl3y:money,quantity=20..}] wesl3y:deku_dark_suit 1");
      player.runCommandAsync("clear @s[hasitem={item=wesl3y:money,quantity=20..}] wesl3y:money 0 20");
    }
    if (r.selection === 5) {
      player.runCommandAsync(`tellraw @s[hasitem={item=wesl3y:money,quantity=!25..}] {"rawtext":[{"translate":"shop.no_money"}]}`);
      player.runCommandAsync("give @s[hasitem={item=wesl3y:money,quantity=25..}] wesl3y:endeavor_suit 1");
      player.runCommandAsync("clear @s[hasitem={item=wesl3y:money,quantity=25..}] wesl3y:money 0 25");
    }
    if (r.selection === 6) {
      player.runCommandAsync(`tellraw @s[hasitem={item=wesl3y:money,quantity=!20..}] {"rawtext":[{"translate":"shop.no_money"}]}`);
      player.runCommandAsync("give @s[hasitem={item=wesl3y:money,quantity=20..}] wesl3y:eraser_suit 1");
      player.runCommandAsync("clear @s[hasitem={item=wesl3y:money,quantity=20..}] wesl3y:money 0 20");
    }
    if (r.selection === 7) {
      player.runCommandAsync(`tellraw @s[hasitem={item=wesl3y:money,quantity=!20..}] {"rawtext":[{"translate":"shop.no_money"}]}`);
      player.runCommandAsync("give @s[hasitem={item=wesl3y:money,quantity=20..}] wesl3y:hawks_suit 1");
      player.runCommandAsync("clear @s[hasitem={item=wesl3y:money,quantity=20..}] wesl3y:money 0 20");
    }
    if (r.selection === 8) {
      player.runCommandAsync(`tellraw @s[hasitem={item=wesl3y:money,quantity=!20..}] {"rawtext":[{"translate":"shop.no_money"}]}`);
      player.runCommandAsync("give @s[hasitem={item=wesl3y:money,quantity=20..}] wesl3y:lemillion_suit 1");
      player.runCommandAsync("clear @s[hasitem={item=wesl3y:money,quantity=20..}] wesl3y:money 0 20");
    }
    if (r.selection === 9) {
      player.runCommandAsync(`tellraw @s[hasitem={item=wesl3y:money,quantity=!20..}] {"rawtext":[{"translate":"shop.no_money"}]}`);
      player.runCommandAsync("give @s[hasitem={item=wesl3y:money,quantity=20..}] wesl3y:mirko_suit 1");
      player.runCommandAsync("clear @s[hasitem={item=wesl3y:money,quantity=20..}] wesl3y:money 0 20");
    }
    if (r.selection === 10) {
      player.runCommandAsync(`tellraw @s[hasitem={item=wesl3y:money,quantity=!15..}] {"rawtext":[{"translate":"shop.no_money"}]}`);
      player.runCommandAsync("give @s[hasitem={item=wesl3y:money,quantity=15..}] wesl3y:red_riot_suit 1");
      player.runCommandAsync("clear @s[hasitem={item=wesl3y:money,quantity=15..}] wesl3y:money 0 15");
    }
    if (r.selection === 11) {
      player.runCommandAsync(`tellraw @s[hasitem={item=wesl3y:money,quantity=!15..}] {"rawtext":[{"translate":"shop.no_money"}]}`);
      player.runCommandAsync("give @s[hasitem={item=wesl3y:money,quantity=15..}] wesl3y:rule_suit 1");
      player.runCommandAsync("clear @s[hasitem={item=wesl3y:money,quantity=15..}] wesl3y:money 0 15");
    }
    if (r.selection === 12) {
      player.runCommandAsync(`tellraw @s[hasitem={item=wesl3y:money,quantity=!20..}] {"rawtext":[{"translate":"shop.no_money"}]}`);
      player.runCommandAsync("give @s[hasitem={item=wesl3y:money,quantity=20..}] wesl3y:shoto_suit 1");
      player.runCommandAsync("clear @s[hasitem={item=wesl3y:money,quantity=20..}] wesl3y:money 0 20");
    }
    if (r.selection === 13) {
      player.runCommandAsync(`tellraw @s[hasitem={item=wesl3y:money,quantity=!15..}] {"rawtext":[{"translate":"shop.no_money"}]}`);
      player.runCommandAsync("give @s[hasitem={item=wesl3y:money,quantity=15..}] wesl3y:tsukuyomi_suit 1");
      player.runCommandAsync("clear @s[hasitem={item=wesl3y:money,quantity=15..}] wesl3y:money 0 15");
    }
    if (r.selection === 14) {
      player.runCommandAsync(`tellraw @s[hasitem={item=wesl3y:money,quantity=!15..}] {"rawtext":[{"translate":"shop.no_money"}]}`);
      player.runCommandAsync("give @s[hasitem={item=wesl3y:money,quantity=15..}] wesl3y:uravity_suit 1");
      player.runCommandAsync("clear @s[hasitem={item=wesl3y:money,quantity=15..}] wesl3y:money 0 15");
    }
  }
);}

function aizawa(player) {
  const form = new ui.ActionFormData();
  form.title("Shop");
  form.button("§f8 Bandidos");
  form.button("§fDabi");
  form.button("§fOverhaul");
  form.button("§fShigaraki");
  form.button("§fBônus");
  form.show(player).then((r) => {
    if (r.selection === 0) {
      if (general.getScore("missions", player) == 0) {
        player.runCommandAsync(`tellraw @s {"rawtext":[{"translate":"text.mission.1"},{"text":"\n"},{"translate":"text.start_mission"}]}`);
        player.runCommandAsync(`scoreboard players set @s missions 9`);
        player.runCommandAsync(`tag @s add bandit_mission`);
      } else player.runCommandAsync(`tellraw @s {"rawtext":[{"translate":"text.in_mission"}]}`)
    }
    if (r.selection === 1) {
      if (general.getScore("missions", player) == 0) {
        player.runCommandAsync(`tellraw @s {"rawtext":[{"translate":"text.mission.2"},{"text":"\n"},{"translate":"text.mission.2_2"},{"text":"\n"},{"translate":"text.start_mission"}]}`);
        player.runCommandAsync(`scoreboard players set @s missions 1`);
        player.runCommandAsync(`tag @s add dabi_mission`);
      } else player.runCommandAsync(`tellraw @s {"rawtext":[{"translate":"text.in_mission"}]}`)
    }
    if (r.selection === 2) {
      if (general.getScore("missions", player) == 0) {
        player.runCommandAsync(`tellraw @s {"rawtext":[{"translate":"text.mission.3"},{"text":"\n"},{"translate":"text.mission.3_2"},{"text":"\n"},{"translate":"text.start_mission"}]}`);
        player.runCommandAsync(`scoreboard players set @s missions 1`);
        player.runCommandAsync(`tag @s add overhaul_mission`);
      } else player.runCommandAsync(`tellraw @s {"rawtext":[{"translate":"text.in_mission"}]}`)
    }
    if (r.selection === 3) {
      if (general.getScore("missions", player) == 0) {
        player.runCommandAsync(`tellraw @s {"rawtext":[{"translate":"text.mission.4"},{"text":"\n"},{"translate":"text.mission.4_2"},{"text":"\n"},{"translate":"text.start_mission"}]}`);
        player.runCommandAsync(`scoreboard players set @s missions 1`);
        player.runCommandAsync(`tag @s add shigaraki_mission`);
      } else player.runCommandAsync(`tellraw @s {"rawtext":[{"translate":"text.in_mission"}]}`)
    }
    if (r.selection === 4) {
      if (general.getScore("missions", player) == 0) {
        player.runCommandAsync(`tellraw @s {"rawtext":[{"translate":"text.mission.nomu"},{"text":"\n"},{"translate":"text.start_mission"}]}`);
        player.runCommandAsync(`scoreboard players set @s missions 1`);
        player.runCommandAsync(`tag @s add nomu_mission`);
      } else player.runCommandAsync(`tellraw @s {"rawtext":[{"translate":"text.in_mission"}]}`)
    }
  }
);}
    
function dabi(player) {
  const form = new ui.ActionFormData();
  form.title("Shop");
  form.button("§fMissions");
  form.button("§fAll For One Suit\n§e[30 Money]");
  form.button("§fKatana Stain\n§e[10 Money]");
  form.button("§fOverhaul Suit\n§e[25 Money]");
  form.button("§fShigaraki Suit\n§e[25 Money]");
  form.button("§fStain Suit\n§e[20 Money]");
  form.button("§fQuirk Random\n§e[64 Money]");
  form.show(player).then((r) => {
    if (r.selection === 0) {
      if (player.hasTag("villain")) {
        villain2(player);
      } else player.runCommandAsync(`tellraw @s {"rawtext":[{"text":"§cNo Hero!!!"}]}`);
    }
    if (r.selection === 1) {
      player.runCommandAsync(`tellraw @s[hasitem={item=wesl3y:money,quantity=!30..}] {"rawtext":[{"translate":"shop.no_money"}]}`);
      player.runCommandAsync("give @s[hasitem={item=wesl3y:money,quantity=30..}] wesl3y:all_for_one_suit 1");
      player.runCommandAsync("clear @s[hasitem={item=wesl3y:money,quantity=30..}] wesl3y:money 0 30");
    }
    if (r.selection === 2) {
      player.runCommandAsync(`tellraw @s[hasitem={item=wesl3y:money,quantity=!10..}] {"rawtext":[{"translate":"shop.no_money"}]}`);
      player.runCommandAsync("give @s[hasitem={item=wesl3y:money,quantity=10..}] wesl3y:katana_stain 1");
      player.runCommandAsync("clear @s[hasitem={item=wesl3y:money,quantity=10..}] wesl3y:money 0 10");
    }
    if (r.selection === 3) {
      player.runCommandAsync(`tellraw @s[hasitem={item=wesl3y:money,quantity=!25..}] {"rawtext":[{"translate":"shop.no_money"}]}`);
      player.runCommandAsync("give @s[hasitem={item=wesl3y:money,quantity=25..}] wesl3y:overhaul_suit 1");
      player.runCommandAsync("clear @s[hasitem={item=wesl3y:money,quantity=25..}] wesl3y:money 0 25");
    }
    if (r.selection === 4) {
      player.runCommandAsync(`tellraw @s[hasitem={item=wesl3y:money,quantity=!25..}] {"rawtext":[{"translate":"shop.no_money"}]}`);
      player.runCommandAsync("give @s[hasitem={item=wesl3y:money,quantity=25..}] wesl3y:shigaraki_suit 1");
      player.runCommandAsync("clear @s[hasitem={item=wesl3y:money,quantity=25..}] wesl3y:money 0 25");
    }
    if (r.selection === 5) {
      player.runCommandAsync(`tellraw @s[hasitem={item=wesl3y:money,quantity=!20..}] {"rawtext":[{"translate":"shop.no_money"}]}`);
      player.runCommandAsync("give @s[hasitem={item=wesl3y:money,quantity=20..}] wesl3y:stain_suit 1");
      player.runCommandAsync("clear @s[hasitem={item=wesl3y:money,quantity=20..}] wesl3y:money 0 20");
    }
    if (r.selection === 6) {
      player.runCommandAsync(`tellraw @s[hasitem={item=wesl3y:money,quantity=!64..}] {"rawtext":[{"translate":"shop.no_money"}]}`);
      player.runCommandAsync("give @s[hasitem={item=wesl3y:money,quantity=64..}] wesl3y:quirk_random 1");
      player.runCommandAsync("clear @s[hasitem={item=wesl3y:money,quantity=64..}] wesl3y:money 0 64");
    }
  }
);}

function villain2(player) {
  const form = new ui.ActionFormData();
  form.title("Shop");
  form.button("§f8 Policemam");
  form.button("§fShoto");
  form.button("§fBakugo");
  form.button("§fDeku Dark");
  form.button("§fBônus");
  form.show(player).then((r) => {
    if (r.selection === 0) {
      if (general.getScore("missions", player) == 0) {
        player.runCommandAsync(`tellraw @s {"rawtext":[{"translate":"text.mission.6"},{"text":"\n"},{"translate":"text.mission.6_2"},{"text":"\n"},{"translate":"text.start_mission"}]}`);
        player.runCommandAsync(`scoreboard players set @s missions 9`);
        player.runCommandAsync(`tag @s add police_mission`);
      } else player.runCommandAsync(`tellraw @s {"rawtext":[{"translate":"text.in_mission"}]}`)
    }
    if (r.selection === 1) {
      if (general.getScore("missions", player) == 0) {
        player.runCommandAsync(`tellraw @s {"rawtext":[{"translate":"text.mission.7"},{"text":"\n"},{"translate":"text.mission.7_2"},{"text":"\n"},{"translate":"text.start_mission"}]}`);
        player.runCommandAsync(`scoreboard players set @s missions 1`);
        player.runCommandAsync(`tag @s add shoto_mission`);
      } else player.runCommandAsync(`tellraw @s {"rawtext":[{"translate":"text.in_mission"}]}`)
    }
    if (r.selection === 2) {
      if (general.getScore("missions", player) == 0) {
        player.runCommandAsync(`tellraw @s {"rawtext":[{"translate":"text.mission.8"},{"text":"\n"},{"translate":"text.mission.8_2"},{"text":"\n"},{"translate":"text.start_mission"}]}`);
        player.runCommandAsync(`scoreboard players set @s missions 1`);
        player.runCommandAsync(`tag @s add bakugo_mission`);
      } else player.runCommandAsync(`tellraw @s {"rawtext":[{"translate":"text.in_mission"}]}`)
    }
    if (r.selection === 3) {
      if (general.getScore("missions", player) == 0) {
        player.runCommandAsync(`tellraw @s {"rawtext":[{"translate":"text.mission.9"},{"text":"\n"},{"translate":"text.mission.9_2"},{"text":"\n"},{"translate":"text.start_mission"}]}`);
        player.runCommandAsync(`scoreboard players set @s missions 1`);
        player.runCommandAsync(`tag @s add deku_dark_mission`);
      } else player.runCommandAsync(`tellraw @s {"rawtext":[{"translate":"text.in_mission"}]}`)
    }
    if (r.selection === 4) {
      if (general.getScore("missions", player) == 0) {
        player.runCommandAsync(`tellraw @s {"rawtext":[{"translate":"text.mission.all_might"},{"text":"\n"},{"translate":"text.start_mission"}]}`);
        player.runCommandAsync(`scoreboard players set @s missions 1`);
        player.runCommandAsync(`tag @s add all_might_mission`);
      } else player.runCommandAsync(`tellraw @s {"rawtext":[{"translate":"text.in_mission"}]}`)
    }
  }
);}