//import { DynamicPropertiesDefinition,MinecraftEntityTypes,Entity,EntityType,EntityTypes,Player,world } from "@minecraft/server";
import * as mc from '@minecraft/server';
import "./test/wg.js";

mc.system.beforeEvents.watchdogTerminate.subscribe(data => data.cancel = true);

/*
let propsPlayer = [
    "vida",
    "vidaM"
];

propsPlayer.forEach(prop => {
  world.afterEvents.worldInitialize.subscribe((event) => {
    const def = new DynamicPropertiesDefinition();
    def.defineNumber(`${prop}`)
    event.propertyRegistry.registerEntityTypeDynamicProperties(def, EntityTypes.get("minecraft:player"));
  });
});


Object.defineProperties(Player.prototype, {
vida: {
get(){return this.getDynamicProperty("vida")??50 },
set(a){return this.setDynamicProperty("vida",a)}},
vidaM:{
get(){return this.getDynamicProperty("vidaM")??50 },
set(a){return this.setDynamicProperty("vidaM",a)}}
});

mc.world.afterEvents.playerSpawn.subscribe((event) => {
  event.player.vida = event.player.vidaM
});*/