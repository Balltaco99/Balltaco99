import * as mc from "@minecraft/server";
import * as general from "../general.js";
import * as modules from "../modules.js";

//mc.system.runInterval(() => { for (const player of mc.world.getPlayers()) { if (player.vida < player.vidaM) player.vida = player.vida + 1; if (player.vida > player.vidaM) player.vida = player.vidaM; player.vidaM = 50 + Math.round(general.getScore("healthStats", player) * 5); } }, 30);

general.tick1(function(player) => {
  if (!player.hasTag("custom") && !player.hasTag("custom2")) modules.custom(player);
  if (player.hasTag("update_stats")) {
    player.removeTag("update_stats");
    player.triggerEvent(`wesl3y:health.${general.getScore("healthStats", player)}`);
    player.runCommandAsync(`scoreboard players set @s energyMax ${general.getScore("energyStats", player) != 0 ? general.getScore("energyStats", player) : "1"}${general.getScore("energyStats", player) <= 10 ? "0" : ""}0`);
    player.runCommandAsync(`function stats`);
  }
  if (player.hasTag("level_up")) {
    player.removeTag("level_up");
    player.runCommandAsync(`scoreboard players add @s level 1`);
    player.runCommandAsync(`scoreboard players remove @s xpCur ${general.getScore("xpMax", player)}`);
    player.runCommandAsync(`scoreboard players set @s xpMax ${general.getScore("level", player) >= 10 ? general.getScore("level", player) : "10"}0`);
    player.runCommandAsync("scoreboard players add @s[scores={level=!10..}] point 1");
    player.runCommandAsync(`tag @s add update_stats`);
    player.runCommandAsync(`tellraw @s {"rawtext":[{"text":"§aLevel Up! §r("},{"score":{"name": "@s", "objective": "level"}},{"text":")"}]}`);
    player.runCommandAsync(`tellraw @s[scores={level=10}] {"rawtext":[{"text":"§cCraft the East Blue map"}]}`);
  }
  //  if (player.getComponent("health")?.currentValue <= 0 || player.vida <= 0) { player.kill(); player.vida = player.vidaM; if (player.hasTag("devil_fruit")) player.runCommandAsync("function player/fruit/reset"); player.runCommandAsync("tag @s add update_stats"); }
  if (player.getComponent("health")?.currentValue <= 0) {
    if (player.hasTag("devil_fruit")) player.runCommandAsync("function player/fruit/reset");
    player.runCommandAsync("tag @s add update_stats");
  }
  for (const entity of [...player.dimension.getEntities()]) {
    const knockback = entity.hasTag("geppo") ? "geppo" : entity.hasTag("jump0_2") ? "jump0_2" : entity.hasTag("jump1_3") ? "jump1_3" : entity.hasTag("jump2_1") ? "jump2_1" : entity.hasTag("jump2_3") ? "jump2_3" : entity.hasTag("speed1") ? "speed1" : entity.hasTag("speed1_25") ? "speed1_25" : entity.hasTag("speed1_5") ? "speed1_5" : "";
    switch (knockback) {
      case `geppo`:
        entity.removeTag("geppo");
        entity.applyKnockback(entity.getViewDirection().x,entity.getViewDirection().z,entity.getViewDirection().y +0.8,1.0);
      break
      case `jump0_2`:
        entity.removeTag("jump0_2");
        entity.applyKnockback(entity.getViewDirection().x,entity.getViewDirection().z,entity.getViewDirection().y,2.0);
      break
      case `jump1_3`:
        entity.removeTag("jump1_3");
        entity.applyKnockback(entity.getViewDirection().x,entity.getViewDirection().z,entity.getViewDirection().y +1.0,3.0);
      break
      case `jump2_1`:
        entity.removeTag("jump2_1");
        entity.applyKnockback(entity.getViewDirection().x,entity.getViewDirection().z,entity.getViewDirection().y +2.0,1.0);
      break
      case `jump2_3`:
        entity.removeTag("jump2_3");
        entity.applyKnockback(entity.getViewDirection().x,entity.getViewDirection().z,entity.getViewDirection().y +2.0,3.0);
      break
      case `speed1`:
        entity.removeTag("speed1");
        entity.applyKnockback(entity.getViewDirection().x,entity.getViewDirection().z,entity.getViewDirection().y +1.0,0.0);
      break
      case `speed1_25`:
        entity.removeTag("speed1_25");
        entity.applyKnockback(entity.getViewDirection().x,entity.getViewDirection().z,entity.getViewDirection().y +1.25,0.0);
      break
      case `speed1_5`:
        entity.removeTag("speed1_5");
        entity.applyKnockback(entity.getViewDirection().x,entity.getViewDirection().z,entity.getViewDirection().y +1.5,0.0);
      break
    }
  }
});