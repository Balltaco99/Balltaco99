import * as mc from "@minecraft/server";
import * as general from "../general";

let ITEMS = {
  "wesl3y:bara_skills": [ "[bara] [skills5] [fruit]" ],
  "wesl3y:bomu_skills": [ "[bomu] [skills5] [fruit]" ],
  "wesl3y:doru_skills": [ "[doru] [skills5] [fruit]" ],
  "wesl3y:gomu_skills": [ "[gomu] [skills5] [fruit]" ],
  "wesl3y:gomu2_skills": [ "[gomu2] [skills5] [fruit]" ],
  "wesl3y:gomu3_skills": [ "[gomu3] [skills5] [fruit]" ],
  "wesl3y:gomu4_skills": [ "[gomu4] [skills5] [fruit]" ],
  "wesl3y:gomu4_2_skills": [ "[gomu4_2] [skills5] [fruit]" ],
  "wesl3y:gomu5_skills": [ "[gomu5] [skills5] [fruit]" ],
  "wesl3y:gomu_gears": [ "gears [skills5] [fruit]" ],
  "wesl3y:goro_skills": [ "[goro] [skills3] [fruit]" ],
  "wesl3y:goro2_skills": [ "[goro2] [skills5] [fruit]" ],
  "wesl3y:gura_skills": [ "[gura] [skills5] [fruit]" ],
  "wesl3y:hie_skills": [ "hie [skills5] [fruit]" ],
  "wesl3y:ito_skills": [ "[ito] [skills3] [fruit]" ],
  "wesl3y:ito2_skills": [ "[ito2] [skills5] [fruit]" ],
  "wesl3y:magu_skills": [ "magu [skills5] [fruit]" ],
  "wesl3y:mera_skills": [ "mera [skills5] [fruit]" ],
  "wesl3y:mochi_skills": [ "[mochi] [skills3] [fruit]" ],
  "wesl3y:mochi2_skills": [ "[mochi2] [skills5] [fruit]" ],
  "wesl3y:moku_skills": [ "moku [skills5] [fruit]" ],
  "wesl3y:neko_leopard_forms": [ "[leopard] [skills3] [fruit]" ],
  "wesl3y:neko_leopard_skills": [ "[leopard2] [skills3] [fruit]" ],
  "wesl3y:ope_skills": [ "[ope] [skills3] [fruit]" ],
  "wesl3y:ope2_skills": [ "[ope2] [skills5] [fruit]" ],
  "wesl3y:pika_skills": [ "pika [skills5] [fruit]" ],
  "wesl3y:smile_dragon_forms": [ "[smile_dragon] [skills5] [fruit]" ],
  "wesl3y:smile_dragon_skills": [ "[smile_dragon2] [skills5] [fruit]" ],
  "wesl3y:soru_skills": [ "[soru] [skills3] [fruit]" ],
  "wesl3y:soru2_skills": [ "[soru2] [skills5] [fruit]" ],
  "wesl3y:suke_skills": [ "[suke] [skills3] [fruit]" ],
  "wesl3y:suna_skills": [ "[suna] [skills5] [fruit]" ],
  "wesl3y:tori_phoenix_forms": [ "[phoenix] [skills3] [fruit]" ],
  "wesl3y:tori_phoenix_skills": [ "[phoenix2] [skills3] [fruit]" ],
  "wesl3y:uo_dragon_forms": [ "[dragon] [skills3] [fruit]" ],
  "wesl3y:uo_dragon_skills": [ "[dragon2] [skills5] [fruit]" ],
  "wesl3y:yami_skills": [ "[yami] [skills5] [fruit]" ],
  "wesl3y:zou_elephant_forms": [ "[elephant] [skills3] [fruit]" ],
  "wesl3y:zou_elephant_skills": [ "[elephant2] [skills3] [fruit]" ],
  
  
  "wesl3y:hakis": [ "[hakis] [skills3] [style]" ],
  "wesl3y:black_leg": [ "[black_leg] [skills5] [style]" ],
  //"wesl3y:punch_combat": [ "[punch_combat] [skills3] [style]" ],

  "wesl3y:enma": [ "[style] [enma]" ],
  "wesl3y:sticks_kama": [ "[sticks_kama] [skills3] [style]" ],
  "wesl3y:gryphon": [ "[gryphon] [skills5] [style]" ],
  "wesl3y:kanabo": [ "[kanabo] [skills3] [style]" ],
  //"wesl3y:katana": [ "[katana] [skills3] [style]" ],
  "wesl3y:kikoku": [ "[kikoku] [skills3] [style]" ],
  "wesl3y:kiribachi": [ "[kiribachi] [skills3] [style]" ],
  "wesl3y:mogura": [ "[mogura] [skills3] [style]" ],
  "wesl3y:murakumogiri": [ "[murakumogiri] [skills5] [style]" ],
  "wesl3y:sandai_kitetsu": [ "[style] [sandai_kitetsu]" ],
  "wesl3y:shusui": [ "[style] [shusui]" ],
  "wesl3y:yoru": [ "[yoru] [skills5] [style]" ],
  "wesl3y:yoru2": [ "[yoru2] [skills3] [style]" ]
}

const FULL = [
  "[selected.skill1]",
  "[selected.skill2]",
  "[selected.skill3]",
  "[selected.skill4]",
  "[selected.skill5]",
  "[selected.skill5]"
]

general.tick1(function(player) => {
  let text;
  const
	inventory = player.getComponent("inventory"),
	container = inventory.container,
	hand = container.getItem( player.selectedSlot ),
	itemCurrent = [ text ] = (hand?.typeId) in ITEMS ? ITEMS[ hand.typeId ] : [ "sla" ],
	itemoffCurrent = hand?.typeId == "wesl3y:enma" && player.hasTag("ame_no_habakiri") ? "[ame_habakiri] [skills3]" : hand?.typeId == "wesl3y:sandai_kitetsu" && player.hasTag("yubashiri") ? "[yubashiri] [skills3]" : hand?.typeId == "wesl3y:shusui" && player.hasTag("sandai_kitetsu") && player.hasTag("wado_ichimonji") ? "[sandai_kitetsu][wado_ichimonji] [skills5]" : "",
	skillCurrent = player.hasTag("item_fruit") ? FULL[ general.getScore("slotSkill", player) ] : FULL[ general.getScore("slotSkill2", player) ],
    cooldown1 = player.hasTag("item_fruit") ? `[empty.skill1_${Math.round(general.getScore("cooldown1", player) * 5 / general.getScore("cooldownmax1", player))}]` : player.hasTag("item_style") ? `[empty.skill1_${Math.round(general.getScore("2cooldown1", player) * 5 / general.getScore("2cooldownmax1", player))}]` : "",
    //cooldown1 = player.hasTag("item_fruit") && general.getScore("cooldown1", player) > 1 ? `[empty.skill1_${Math.round(general.getScore("cooldown1", player) * 5 / general.getScore("cooldownmax1", player))}]` : player.hasTag("item_style") && general.getScore("2cooldown1", player) > 1 ? `[empty.skill1_${Math.round(general.getScore("2cooldown1", player) * 5 / general.getScore("2cooldownmax1", player))}]` : "",
    cooldown2 = player.hasTag("item_fruit") ? `[empty.skill2_${Math.round(general.getScore("cooldown2", player) * 5 / general.getScore("cooldownmax2", player))}]` : player.hasTag("item_style") ? `[empty.skill2_${Math.round(general.getScore("2cooldown2", player) * 5 / general.getScore("2cooldownmax2", player))}]` : "",
    cooldown3 = player.hasTag("item_fruit") && general.getScore("cooldown3", player) > 1 ? `[empty.skill3_${Math.round(general.getScore("cooldown3", player) * 5 / general.getScore("cooldownmax3", player))}]` : player.hasTag("item_style") && general.getScore("2cooldown3", player) > 1 ? `[empty.skill3_${Math.round(general.getScore("2cooldown3", player) * 5 / general.getScore("2cooldownmax3", player))}]` : "",
    cooldown4 = player.hasTag("item_fruit") && general.getScore("cooldown4", player) > 1 ? `[empty.skill4_${Math.round(general.getScore("cooldown4", player) * 5 / general.getScore("cooldownmax4", player))}]` : player.hasTag("item_style") && general.getScore("2cooldown4", player) > 1 ? `[empty.skill4_${Math.round(general.getScore("2cooldown4", player) * 5 / general.getScore("2cooldownmax4", player))}]` : "",
    cooldown5 = player.hasTag("item_fruit") && general.getScore("cooldown5", player) > 1 ? `[empty.skill5_${Math.round(general.getScore("cooldown5", player) * 5 / general.getScore("cooldownmax5", player))}]` : player.hasTag("item_style") && general.getScore("2cooldown5", player) > 1 ? `[empty.skill5_${Math.round(general.getScore("2cooldown5", player) * 5 / general.getScore("2cooldownmax5", player))}]` : "",
    color_screen = player.hasTag("doa_door") ? "[color_green]" : player.hasTag("haki_observation") ? "[color_red_transparent]" : "",
    hakiKing = player.hasTag("haki_king") && general.getScore("hakiMaes", player) < 300 ? "[stKing]" : player.hasTag("haki_king") && general.getScore("hakiMaes", player) < 500 ? "[stKing2]" : player.hasTag("haki_king") ? "[stKing3]" : "",//Haki
    hakiArm = player.hasTag("haki_armament") && general.getScore("hakiMaes", player) < 150 ? "[stArmament]" : player.hasTag("haki_armament") && general.getScore("hakiMaes", player) < 350 ? "[stArmament2]" : player.hasTag("haki_armament") ? "[stArmament3]" : "",
    hakiObs = player.hasTag("haki_observation") && general.getScore("hakiMaes", player) < 250 ? "[stObservation]" : player.hasTag("haki_observation") && general.getScore("hakiMaes", player) < 350 ? "[stObservation2]" : player.hasTag("haki_observation") ? "[stObservation3]" : "",
    hits = general.getScore("hitTimer", player) >= 5 ? ` §l§r${Math.round(general.getScore("hitCur", player))}\nHITS\n§c${general.getScore("hitDamageCur", player) < 9 ? " " : ""}${Math.round(general.getScore("hitDamageCur", player))}` : "",
    kenbushoku = player.hasTag("haki_observation") ? `Dodges: ${general.getScore("hakiobs", player)}` : "",
    map = general.getScore("level", player) < 10 ? "[map:0]" : general.getScore("level", player) < 40 ? "[map:1]" : "[map:2]";
  player.onScreenDisplay.setActionBar(`  §lHP§r§f ${Math.round(player.getComponent("health")?.currentValue)}\n\n  §lST§r§f ${general.getScore("energyCur", player)}\n§lLevel§r§f ${general.getScore("level", player)}\nXp ${general.getScore("xpCur", player)}\n§lPoint§r§f ${general.getScore("point", player)}\n§lR$§r§f ${general.getScore("belly", player)}\n${kenbushoku}`);
  player.onScreenDisplay.setTitle(`\n\n\n\n${hits}\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n[${hand?.typeId == "wesl3y:map_eastblue" ? `${map}` : ""}:1][health${Math.round(player.getComponent("health")?.currentValue * 10 / player.getComponent("health")?.defaultValue)}] [energy${Math.round(general.getScore("energyCur", player) * 10 / general.getScore("energyMax", player))}] [xp${Math.round(general.getScore("xpCur", player) * 10 / general.getScore("xpMax", player))}] ${hakiArm}${hakiKing}${hakiObs}${color_screen}\n${itemCurrent}${itemoffCurrent}${skillCurrent}\n${cooldown1}${cooldown2}${cooldown3}${cooldown4}${cooldown5}`);
  player.onScreenDisplay.updateSubtitle(`${hand && player.hasTag('item_fruit') ? `Maestria: ${general.getScore("fruitMaes", player)}` : hand && player.hasTag('item_style') ? `Maestria: ${hand?.typeId == "wesl3y:hakis" ? general.getScore("hakiMaes", player) : general.getScore("styleMaes", player)}` : ""}`);
});