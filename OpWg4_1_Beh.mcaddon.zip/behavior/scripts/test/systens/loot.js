import * as mc from "@minecraft/server";
import * as general from "../general.js";

general.tick5(function(player) {
  loot(player, "gin", general.random(0, 50),[])
  loot(player, "sanji", general.random(0, 60), [
    {
      id: "minecraft:air",
      name: "Air",
      porcent: 0,
      porcent: [0, 200],
      quantity: 0
    },
    {
      id: "wesl3y:cigarette",
      name: "Cigarette",
      porcent: [0, 1],
      quantity: 1
    }
  ])
  loot(player, "don_krieg", general.random(0, 125), [
    {
      id: "minecraft:air",
      name: "Air",
      porcent: 0,
      porcent: [0, 300],
      quantity: 0
    },
    {
      id: "wesl3y:golden_armor",
      name: "Golden Armor",
      porcent: [0, 1],
      quantity: 1
    }
  ])
  loot(player, "chew", general.random(0, 150),[])
  loot(player, "kuroobi", general.random(0, 185),[])
  loot(player, "arlong", general.random(0, 225),[])
  loot(player, "buggy", general.random(25, 50), [
    {
      id: "minecraft:air",
      name: "Air",
      porcent: 0,
      porcent: [0, 300],
      quantity: 0
    },
    {
      id: "wesl3y:buggy_haori",
      name: "Buggy Haori",
      porcent: [0, 1],
      quantity: 1
    }
  ])
});

function loot(player, name, xp, arrayItems) {

  if (player.hasTag(`loot.${name}`)) {
    player.removeTag(`loot.${name}`);
    player.runCommandAsync(`scoreboard players add @s xpCur ${xp}`);
    randomItem(player, arrayItems)
  }
}

function randomItem(player, array) {
  const random = general.random(0, 100)
  for (let i = 0; i <= (array.length - 1); i++) {
    if (random >= array[i].porcent[0] && random <= array[i].porcent[1]) {
      player.runCommandAsync(`give @s ${array[i].id} ${array[i].quantity} 0`)
      player.playSound(`random.pop`)
      if (array[i].name != "Air") general.tell(player, `§eItem Drop <${array[i].name}>`)
    }
  }
}