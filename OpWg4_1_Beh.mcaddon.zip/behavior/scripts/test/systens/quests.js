import * as mc from "@minecraft/server";
import * as q from "../quest_list.js";
import * as general from "../general.js";

general.tick5(function(player) => {
  for (const player of mc.world.getPlayers({ tags: ["start_mission"] })) {
    const quest = q.QUEST.list[general.getScore("mission", player)];
    player.removeTag("start_mission");
    if (!player.hasTag("in_mission")) {
      player.runCommandAsync(`tellraw @s[scores={level=!${quest.levelmin}..${quest.levelmax}}]{"rawtext":[{"text": "§c"},{"translate": "text.requires"},{"text": "Level ${quest.levelmin}..${quest.levelmax}§f"}]}`);
      player.runCommandAsync(`tag @s[scores={level=${quest.levelmin}..${quest.levelmax}}] add in_mission`);
      player.runCommandAsync(`tellraw @s[scores={level=${quest.levelmin}..${quest.levelmax}}] {"rawtext":[{"text": "§a"},{"translate": "mission.start"},{"text": "§f\n"},{"translate": "${quest.text}"}]}`);
      if (quest.summon) {
        player.runCommandAsync(`execute at @s[scores={level=${quest.levelmin}..${quest.levelmax}}] run summon ${quest.enemies} ~-6~~ ~~ minecraft:entity_spawned`);
      }
      if (general.getScore("level", player) >= quest.levelmin && general.getScore("level", player) <= quest.levelmax) inMission(player, quest);
    } else {
      inMission(player, quest);
      player.runCommandAsync(`tellraw @s[scores={level=!${quest.levelmin}..${quest.levelmax}}]{"rawtext":[{"text": "§c"},{"translate": "text.requires"},{"text": "Level ${quest.levelmin}..${quest.levelmax}§f"}]}`);
      player.runCommandAsync(`tellraw @s[tag=in_mission,scores={level=${quest.levelmin}..${quest.levelmax}}]{"rawtext":[{"translate": "mission.in"},{"text": ": §e"},{"translate": "${quest.text}"},{"text": "§f"}]}`);
      if (quest.summon) {
        player.runCommandAsync(`execute at @s[tag=in_mission,scores={level=${quest.levelmin}..${quest.levelmax}}] unless entity @e[type=${quest.enemies}] run summon ${quest.enemies} ~-6~~2 ~~ minecraft:entity_spawned`);
      }
      player.runCommandAsync(`tag @s[scores={level=!${quest.levelmin}..${quest.levelmax}}] remove in_mission`);
    }
    if (player.hasTag("finish_mission")) finishMission(player, quest);
  }
});

function inMission(player, quest) {
  let objective = [...quest.enemies];
  mc.world.afterEvents.entityHurt.subscribe(data => {
    try {
      if (data.damageSource?.damagingEntity === player) {
        for (let index = 0; index < objective.length; index++) {
          if (objective[index] === data.hurtEntity.typeId) {
            if (data.hurtEntity.getComponent("minecraft:health")?.currentValue <= 0) {
              objective.splice(index, 1);
              if (player.hasTag("in_mission") && !objective.length) return finishMission(player, quest); break;
            }
          }
        }
      }
    }
    catch (error) { }
  });
}

function finishMission(player, quest) {
  player.removeTag("finish_mission");
  player.removeTag("in_mission");
  player.runCommandAsync(`tellraw @s {"rawtext":[{"text": "§e<"},{"translate": "mission.complete"},{"text": ">\n§f"},{"translate": "mission.earned"},{"text": " §a${quest.belly}\n§f"},{"translate": "mission.earned"},{"text": " §e${quest.xp} Exp.§f"}]}`);
  player.runCommandAsync(`scoreboard players reset @s mission`);
  player.runCommandAsync(`scoreboard players add @s belly ${quest.belly}`);
  player.runCommandAsync(`scoreboard players add @s xpCur ${player.hasTag("human") && general.getScore("level", player) <= 19 ? quest.xp * 1.5 : quest.xp}`);
  player.runCommandAsync(`scoreboard players add @s point ${quest.point}`);
}