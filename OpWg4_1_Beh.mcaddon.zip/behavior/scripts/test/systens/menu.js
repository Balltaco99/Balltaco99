import * as mc from "@minecraft/server";
import * as ui from "@minecraft/server-ui";
import * as general from "../general.js";

export function custom(player) {
  player.addTag("custom2");
  const form = new ui.ActionFormData();
  form.title("Start");
  form.body(`§bOne Piece Wg Versão Survival§r\nExplore o mundo de One Piece no Minecraft, procure navios, casas e até ilhas no céu... derrote inimigos e crie uma tripulação, seja o mais livre, aquele que terá o maior Tesouro do Mundo... O One Piece.`);
  form.button("");
  form.button("");
  form.show(player).then((r) => {
    if (r.canceled) {
      custom(player);
    }
    if (r.selection === 0) {
      player.runCommandAsync("event entity @s wesl3y:random_race");
      player.runCommandAsync(`tellraw @s {"rawtext":[{"text":"§cDefeat pirates, sailors and level up to level 10"}]}`);
      player.addTag("custom");
      player.removeTag("custom2");
      player.addTag("pirate");
      player.removeTag("bounty_hunter");
      player.removeTag("marine");
      player.removeTag("revolutionary");
    }
    if (r.selection === 1) {
      player.runCommandAsync("event entity @s wesl3y:random_race");
      player.runCommandAsync(`tellraw @s {"rawtext":[{"text":"§cDefeat pirates, sailors and level up to level 10"}]}`);
      player.addTag("custom");
      player.removeTag("custom2");
      player.addTag("marine");
      player.removeTag("bounty_hunter");
      player.removeTag("pirate");
      player.removeTag("revolutionary");
    }
  }
);}

mc.world.beforeEvents.itemUse.subscribe(data => {
  let { itemStack, source } = data
  const plr = data.source
  if (itemStack.typeId == "wesl3y:menu") {
    mc.system.run(() => {
      menu(plr);
    })
  }
});

function menu(player) {
  const form = new ui.ActionFormData();
  form.title("Menu");
  form.body(`§eName:§f ${player.nameTag}\n§eFaction:§f ${player.hasTag("pirate") ? "Pirate" : player.hasTag("marine") ? "Marine" : ""}\n§eRace:§f ${player.hasTag("fishman") ? "Fishman" : player.hasTag("mink") ? "Fishman" : player.hasTag("lunarian") ? "Lunarian" : "Human"}\n§eRank:§f ${player.hasTag("haki_killer") ? "§cHaki Killer§r" : player.hasTag("best_swordsman") ? "Best Swordman" : player.hasTag("strongest_man") ? "Strongest Man" : player.hasTag("strongest_creature") ? "Strongest Creature" : "null"}\n\n${player.hasTag("pirate") ? "§7Mostre ao mundo quem será o pirata mais forte." : "§7Torne-se um Almirante e mostre a verdadeira Justiça."}\n${player.hasTag("pirate") ? "§7Show the world who will be the strongest pirate." : "§7Become an Admiral and show true justice."}`);
  form.button("");//Status
  form.button("");//Achievements
  form.button("");//Configurations
  form.show(player).then((r) => {
    if (r.selection === 0) {
      menu_status(player);
    }
    if (r.selection === 1) {
      menu_achievements(player);
    }
    if (r.selection === 2) {
      menu_config(player);
    }
  });
}
  
function menu_status(player) {
  const form = new ui.ActionFormData();
  form.title("Status");
  form.body(`§f${general.number(general.getScore("point", player))}§7\n\n                  ${general.getScore("healthStats", player) < 9 ? " " : ""}§fLv§r.${general.getScore("healthStats", player)}\n                  ${general.getScore("energyStats", player) < 9 ? " " : ""}§fLv§r.${general.getScore("energyStats", player)}\n                  ${general.getScore("fruitMaes", player) < 9 ? " " : ""}§fLv§r.${general.getScore("fruitMaes", player)}\n                  ${general.getScore("styleMaes", player) < 9 ? " " : ""}§fLv§r.${general.getScore("styleMaes", player)}\n                  ${general.getScore("hakiMaes", player) < 9 ? " " : ""}§fLv§r.${general.getScore("hakiMaes", player)}`);
  form.button("§0+");
  form.button("§0+");
  form.button("§0+");
  form.button("§0+");
  form.button("§0+");
  form.show(player).then((r) => {
    if (r.selection === 0) {
      if (general.getScore("healthStats", player) <= 99 && general.getScore("point", player) >= 1) {
        player.runCommandAsync("scoreboard players add @s healthStats 1");
        player.runCommandAsync("scoreboard players remove @s point 1");
        player.runCommandAsync("tag @s add update_stats");
        menu(player);
      } else player.runCommandAsync(`tellraw @s[scores={healthStats=!200..}] {"rawtext": [{"text":"§c"},{"translate":"text.requires"},{"text": "1 Point"}]}`);
    }
    if (r.selection === 1) {
      if (general.getScore("energyStats", player) <= 99 && general.getScore("point", player) >= 1) {
        player.runCommandAsync("scoreboard players add @s energyStats 1");
        player.runCommandAsync("scoreboard players remove @s point 1");
        player.runCommandAsync("tag @s add update_stats");
        menu(player);
      } else player.runCommandAsync(`tellraw @s[scores={energyStats=!100..}] {"rawtext": [{"text":"§c"},{"translate":"text.requires"},{"text": "1 Point"}]}`);
    }
    if (r.selection === 2) {
      if (general.getScore("fruitMaes", player) <= 599 && general.getScore("point", player) >= 1) {
        player.runCommandAsync("scoreboard players add @s fruitMaes 1");
        player.runCommandAsync("scoreboard players remove @s point 1");
        player.runCommandAsync("tag @s add update_stats");
        menu(player);
      } else player.runCommandAsync(`tellraw @s[scores={fruitMaes=!600..}] {"rawtext": [{"text":"§c"},{"translate":"text.requires"},{"text": "1 Point"}]}`);
    }
    if (r.selection === 3) {
      if (general.getScore("styleMaes", player) <= 599 && general.getScore("point", player) >= 1) {
        player.runCommandAsync("scoreboard players add @s styleMaes 1");
        player.runCommandAsync("scoreboard players remove @s point 1");
        player.runCommandAsync("tag @s add update_stats");
        menu(player);
      } else player.runCommandAsync(`tellraw @s[scores={styleMaes=!600..}] {"rawtext": [{"text":"§c"},{"translate":"text.requires"},{"text": "1 Point"}]}`);
    }
    if (r.selection === 4) {
      if (general.getScore("hakiMaes", player) <= 599 && general.getScore("point", player) >= 1) {
        player.runCommandAsync("scoreboard players add @s hakiMaes 1");
        player.runCommandAsync("scoreboard players remove @s point 1");
        player.runCommandAsync("tag @s add update_stats");
        menu(player);
      } else player.runCommandAsync(`tellraw @s[scores={hakiMaes=!600..}] {"rawtext": [{"text":"§c"},{"translate":"text.requires"},{"text": "1 Point"}]}`);
    }
  }
);}
  
function menu_achievements(player) {
  const form = new ui.ActionFormData();
  form.title("Achievements");
  form.body(`§r• Use Punch Combat to defeat enemies if you don't have a sword\n§r• Up "Style" to deal more damage on hit\n§r• Up haki 35 to awaken Armament haki\n§r• Up haki 70 to awaken observation haki\n§r• Find chests in Baratie or Arlong Park`);
  form.button("§0<");
  form.button("§0Pt");
  form.show(player).then((r) => {
    if (r.selection === 0) {
      menu(player);
    }
    if (r.selection === 1) {
      menu_achievements2(player);
    }
  }
);}
  
function menu_achievements2(player) {
  const form = new ui.ActionFormData();
  form.title("Achievements");
  form.body(`§r• Use Punch Combat para derrotar os inimigos se você não tiver uma espada\n§r• Aumente o "Estilo" para causar mais dano ao acertar\n§r• Suba o haki 35 para despertar o Haki do Armamento\n§r• Suba o haki 70 para despertar o Haki da Observação\n§r• Encontre baús em Baratie ou Arlong Park`);
  form.button("§0<");
  form.button("§0Eng");
  form.show(player).then((r) => {
    if (r.selection === 0) {
      menu(player);
    }
    if (r.selection === 1) {
      menu_achievements(player);
    }
  }
);}

function menu_achievements3(player) {
  const form = new ui.ActionFormData();
  form.title("Achievements");
  form.body(`§r• Defeat ${player.hasTag("achi.luffy") ? "§aLuffy" : "§cLuffy"}\n§r• Defeat ${player.hasTag("achi.katakuri") ? "§aKatakuri" : "§cKatakuri"}\n§r• Defeat ${player.hasTag("achi.shanks") ? "§aShanks" : "§cShanks"}\n§r• Item ${player.hasTag("achi.cigarette") ? "§aCigarette Sanji" : "§cCigarette Sanji"}\n§r• Level ${general.getScore("level", player) >= 200 ? "§a200" : "§c200"}`);
  form.button("§0<");
  form.show(player).then((r) => {
    if (r.selection === 0) {
      menu(player);
    }
  }
);}

function menu_config(player) {
  const form = new ui.ActionFormData();
  form.title("Config");
  form.body(`§rFire Faction: ${player.hasTag("fire_faction") ? "§aOn": "§cOff"}\n§rFruit Skill change: ${general.getScore("changeskill", player) == 0 ? "§aShift": "§aClick"}\n§rStyle Skill change: ${general.getScore("changeskill2", player) == 0 ? "§aShift": "§aClick"}\n§rCamera mode: ${player.hasTag("camera_mode") ? "§aOn": "§cOff"}`);
  form.button("§0x");
  form.button("§0x");
  form.button("§0x");
  form.button("§0x");
  form.show(player).then((r) => {
    if (r.selection === 0) {
      if (player.hasTag("fire_faction")) {
        player.runCommandAsync("tag @s remove fire_faction");
      } else player.runCommandAsync("tag @s add fire_faction");
    }
    if (r.selection === 1) {
      if (general.getScore("changeskill", player) == 0) {
        player.runCommandAsync("scoreboard players set @s changeskill 1");
      } else player.runCommandAsync("scoreboard players set @s changeskill 0");
    }
    if (r.selection === 2) {
      if (general.getScore("changeskill2", player) == 0) {
        player.runCommandAsync("scoreboard players set @s changeskill2 1");
      } else player.runCommandAsync("scoreboard players set @s changeskill2 0");
    }
    if (r.selection === 3) {
      if (player.hasTag("camera_mode")) {
        player.runCommandAsync("tag @s remove camera_mode");
      } else player.runCommandAsync("tag @s add camera_mode");
    }
  }
);}

mc.world.afterEvents.entityHitEntity.subscribe(data => {
  let hit = data.hitEntity;
  let player = data.damagingEntity;
  if(!hit || hit?.typeId != "wesl3y:npc" || player.typeId != "minecraft:player") return;
  if(player?.typeId == "minecraft:player" && hit?.typeId == "wesl3y:npc") {
    const tag = hit.hasTag("wg_baratie") ? "wg_baratie" : hit.hasTag("wg_arlong") ? "wg_arlong" : hit.hasTag("baratie") ? "baratie" : hit.hasTag("arlong_park") ? "arlong_park" : hit.hasTag("loguetown") ? "loguetown" : "";
    switch (tag) {
      case "wg_baratie":
        wg_baratie(player);
      break
      case "wg_arlong":
        wg_arlong(player);
      break
      case "baratie":
        baratie1(player);
      break
      case "arlong_park":
        arlong_park1(player);
      break
    }
  }
});

function wg_baratie(player) {
  const form = new ui.ActionFormData();
  form.title("Shop");
  form.body(`O que deseja?`);
  form.button(`§f5 Salmon\nPrice: ${general.getScore("belly", player) >= 75 ? "§a75" : "§c75"}`);
  form.button(`§f3 Bread\nPrice: ${general.getScore("belly", player) >= 100 ? "§a100" : "§c100"}`);
  form.button(`§f1 Golden Key\nPrice: ${general.getScore("belly", player) >= 300 ? "§a300" : "§c300"}`);
  form.button("back");
  form.show(player).then((r) => {
    if (r.selection === 0) {
      if (general.getScore("belly", player) >= 75) {
        player.runCommandAsync("give @s cooked_salmon 5");
        player.runCommandAsync("scoreboard players remove @s belly 75");
      } else player.runCommandAsync(`tellraw @s {"rawtext": [{"text": "§c"}, {"translate": "text.requires"}, {"text": " 75 belly"}]}`);
    }
    if (r.selection === 1) {
      if (general.getScore("belly", player) >= 100) {
        player.runCommandAsync("give @s bread 3");
        player.runCommandAsync("scoreboard players remove @s belly 100");
      } else player.runCommandAsync(`tellraw @s {"rawtext": [{"text": "§c"}, {"translate": "text.requires"}, {"text": " 100 belly"}]}`);
    }
    if (r.selection === 2) {
      if (general.getScore("belly", player) >= 300) {
        player.runCommandAsync("give @s wesl3y:key_chest 1");
        player.runCommandAsync("scoreboard players remove @s belly 300");
      } else player.runCommandAsync(`tellraw @s {"rawtext": [{"text": "§c"}, {"translate": "text.requires"}, {"text": " 300 belly"}]}`);
    }
  }
);}

function wg_arlong(player) {
  const form = new ui.ActionFormData();
  form.title("Shop");
  form.body(`O que deseja?`);
  form.button(`§f1 Pirate Haori\nPrice: ${general.getScore("belly", player) >= 500 ? "§a500" : "§c500"}`);
  form.button(`§f1 Katana\nPrice: ${general.getScore("belly", player) >= 300 ? "§a300" : "§c300"}`);
  form.button(`§f1 Golden Apple\nPrice: ${general.getScore("belly", player) >= 150 ? "§a150" : "§c150"}`);
  form.button(`§f1 Sake\nPrice: ${general.getScore("belly", player) >= 300 ? "§a300" : "§c300"}`);
  form.show(player).then((r) => {
    if (r.selection === 0) {
      if (general.getScore("belly", player) >= 500) {
        player.runCommandAsync("give @s wesl3y:pirate_haori 1");
        player.runCommandAsync("scoreboard players remove @s belly 500");
      } else player.runCommandAsync(`tellraw @s {"rawtext": [{"text": "§c"}, {"translate": "text.requires"}, {"text": " 500 belly"}]}`);
    }
    if (r.selection === 1) {
      if (general.getScore("belly", player) >= 300) {
        player.runCommandAsync("give @s wesl3y:katana 1");
        player.runCommandAsync("scoreboard players remove @s belly 300");
      } else player.runCommandAsync(`tellraw @s {"rawtext": [{"text": "§c"}, {"translate": "text.requires"}, {"text": " 300 belly"}]}`);
    }
    if (r.selection === 2) {
      if (general.getScore("belly", player) >= 150) {
        player.runCommandAsync("give @s golden_apple 1");
        player.runCommandAsync("scoreboard players remove @s belly 150");
      } else player.runCommandAsync(`tellraw @s {"rawtext": [{"text": "§c"}, {"translate": "text.requires"}, {"text": " 150 belly"}]}`);
    }
    if (r.selection === 3) {
      if (general.getScore("belly", player) >= 300) {
        player.runCommandAsync("give @s wesl3y:sake 1");
        player.runCommandAsync("scoreboard players remove @s belly 300");
      } else player.runCommandAsync(`tellraw @s {"rawtext": [{"text": "§c"}, {"translate": "text.requires"}, {"text": " 300 belly"}]}`);
    }
  }
);}

function baratie1(player) {
  const form = new ui.ActionFormData();
  form.title("Mission");
  form.body(`             Quest Gin\n\nLevel Required: 10\nEi garoto(a), estou dando uma recompensa para quem derrotar o Gin, aquele mendigo comeu sem pagar.\nReward:\n§a$56\n§e28 Exp.`);
  form.button("Gin");
  form.button("Sanji");
  form.button("Don Krieg");
  form.button("Esquecer");
  form.button("Confirm");
  form.show(player).then((r) => {
    if (r.selection === 0) {
      baratie1(player);
    }
    if (r.selection === 1) {
      baratie2(player);
    }
    if (r.selection === 2) {
      baratie3(player);
    }
    if (r.selection === 3) {}
    if (r.selection === 4) {
      player.runCommandAsync("scoreboard players set @s[tag=!in_mission] mission 0");
      player.runCommandAsync("tag @s add start_mission");
    }
  }
);}

function baratie2(player) {
  const form = new ui.ActionFormData();
  form.title("Mission");
  form.body(`             Quest Sanji\n\nLevel Required: 20\nEi garoto(a), estou dando uma recompensa para quem derrotar o Sanji, ele deu comida de graça para um mendigo.\nReward:\n§a$68\n§e34 Exp.`);
  form.button("Gin");
  form.button("Sanji");
  form.button("Don Krieg");
  form.button("Esquecer");
  form.button("Confirm");
  form.show(player).then((r) => {
    if (r.selection === 0) {
      baratie1(player);
    }
    if (r.selection === 1) {
      baratie2(player);
    }
    if (r.selection === 2) {
      baratie3(player);
    }
    if (r.selection === 3) {}
    if (r.selection === 4) {
      player.runCommandAsync("scoreboard players set @s[tag=!in_mission] mission 1");
      player.runCommandAsync("tag @s add start_mission");
    }
  }
);}

function baratie3(player) {
  const form = new ui.ActionFormData();
  form.title("Mission");
  form.body(`             Quest Don Krieg\n\nLevel Required: 30\nEi garoto(a), estou dando uma recompensa para quem derrotar o Don Krieg, maldito pirata.\nReward:\n§a$80\n§e40 Exp.`);
  form.button("Gin");
  form.button("Sanji");
  form.button("Don Krieg");
  form.button("Esquecer");
  form.button("Confirm");
  form.show(player).then((r) => {
    if (r.selection === 0) {
      baratie1(player);
    }
    if (r.selection === 1) {
      baratie2(player);
    }
    if (r.selection === 2) {
      baratie3(player);
    }
    if (r.selection === 3) {}
    if (r.selection === 4) {
      player.runCommandAsync("scoreboard players set @s[tag=!in_mission] mission 2");
      player.runCommandAsync("tag @s add start_mission");
    }
  }
);}

function arlong_park1(player) {
  const form = new ui.ActionFormData();
  form.title("Mission");
  form.body(`             Quest Chew\n\nLevel Required: 40\nEi garoto(a), se derrotar o Chew um dos piratas do Arlong, irei te recompensar.\nReward:\n§a$96\n§e48 Exp.`);
  form.button("Chew");
  form.button("Kuroobi");
  form.button("Arlong");
  form.button("Esquecer");
  form.button("Confirm");
  form.show(player).then((r) => {
    if (r.selection === 0) {
      arlong_park1(player);
    }
    if (r.selection === 1) {
      arlong_park2(player);
    }
    if (r.selection === 2) {
      arlong_park3(player);
    }
    if (r.selection === 3) {}
    if (r.selection === 4) {
      player.runCommandAsync("scoreboard players set @s[tag=!in_mission] mission 3");
      player.runCommandAsync("tag @s add start_mission");
    }
  }
);}

function arlong_park2(player) {
  const form = new ui.ActionFormData();
  form.title("Mission");
  form.body(`             Quest Kuroobi\n\nLevel Required: 50\nEi garoto(a), se derrotar o Chew um dos piratas do Arlong, irei te recompensar.\nReward:\n§a$108\n§e54 Exp.`);
  form.button("Chew");
  form.button("Kuroobi");
  form.button("Arlong");
  form.button("Esquecer");
  form.button("Confirm");
  form.show(player).then((r) => {
    if (r.selection === 0) {
      arlong_park1(player);
    }
    if (r.selection === 1) {
      arlong_park2(player);
    }
    if (r.selection === 2) {
      arlong_park3(player);
    }
    if (r.selection === 3) {}
    if (r.selection === 4) {
      player.runCommandAsync("scoreboard players set @s[tag=!in_mission] mission 4");
      player.runCommandAsync("tag @s add start_mission");
    }
  }
);}

function arlong_park3(player) {
  const form = new ui.ActionFormData();
  form.title("Mission");
  form.body(`             Quest Arlong\n\nLevel Required: 60\nEi garoto(a), se derrotar o Chew um dos piratas do Arlong, irei te recompensar.\nReward:\n§a$120\n§e60 Exp.`);
  form.button("Chew");
  form.button("Kuroobi");
  form.button("Arlong");
  form.button("Esquecer");
  form.button("Confirm");
  form.show(player).then((r) => {
    if (r.selection === 0) {
      arlong_park1(player);
    }
    if (r.selection === 1) {
      arlong_park2(player);
    }
    if (r.selection === 2) {
      arlong_park3(player);
    }
    if (r.selection === 3) {}
    if (r.selection === 4) {
      player.runCommandAsync("scoreboard players set @s[tag=!in_mission] mission 5");
      player.runCommandAsync("tag @s add start_mission");
    }
  }
);}