import * as mc from "@minecraft/server";

mc.world.afterEvents.entityHurt.subscribe(data => {
  const
    hurt = data.hurtEntity,
    damage = data.damage,
    damaging = data.damageSource.damagingEntity;
  if (hurt === undefined || data.damageSource.damagingEntity === undefined) { return; }
  if (damaging.typeId == "minecraft:player") {
    hurt.runCommandAsync("particle wesl3y:blood_splash ~~1~");
    damaging.runCommandAsync(`scoreboard players set @s hitTimer 12`);
    damaging.runCommandAsync(`scoreboard players add @s hitDamageCur ${Math.round(damage)}`);
    damaging.runCommandAsync(`scoreboard players add @s hitCur 1`);
  }
  if (hurt.typeId == "minecraft:player") {
    hurt.runCommandAsync("scoreboard players set @s[scores={hurtCur=..9}] hurtCur 9");
  }
  if (damaging.hasTag("attack_stunned")) {
    hurt.runCommandAsync("tp @s ~~~");
  }/*
  if (hurt?.typeId != "minecraft:player") return;
  hurt.vida = hurt.vida - Math.round(damage);
  hurt.getComponent("health")?.setCurrentValue(hurt.getComponent("health")?.defaultValue);*/
});