import * as mc from "@minecraft/server";
import * as ui from "@minecraft/server-ui";

export function addScore(objective) { mc.world.scoreboard.addObjective(objective, objective); }

export function getScore(objective, player) { try { return mc.world.scoreboard.getObjective(objective).getScore(player.scoreboardIdentity); } catch (error) { return 0; } }

export const overworld = mc.world.getDimension("overworld"), nether = mc.world.getDimension("nether"), theEnd = mc.world.getDimension("the end");

export function number(value) { const ranges = [ { divider: 1e9, suffix: "b" }, { divider: 1e6, suffix: "m" }, { divider: 1e3, suffix: "k" }, ]; for (const range of ranges) if (value >= range.divider) return ((value / range.divider).toFixed(1) + range.suffix).toString(); return value; }

export function tick1(callback) { mc.system.runInterval((data) => { for (const player of mc.world.getPlayers()) { callback(player); } }, 1); }

export function tick5(callback) { mc.system.runInterval((data) => { for (const player of mc.world.getPlayers()) { callback(player); } }, 5); }

export function tick10(callback) { mc.system.runInterval((data) => { for (const player of mc.world.getPlayers()) { callback(player); } }, 10); }

export function random(min, max) { return Math.floor(Math.random() * (max - min + 1)) + min; }