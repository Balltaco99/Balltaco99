import * as general from "./general.js";

export const QUEST = {
  list: [
/*  {
      belly: dobro do xp
      levelmin: voce escolhe
      levelmax: voce escolhe
      point: 1 ou 2
      reward: raiz quadrada da recompensa vdd
      text: "mission."
      xp: dobro da raiz quadrada da vida +10(se tiver drop)
      enemies: [
        "wesl3y:"
      ]
    },*/
    {
      belly: 56,
      levelmin: 10,
      levelmax: 40,
      summon: true,
      point: 1,
      reward: 0,
      text: "mission.gin",
      xp: 28,
      enemies: [
        "wesl3y:gin"
      ]
    },
    {
      belly: 68,
      levelmin: 20,
      levelmax: 40,
      summon: true,
      point: 2,
      reward: 0,
      text: "mission.sanji",
      xp: 34,
      enemies: [
        "wesl3y:sanji"
      ]
    },
    {
      belly: 80,
      levelmin: 30,
      levelmax: 40,
      summon: true,
      point: 3,
      reward: 0,
      text: "mission.don_krieg",
      xp: 40,
      enemies: [
        "wesl3y:don_krieg"
      ]
    },
    {
      belly: 96,
      levelmin: 40,
      levelmax: 200,
      summon: true,
      point: 1,
      reward: 0,
      text: "mission.chew",
      xp: 48,
      enemies: [
        "wesl3y:chew"
      ]
    },
    {
      belly: 108,
      levelmin: 50,
      levelmax: 200,
      summon: true,
      point: 2,
      reward: 0,
      text: "mission.kuroobi",
      xp: 54,
      enemies: [
        "wesl3y:kuroobi"
      ]
    },
    {
      belly: 120,
      levelmin: 60,
      levelmax: 200,
      summon: true,
      point: 3,
      reward: 0,
      text: "mission.arlong",
      xp: 60,
      enemies: [
        "wesl3y:arlong"
      ]
    }
  ]
};