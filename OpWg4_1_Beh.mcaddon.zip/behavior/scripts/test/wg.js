import "./modules.js";
import "./systens/attack.js";
import "./systens/chat.js";
import "./systens/commands.js";
import "./systens/quests.js";
import "./systens/titles.js";
import "./systens/loot.js";