import * as mc from '@minecraft/server';
import * as system from '@minecraft/server';
import * as ui from '@minecraft/server-ui';

system.system.runInterval(() => {
  for (const player of mc.world.getPlayers()) {
    if (player.hasTag("orochi_menu")) {
      orochi_menu(player);
      player.removeTag("orochi_menu");
    }
    if (player.hasTag("tenten_menu")) {
      tenten_menu(player);
      player.removeTag("tenten_menu");
    }
  }
}, 1);

function orochi_menu(player) {
  const form = new ui.ActionFormData();
  form.title("Orochimaru");
  form.button("Curse Mark\n§e600 Tp");
  form.button("Sennin Frogs\n§e1000 Tp");
  form.show(player).then((r) => {
    player.removeTag("orochi_menu");
    if (r.selection === 0) {
      player.runCommandAsync("tellraw @s[scores={tp=!600..}] {\"rawtext\":[{\"text\":\"§cRequires 600 Tp\"}]}");
      player.runCommandAsync("give @s[scores={tp=600..}] wesl3y:curse_mark1");
      player.runCommandAsync("tellraw @s[scores={tp=600..}] {\"rawtext\":[{\"text\":\"§aYou learned the Curse Mark\"}]}");
      player.runCommandAsync("scoreboard players remove @s[scores={tp=600..}] tp 600");
      player.removeTag("orochi_menu");
    }
    if (r.selection === 1) {
      player.runCommandAsync("tellraw @s[scores={tp=!1000..}] {\"rawtext\":[{\"text\":\"§cRequires 1000 Tp\"}]}");
      player.runCommandAsync("give @s[scores={tp=1000..}] wesl3y:sennin_snakes");
      player.runCommandAsync("tellraw @s[scores={tp=100..}] {\"rawtext\":[{\"text\":\"§aYou learned the Snakes Sennin Mode\"}]}");
      player.runCommandAsync("scoreboard players remove @s[scores={tp=1000..}] tp 1000");
      player.removeTag("orochi_menu");
    }
  }
);}

function tenten_menu(player) {
  const form = new ui.ActionFormData();
  form.title("Tenten");
  form.button("Kubikiribocho\n§e400 Tp");
  form.button("Kusanagi\n§e200 Tp");
  form.button("Scythe\n§e500 Tp");
  form.button("Suit Naruto\n§e100 Tp");
  form.button("Suit Neji\n§e100 Tp");
  form.button("Suit Otsutsuki\n§e400 Tp");
  form.button("Suit Rocklee\n§e200 Tp");
  form.button("Suit Sasuke\n§e100 Tp");
  form.show(player).then((r) => {
    player.removeTag("tenten_menu");
    if (r.selection === 0) {
      player.runCommandAsync("tellraw @s[scores={tp=!400..}] {\"rawtext\":[{\"text\":\"§cRequires 400 Tp\"}]}");
      player.runCommandAsync("give @s[scores={tp=400..}] wesl3y:kubikiribocho");
      player.runCommandAsync("scoreboard players remove @s[scores={tp=400..}] tp 400");
      player.removeTag("tenten_menu");
    }
    if (r.selection === 1) {
      player.runCommandAsync("tellraw @s[scores={tp=!200..}] {\"rawtext\":[{\"text\":\"§cRequires 200 Tp\"}]}");
      player.runCommandAsync("give @s[scores={tp=200..}] wesl3y:kusanagi");
      player.runCommandAsync("scoreboard players remove @s[scores={tp=200..}] tp 200");
      player.removeTag("tenten_menu");
    }
    if (r.selection === 2) {
      player.runCommandAsync("tellraw @s[scores={tp=!500..}] {\"rawtext\":[{\"text\":\"§cRequires 500 Tp\"}]}");
      player.runCommandAsync("give @s[scores={tp=500..}] wesl3y:scythe");
      player.runCommandAsync("scoreboard players remove @s[scores={tp=500..}] tp 500");
      player.removeTag("tenten_menu");
    }
    if (r.selection === 3) {
      player.runCommandAsync("tellraw @s[scores={tp=!100..}] {\"rawtext\":[{\"text\":\"§cRequires 100 Tp\"}]}");
      player.runCommandAsync("give @s[scores={tp=100..}] wesl3y:suit_naruto");
      player.runCommandAsync("scoreboard players remove @s[scores={tp=100..}] tp 100");
      player.removeTag("tenten_menu");
    }
    if (r.selection === 4) {
      player.runCommandAsync("tellraw @s[scores={tp=!100..}] {\"rawtext\":[{\"text\":\"§cRequires 100 Tp\"}]}");
      player.runCommandAsync("give @s[scores={tp=100..}] wesl3y:suit_neji");
      player.runCommandAsync("scoreboard players remove @s[scores={tp=100..}] tp 100");
      player.removeTag("tenten_menu");
    }
    if (r.selection === 5) {
      player.runCommandAsync("tellraw @s[scores={tp=!400..}] {\"rawtext\":[{\"text\":\"§cRequires 400 Tp\"}]}");
      player.runCommandAsync("give @s[scores={tp=400..}] wesl3y:suit_otsutsuki");
      player.runCommandAsync("scoreboard players remove @s[scores={tp=400..}] tp 400");
      player.removeTag("tenten_menu");
    }
    if (r.selection === 6) {
      player.runCommandAsync("tellraw @s[scores={tp=!200..}] {\"rawtext\":[{\"text\":\"§cRequires 200 Tp\"}]}");
      player.runCommandAsync("give @s[scores={tp=200..}] wesl3y:suit_rocklee");
      player.runCommandAsync("scoreboard players remove @s[scores={tp=200..}] tp 200");
      player.removeTag("tenten_menu");
    }
    if (r.selection === 7) {
      player.runCommandAsync("tellraw @s[scores={tp=!100..}] {\"rawtext\":[{\"text\":\"§cRequires 100 Tp\"}]}");
      player.runCommandAsync("give @s[scores={tp=100..}] wesl3y:suit_sasuke");
      player.runCommandAsync("scoreboard players remove @s[scores={tp=100..}] tp 100");
      player.removeTag("tenten_menu");
    }
  }
);}