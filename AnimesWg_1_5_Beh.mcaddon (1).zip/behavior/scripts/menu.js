import * as mc from "@minecraft/server";
import * as ui from "@minecraft/server-ui";

mc.world.beforeEvents.itemUse.subscribe(data => {
  let { itemStack, source } = data
  const plr = data.source
  //Aot
  if (itemStack.typeId == "wesl3y:characters") {
    mc.system.run(() => {
      animes(plr);
    })
  }
});

function animes(player) {
  const form = new ui.ActionFormData();
  form.title("Choose Character");
  form.body(``);
  form.button("Player");//Player
  form.button("");//Eren
  form.button("");//Reiner
  form.button("");//Asta
  form.button("");//Magna
  form.button("");//Bakugou
  form.button("");//Todoroki
  form.button("");//Bills
  form.button("");//Kuririn
  form.button("");//Geto
  form.button("");//Gojo
  form.button("");//Itadori
  form.button("");//Byakuya
  form.button("");//Yamamoto
  form.button("");//Kakashi
  form.button("");//Sakura
  form.button("");//Ban
  form.button("");//Escanor
  form.button("");//Luffy
  form.button("");//Zoro
  form.button("");//Sanji
  form.show(player).then((r) => {
    if (r.selection === 0) {
      player.runCommandAsync("scoreboard players set @s wg:animes 0");
      player.runCommandAsync("scoreboard players set @s wg:characters 1");
      player.runCommandAsync("camera @s clear");
      player.runCommandAsync("tag @s add update_character");
      player.runCommandAsync("function remove_tag");
    }
    if (r.selection === 1) {
      if (player.hasTag("unlock.eren")) eren(player);
      else player.runCommandAsync(`tellraw @s {"rawtext":[{"translate":"lock.character"}]}`);
    }
    if (r.selection === 2) {
      if (player.hasTag("unlock.reiner")) reiner(player);
      else player.runCommandAsync(`tellraw @s {"rawtext":[{"translate":"lock.character"}]}`);
    }
    if (r.selection === 3) {
      if (player.hasTag("unlock.asta")) asta(player);
      else player.runCommandAsync(`tellraw @s {"rawtext":[{"translate":"lock.character"}]}`);
    }
    if (r.selection === 4) {
      magna(player);
    }
    if (r.selection === 5) {
      bakugou(player);
    }
    if (r.selection === 6) {
      if (player.hasTag("unlock.todoroki")) todoroki(player);
      else player.runCommandAsync(`tellraw @s {"rawtext":[{"translate":"lock.character"}]}`);
    }
    if (r.selection === 7) {
      bills(player);
    }
    if (r.selection === 8) {
      if (player.hasTag("unlock.kuririn")) kuririn(player);
      else player.runCommandAsync(`tellraw @s {"rawtext":[{"translate":"lock.character"}]}`);
    }
    if (r.selection === 9) {
      geto(player);
    }
    if (r.selection === 10) {
      if (player.hasTag("unlock.gojo")) gojo(player);
      else player.runCommandAsync(`tellraw @s {"rawtext":[{"translate":"lock.character"}]}`);
    }
    if (r.selection === 11) {
      if (player.hasTag("unlock.itadori")) itadori(player);
      else player.runCommandAsync(`tellraw @s {"rawtext":[{"translate":"lock.character"}]}`);
    }
    if (r.selection === 12) {
      byakuya(player);
    }
    if (r.selection === 13) {
      if (player.hasTag("unlock.yamamoto")) yamamoto(player);
      else player.runCommandAsync(`tellraw @s {"rawtext":[{"translate":"lock.character"}]}`);
    }
    if (r.selection === 14) {
      kakashi(player);
    }
    if (r.selection === 15) {
      sakura(player);
    }
    if (r.selection === 16) {
      ban(player);
    }
    if (r.selection === 17) {
      if (player.hasTag("unlock.escanor")) escanor(player);
      else player.runCommandAsync(`tellraw @s {"rawtext":[{"translate":"lock.character"}]}`);
    }
    if (r.selection === 18) {
      if (player.hasTag("unlock.luffy")) luffy(player);
      else player.runCommandAsync(`tellraw @s {"rawtext":[{"translate":"lock.character"}]}`);
    }
    if (r.selection === 19) {
      zoro(player);
    }
    if (r.selection === 20) {
      if (player.hasTag("unlock.jinwoo")) jinwoo(player);
      else player.runCommandAsync(`tellraw @s {"rawtext":[{"translate":"lock.character"}]}`);
    }
  });
}


function eren(player) {
  const form = new ui.ActionFormData();
  form.title("Eren");
  form.body("Health: §e100§r\nDamage: §e7§r\nPassive: §e...§r\nEffects: §eSpeed 1, Jump Boost 1, Haste 1§r\n\n           Dmt\n           Distance: Long\n           Damage: 0\n\n           Bayblade\n           Distance: Long\n           Damage: 10");
  form.button("Selected");
  form.button("Transform");
  form.button("<-");
  form.show(player).then((r) => {
    if (r.selection === 0) {
      player.runCommandAsync("scoreboard players set @s wg:animes 1");
      player.runCommandAsync("scoreboard players set @s wg:characters 1");
      player.runCommandAsync("tag @s add update_character");
    }
    if (r.selection === 1) {
      player.runCommandAsync(`tellraw @s[lm=0,l=4] {"rawtext":[{"translate":"character.5_xp"}]}`);
      player.runCommandAsync("scoreboard players set @s[lm=5] wg:animes 1");
      player.runCommandAsync("scoreboard players set @s[lm=5] wg:characters 1");
      player.runCommandAsync("scoreboard players set @s[lm=5] wg:transform 123");
      player.runCommandAsync("tag @s[lm=5] add update_character");
      player.runCommandAsync("xp -5L @s[lm=5]");
    }
    if (r.selection === 2) {
      animes(player);
    }
  });
}


function reiner(player) {
  const form = new ui.ActionFormData();
  form.title("Reiner");
  form.body("Health: §e100§r\nDamage: §e7§r\nPassive: §e...§r\nEffects: §eSpeed 1, Jump Boost 1, Resistance 1§r\n\n           Dmt\n           Distance: Long\n           Damage: 0\n\n           Bayblade\n           Distance: Long\n           Damage: 10");
  form.button("Selected");
  form.button("Transform");
  form.button("<-");
  form.show(player).then((r) => {
    if (r.selection === 0) {
      player.runCommandAsync("scoreboard players set @s wg:animes 1");
      player.runCommandAsync("scoreboard players set @s wg:characters 3");
      player.runCommandAsync("tag @s add update_character");
    }
    if (r.selection === 1) {
      player.runCommandAsync(`tellraw @s[lm=0,l=4] {"rawtext":[{"translate":"character.5_xp"}]}`);
      player.runCommandAsync("scoreboard players set @s[lm=5] wg:animes 1");
      player.runCommandAsync("scoreboard players set @s[lm=5] wg:characters 3");
      player.runCommandAsync("scoreboard players set @s[lm=5] wg:transform 123");
      player.runCommandAsync("tag @s[lm=5] add update_character");
      player.runCommandAsync("xp -5L @s[lm=5]");
    }
    if (r.selection === 2) {
      animes(player);
    }
  });
}

function asta(player) {
  const form = new ui.ActionFormData();
  form.title("Asta");
  form.body("Health: §e100§r\nDamage: §e7§r\nPassive: §eNullify projectiles on hit§r\nEffects: §eSpeed 2, Jump Boost 1, Haste 1§r\n\n           Bull Thrust\n           Distance: Long\n           Damage: 12\n\n           Black Cut\n           Distance: Long\n           Damage: 12");
  form.button("Selected");
  form.button("Transform");
  form.button("<-");
  form.show(player).then((r) => {
    if (r.selection === 0) {
      player.runCommandAsync("scoreboard players set @s wg:animes 2");
      player.runCommandAsync("scoreboard players set @s wg:characters 1");
      player.runCommandAsync("tag @s add update_character");
    }
    if (r.selection === 1) {
      player.runCommandAsync(`tellraw @s {"rawtext":[{"translate":"character.no_transform"}]}`);
    }
    if (r.selection === 2) {
      animes(player);
    }
  });
}

function yamamoto(player) {
  const form = new ui.ActionFormData();
  form.title("Yamamoto");
  form.body(`Health: §e100§r\nDamage: §e7§r\nPassive: §eFire Hit§r\nEffects: §eJump 1, Speed 1, Fire Resistance 1§r\n\n           Fire Dash\n           Distance: Short\n           Damage: 12\n\n           Fire Cuts\n           Distance: Long\n           Damage: 10`);
  form.button("Selected");
  form.button("Transform");
  form.button("<-");
  form.show(player).then((r) => {
    if (r.selection === 0) {
      player.runCommandAsync("scoreboard players set @s wg:animes 3");
      player.runCommandAsync("scoreboard players set @s wg:characters 1");
      player.runCommandAsync("scoreboard players set @s wg:transform 81");
      player.runCommandAsync("tag @s add update_character");
    }
    if (r.selection === 1) {
      player.runCommandAsync(`tellraw @s[lm=0,l=4] {"rawtext":[{"translate":"character.5_xp"}]}`);
      player.runCommandAsync("scoreboard players set @s[lm=5] wg:animes 3");
      player.runCommandAsync("scoreboard players set @s[lm=5] wg:characters 2");
      player.runCommandAsync("tag @s[lm=5] add update_character");
      player.runCommandAsync("xp -5L @s[lm=5]");
    }
    if (r.selection === 2) {
      animes(player);
    }
  });
}

function todoroki(player) {
  const form = new ui.ActionFormData();
  form.title("Todoroki");
  form.body("Health: §e80§r\nDamage: §e5§r\nPassive: §eCreate ice when running and jumping§r\nEffects: §eFire Resistance 1§r\n\n           Ice Wall\n           Distance: Short\n           Damage: 5\n\n           Jet Burn\n           Distance: Long\n           Damage: 10");
  form.button("Selected");
  form.button("Transform");
  form.button("<-");
  form.show(player).then((r) => {
    if (r.selection === 0) {
      player.runCommandAsync("scoreboard players set @s wg:animes 4");
      player.runCommandAsync("scoreboard players set @s wg:characters 1");
      player.runCommandAsync("tag @s add update_character");
    }
    if (r.selection === 1) {
      player.runCommandAsync(`tellraw @s {"rawtext":[{"translate":"character.no_transform"}]}`);
    }
    if (r.selection === 2) {
      animes(player);
    }
  });
}

function kuririn(player) {
  const form = new ui.ActionFormData();
  form.title("Kuririn");
  form.body("Health: §e180§r\nDamage: §e5§r\nPassive: §e...§r\nEffects: §eResistance 1, Speed 1, Jump Boost 2§r\n\n           Kienzan\n           Distance: Long\n           Damage: 13\n\n           Kamehameha\n           Distance: Long\n           Damage: 18");
  form.button("Selected");
  form.button("Transform");
  form.button("<-");
  form.show(player).then((r) => {
    if (r.selection === 0) {
      player.runCommandAsync("scoreboard players set @s wg:animes 5");
      player.runCommandAsync("scoreboard players set @s wg:characters 1");
      player.runCommandAsync("tag @s add update_character");
    }
    if (r.selection === 1) {
      player.runCommandAsync(`tellraw @s {"rawtext":[{"translate":"character.no_transform"}]}`);
    }
    if (r.selection === 2) {
      animes(player);
    }
  });
}

function gojo(player) {
  const form = new ui.ActionFormData();
  form.title("Gojo");
  form.body("Health: §e400§r\nDamage: §e15§r\nPassive: §e...§r\nEffects: §eSpeed 1, Jump Boost 1, Regeneration 1§r\n\n           Black Flash\n           Distance: Short\n           Damage: +15\n\n           Mugen\n           Distance: Short\n           Damage: 0\n\n           Blue\n           Distance: Short\n           Damage: 30\n\n           Red\n           Distance: Long\n           Damage: 32");
  form.button("Selected");
  form.button("Transform");
  form.button("<-");
  form.show(player).then((r) => {
    if (r.selection === 0) {
      player.runCommandAsync("scoreboard players set @s wg:animes 6");
      player.runCommandAsync("scoreboard players set @s wg:characters 2");
      player.runCommandAsync("tag @s add update_character");
    }
    if (r.selection === 1) {
      player.runCommandAsync(`tellraw @s {"rawtext":[{"translate":"character.no_transform"}]}`);
    }
    if (r.selection === 2) {
      animes(player);
    }
  });
}

function itadori(player) {
  const form = new ui.ActionFormData();
  form.title("Itadori");
  form.body("Health: §e200§r\nDamage: §e10§r\nPassive: §e...§r\nEffects: §eSpeed 1, Jump Boost 1, Haste 2§r\n\n           Divergent Fist\n           Distance: Short\n           Damage: 12\n\n           Black Flash\n           Distance: Short\n           Damage: +12");
  form.button("Selected");
  form.button("Transform");
  form.button("<-");
  form.show(player).then((r) => {
    if (r.selection === 0) {
      player.runCommandAsync("scoreboard players set @s wg:animes 6");
      player.runCommandAsync("scoreboard players set @s wg:characters 4");
      player.runCommandAsync("tag @s add update_character");
    }
    if (r.selection === 1) {
      player.runCommandAsync(`tellraw @s {"rawtext":[{"translate":"character.no_transform"}]}`);
    }
    if (r.selection === 2) {
      animes(player);
    }
  });
}

function escanor(player) {
  const form = new ui.ActionFormData();
  form.title("Escanor");
  form.body("Health: §e200§r\nDamage: §e10§r\nPassive: §eBurn surrounding mobs§r\nEffects: §eResistance 1, Regeneration 1§r\n\n           Cruel Sun\n           Distance: Long\n           Damage: 15\n\n           ...\n           ...\n           ...");
  form.button("Selected");
  form.button("Transform");
  form.button("<-");
  form.show(player).then((r) => {
    if (r.selection === 0) {
      player.runCommandAsync("scoreboard players set @s wg:animes 7");
      player.runCommandAsync("scoreboard players set @s wg:characters 1");
      player.runCommandAsync("tag @s add update_character");
    }
    if (r.selection === 1) {
      player.runCommandAsync(`tellraw @s {"rawtext":[{"translate":"character.no_transform"}]}`);
    }
    if (r.selection === 2) {
      animes(player);
    }
  });
}

function luffy(player) {
  const form = new ui.ActionFormData();
  form.title("Luffy");
  form.body(`Health: §e300§r\nDamage: §e12§r\nPassive: §e...§r\nEffects: §eJump Boost 2§r\n\n           Gatling Gun\n           Distance: Short\n           Damage: 20\n\n           Giant Pistol\n           Distance: Short\n           Damage: 25`);
  form.button("Selected");
  form.button("Transform");
  form.button("<-");
  form.show(player).then((r) => {
    if (r.selection === 0) {
      player.runCommandAsync("scoreboard players set @s wg:animes 9");
      player.runCommandAsync("scoreboard players set @s wg:characters 1");
      player.runCommandAsync("tag @s add update_character");
    }
    if (r.selection === 1) {
      player.runCommandAsync(`tellraw @s[lm=0,l=14] {"rawtext":[{"translate":"character.15_xp"}]}`);
      player.runCommandAsync("scoreboard players set @s[lm=15] wg:animes 9");
      player.runCommandAsync("scoreboard players set @s[lm=15] wg:characters 3");
      player.runCommandAsync("scoreboard players set @s[lm=15] wg:transform 203");
      player.runCommandAsync("tag @s[lm=15] add update_character");
      player.runCommandAsync("xp -15L @s[lm=15]");
    }
    if (r.selection === 2) {
      animes(player);
    }
  });
}

function jinwoo(player) {
  const form = new ui.ActionFormData();
  form.title("Jinwoo");
  form.body("Health: §e300§r\nDamage: §e12§r\nPassive: §eRegeneration 2§r\nEffects: §eSpeed 3, Jump Boost 3§r\n\n           Stealth\n           Distance: Short\n           Inf: Invisibility and more speed\n\n           Bloodlust\n           Distance: Long\n           Inf: Target slowness and weakness\n\n           Igris\n           Distance: Short\n           Inf: Summon Igris");
  form.button("Selected");
  form.button("Transform");
  form.button("<-");
  form.show(player).then((r) => {
    if (r.selection === 0) {
      player.runCommandAsync("scoreboard players set @s wg:animes 10");
      player.runCommandAsync("scoreboard players set @s wg:characters 1");
      player.runCommandAsync("tag @s add update_character");
    }
    if (r.selection === 1) {
      player.runCommandAsync(`tellraw @s {"rawtext":[{"translate":"character.no_transform"}]}`);
    }
    if (r.selection === 2) {
      animes(player);
    }
  });
}