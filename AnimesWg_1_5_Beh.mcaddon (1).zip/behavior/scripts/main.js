import * as mc from '@minecraft/server';
import "./menu.js";
import "./title.js";

mc.system.beforeEvents.watchdogTerminate.subscribe(data => data.cancel = true);