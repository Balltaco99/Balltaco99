import * as mc from "@minecraft/server";

export function getScore(objective, player) { try { return mc.world.scoreboard.getObjective(objective).getScore(player.scoreboardIdentity); } catch (error) { return 0; } }


mc.system.runInterval((data) => {
  for (const player of mc.world.getPlayers()) {
    if (player.hasTag("eren_dmt") && getScore("wg:skill_loop", player) > 0) {
      player.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, 0.75, player.getViewDirection().y);
    }
    if (player.hasTag("eren_bayblade")) {
      player.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, 1.5, 0);
    }
      if (player.hasTag("reiner_dmt") && getScore("wg:skill_loop", player) > 0) {
      player.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, 0.75, player.getViewDirection().y);
    }
    if (player.hasTag("reiner_bayblade")) {
      player.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, 1.5, 0);
    }
  }
}, 1);
    
mc.system.runInterval((data) => {
  for (const player of mc.world.getPlayers()) {
    const
      attack_on_titan = getScore("wg:characters", player) == 1 ? "[eren][2skills]" : getScore("wg:characters", player) == 2 ? "[titan_attack][2skills]" : getScore("wg:characters", player) == 3 ? "[reiner][2skills]" : getScore("wg:characters", player) == 4 ? "[titan_armored][2skills]" : "",
      black_clover = getScore("wg:characters", player) == 1 ? "[asta][2skills]" : getScore("wg:characters", player) == 2 ? "[asta_demon][2skills]" : "",
      bleach = getScore("wg:characters", player) == 1 ? "[yamamoto][2skills]" : getScore("wg:characters", player) == 2 ? "[yamamoto_bankai][2skills]" : "",
      boku_no_hero = getScore("wg:characters", player) == 1 ? "[todoroki][2skills]" : "",
      dragon_ball = getScore("wg:characters", player) == 1 ? "[kuririn][2skills]" : "",
      jujutsu_kaisen = getScore("wg:characters", player) == 1 ? "[geto][skill]" : getScore("wg:characters", player) == 2 ? "[gojo][4skills]" : getScore("wg:characters", player) == 3 ? "[gojo_eye][6skills]" : getScore("wg:characters", player) == 4 ? "[itadori][2skills]" : "",
      nanatsu = getScore("wg:characters", player) == 1 ? "[escanor][2skills]" : getScore("wg:characters", player) == 2 ? "[escanor_day][skill]" : getScore("wg:characters", player) == 3 ? "[escanor_the_one][skill]" : "",
      naruto = getScore("wg:characters", player) == 1 ? "[kakashi][skill]" : getScore("wg:characters", player) == 2 ? "[kakashi_sharingan][skill]" : getScore("wg:characters", player) == 3 ? "[kakashi_mangekyou][skill]" : "",
      one_piece = getScore("wg:characters", player) == 1 ? "[luffy][2skills]" : getScore("wg:characters", player) == 2 ? "[luffy_gear2][2skills]" : getScore("wg:characters", player) == 3 ? "[luffy_gear5][3skills]" : "",
      solo_leveling = getScore("wg:characters", player) == 1 ? "[jinwoo][4skills]" : getScore("wg:characters", player) == 2 ? "[jinwoo2][5skills]" : "",
      black_flashGoj = player.hasTag("gojo_black_flash") ? `BlackFlash: ${getScore("wg:skill_loop", player)}` : "",
      black_flashIta = player.hasTag("itadori_black_flash") ? `BlackFlash: ${getScore("wg:skill_loop2", player)}` : "",
      mugen = player.hasTag("gojo_mugen") ? `Mugen: ${getScore("wg:skill_loop2", player)}` : "",
      stealthJin = player.hasTag("jinwoo_stealth") ? `Stealth: ${getScore("wg:skill_loop", player)}` : "";
    player.onScreenDisplay.setTitle(
      `[skill:${getScore("wg:skill", player)}]` +
      `${getScore("wg:animes", player) == 1 ? attack_on_titan : getScore("wg:animes", player) == 2 ? black_clover : getScore("wg:animes", player) == 3 ? bleach : getScore("wg:animes", player) == 4 ? boku_no_hero : getScore("wg:animes", player) == 5 ? dragon_ball : getScore("wg:animes", player) == 6 ? jujutsu_kaisen : getScore("wg:animes", player) == 7 ? nanatsu : getScore("wg:animes", player) == 8 ? naruto : getScore("wg:animes", player) == 9 ? one_piece : getScore("wg:animes", player) == 10 ? solo_leveling : ""}` +
      `[${player.hasTag("m0") ? "[hp" + Math.round(player.getComponent("health")?.currentValue * 10 / player.getComponent("health")?.defaultValue) + "]" : ""}`
    );
    player.onScreenDisplay.updateSubtitle(
      `${black_flashGoj}${stealthJin}\n` +
      `${getScore("wg:cooldown", player) >= 1 ? `Cdw: ${getScore("wg:cooldown", player)}` : ""}` +
      `\n${black_flashIta}${mugen}\n` +
      `${getScore("wg:cooldown2", player) >= 1 ? `Cdw: ${getScore("wg:cooldown2", player)}` : ""}` +
      `\n\n` +
      `${getScore("wg:cooldown3", player) >= 1 ? `Cdw: ${getScore("wg:cooldown3", player)}` : ""}` +
      `\n\n` +
      `${getScore("wg:cooldown4", player) >= 1 ? `Cdw: ${getScore("wg:cooldown4", player)}` : ""}` +
      `\n\n` +
      `${getScore("wg:cooldown5", player) >= 1 ? `Cdw: ${getScore("wg:cooldown5", player)}` : ""}` +
      `\n\n` +
      `${getScore("wg:cooldown6", player) >= 1 ? `Cdw: ${getScore("wg:cooldown6", player)}` : ""}`
    );
    player.onScreenDisplay.setActionBar(
      `§c${player.hasTag("m0") ? Math.round(player.getComponent("health")?.currentValue) : ""}${player.hasTag("m0") ? "§r/§c" : ""}${player.hasTag("m0") ? Math.round(player.getComponent("health")?.defaultValue) : ""}`
    );
  }
}, 10);