import * as mc from "@minecraft/server";

mc.world.beforeEvents.chatSend.subscribe(eventData => {
  try {
    const
      msg = eventData.message,
      player = eventData.sender,
      stats = player.hasTag("Yonkou") ? "§f[§cYonkou§f]§r " : player.hasTag("Fleet_Admiral") ? "§f[§bAdmiral§f]§r " : "",
      king = player.hasTag("haki_king") ? ".D" : "";
    //if (!player.hasTag("off")) {
      eventData.cancel = true
      mc.world.getDimension("overworld").runCommandAsync(`tellraw @a {"rawtext":[{"text":"${stats}<${player.name}${king}> ${msg}"}]}`);
    //}
  } catch (error) {}
});