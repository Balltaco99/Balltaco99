import * as mc from "@minecraft/server";
import * as general from "../general.js";
import * as modules from "../modules.js";

//mc.system.runInterval(() => { for (const player of mc.world.getPlayers()) { if (player.vida < player.vidaM) player.vida = player.vida + 1; if (player.vida > player.vidaM) player.vida = player.vidaM; player.vidaM = 50 + Math.round(general.getScore("healthStats", player) * 5); } }, 30);

general.tick1(function(player) => {
  if (!player.hasTag("custom") && !player.hasTag("custom2")) modules.custom(player);
  if (player.hasTag("update_stats")) {
    player.removeTag("update_stats");
    player.triggerEvent(`wesl3y:health.${general.getScore("healthStats", player)}`);
    player.runCommandAsync(`scoreboard players set @s energyMax ${general.getScore("energyStats", player) < 3 ? "100" : general.getScore("energyStats", player) < 5 ? "110" : general.getScore("energyStats", player) < 7 ? "120" : general.getScore("energyStats", player) < 9 ? "130" : general.getScore("energyStats", player) < 11 ? "140" : general.getScore("energyStats", player) < 13 ? "150" : general.getScore("energyStats", player) < 15 ? "160" : general.getScore("energyStats", player) < 17 ? "170" : general.getScore("energyStats", player) < 19 ? "180" : general.getScore("energyStats", player) < 20 ? "190" : general.getScore("energyStats", player)}${general.getScore("energyStats", player) >= 20 ? "0" : ""}`);
    player.runCommandAsync(`function stats`);
  }
});

general.tick1(function(player) => {
  if (player.getComponent("health")?.currentValue <= 0) {
    if (player.hasTag("devil_fruit")) player.runCommandAsync("function player/fruit/reset");
    player.runCommandAsync("tag @s add update_stats");
  }
});

general.tick1(function(player) => {
  //  if (player.getComponent("health")?.currentValue <= 0 || player.vida <= 0) { player.kill(); player.vida = player.vidaM; if (player.hasTag("devil_fruit")) player.runCommandAsync("function player/fruit/reset"); player.runCommandAsync("tag @s add update_stats"); }
  for (const entity of [...player.dimension.getEntities()]) {
    const knockback = entity.hasTag("geppo") ? "geppo" : entity.hasTag("jump0_2") ? "jump0_2" : entity.hasTag("jump1_3") ? "jump1_3" : entity.hasTag("jump2_1") ? "jump2_1" : entity.hasTag("jump2_3") ? "jump2_3" : entity.hasTag("speed1") ? "speed1" : entity.hasTag("speed1_25") ? "speed1_25" : entity.hasTag("speed1_5") ? "speed1_5" : "";
    switch (knockback) {
      case `geppo`:
        entity.removeTag("geppo");
        entity.applyKnockback(entity.getViewDirection().x,entity.getViewDirection().z,entity.getViewDirection().y +0.8,1.0);
      break
      case `jump0_2`:
        entity.removeTag("jump0_2");
        entity.applyKnockback(entity.getViewDirection().x,entity.getViewDirection().z,entity.getViewDirection().y,2.0);
      break
      case `jump1_3`:
        entity.removeTag("jump1_3");
        entity.applyKnockback(entity.getViewDirection().x,entity.getViewDirection().z,entity.getViewDirection().y +1.0,3.0);
      break
      case `jump2_1`:
        entity.removeTag("jump2_1");
        entity.applyKnockback(entity.getViewDirection().x,entity.getViewDirection().z,entity.getViewDirection().y +2.0,1.0);
      break
      case `jump2_3`:
        entity.removeTag("jump2_3");
        entity.applyKnockback(entity.getViewDirection().x,entity.getViewDirection().z,entity.getViewDirection().y +2.0,3.0);
      break
      case `speed1`:
        entity.removeTag("speed1");
        entity.applyKnockback(entity.getViewDirection().x,entity.getViewDirection().z,entity.getViewDirection().y +1.0,0.0);
      break
      case `speed1_25`:
        entity.removeTag("speed1_25");
        entity.applyKnockback(entity.getViewDirection().x,entity.getViewDirection().z,entity.getViewDirection().y +1.25,0.0);
      break
      case `speed1_5`:
        entity.removeTag("speed1_5");
        entity.applyKnockback(entity.getViewDirection().x,entity.getViewDirection().z,entity.getViewDirection().y +1.5,0.0);
      break
    }
  }
});