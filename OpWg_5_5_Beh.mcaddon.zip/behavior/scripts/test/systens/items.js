import * as mc from "@minecraft/server";
import { BlockPermutation } from "@minecraft/server";
import * as modules from "../modules.js";
import * as general from "../general.js";

export function menu(player) {
  modules.menu(player);
}

export function up(player) {
  player.runCommand(`tellraw @s[tag=!haki_king]{"rawtext":[{"text":"§a"},{"selector":"@s"},{"text":"§f has made the advancement §a[Haki King]§f"}]}`);
  player.runCommand(`effect @s instant_health 3 255 true`);
  player.runCommand(`tag @s[tag=!haki_king] add haki_king`);
  player.runCommand(`scoreboard players set @s level 200`);
  player.runCommand(`scoreboard players set @s healthStats 200`);
  player.runCommand(`scoreboard players set @s fruitMaes 600`);
  player.runCommand(`scoreboard players set @s styleMaes 600`);
  player.runCommand(`scoreboard players set @s fruitNew 600`);
  player.runCommand(`scoreboard players set @s styleNew 600`);
  player.runCommand(`scoreboard players set @s fruitNew2 0`);
  player.runCommand(`scoreboard players set @s styleNew2 0`);
  player.runCommand(`scoreboard players set @s hakiMaes 600`);
  player.runCommand(`scoreboard players set @s energyStats 100`);
  player.runCommand(`scoreboard players set @s energyCur 10000`);
  player.runCommand(`scoreboard players set @s energyMax 10000`);
  player.runCommand(`scoreboard players set @s xpCur 0`);
  player.runCommand(`scoreboard players set @s xpMax 20000`);
  player.runCommand(`clear @s wesl3y:up 0 1`);
  player.addTag("update_stats");
}

export function belly_bag(player) {
  player.runCommand(`scoreboard players add @s belly 100`);
  player.runCommand(`clear @s wesl3y:belly_bag 0 1`);
}

export function race_lunarian(player) {
  const
    race = player.getProperty('wesl3y:race'),
    lunarian = player.getProperty('wesl3y:lunaria');
  if (race == 4 && lunarian == 1 && player.getProperty('wesl3y:empty') == 0 && player.getProperty('wesl3y:mode') == 0 && !player.isSneaking) {
    player.runCommand('event entity @s wesl3y:lunarianofire');
    player.runCommand('tellraw @s {"rawtext":[{"text":"§eLunarian No Fire"}]}');
  } else if (race == 4 && lunarian == 2 && player.getProperty('wesl3y:empty') == 0 && !player.isSneaking) {
    player.runCommand('event entity @s wesl3y:lunariafire');
    player.runCommand('tellraw @s {"rawtext":[{"text":"§eLunarian Fire"}]}');
  }
}

export function sake(player) {
  player.runCommand(`execute if score @s energyCur < @s energyMax run scoreboard players add @s energyCur 70`);
  player.runCommand(`effect @s regeneration 5 2 true`);
  player.runCommand(`effect @s nausea 7 3 true`);
  player.runCommand(`clear @s wesl3y:sake 0 1`);
}

export function chest_fruit_interact(block, player) {
  const
    hand = player.getComponent('equippable').getEquipment('Mainhand'),
    random = Math.random(0, 20),
    {x,y,z} = block.location;
  if (hand?.typeId == "wesl3y:key_chest") {
    if (random <= 30 || random >= 60) {
      block.dimension.runCommand(`execute positioned ${x} ${y} ${z} run loot spawn ~~0.5~ loot "blocks/test"`);
      block.dimension.runCommand(`execute positioned ${x} ${y} ${z} run setblock ~~~ air`);
      player.runCommand(`clear @s wesl3y:key_chest 0 1`);
    } else {
      block.dimension.runCommand(`execute positioned ${x} ${y} ${z} run summon wesl3y:pirate ~1~~ ~~`);
      block.dimension.runCommand(`execute positioned ${x} ${y} ${z} run summon wesl3y:pirate ~~~1`);
      block.dimension.runCommand(`execute positioned ${x} ${y} ${z} run summon wesl3y:pirate_captain ~~~ ~~`);
      block.dimension.runCommand(`execute positioned ${x} ${y} ${z} run setblock ~~~ air`);
      player.runCommand(`clear @s wesl3y:key_chest 0 1`);
    }
  } else player.runCommand(`tellraw @p[c=1] {"rawtext":[{"text":"§c"},{"translate":"text.key_chest"}]}"`);
}

export function chest_fruit_placed(block, player, setBlockPermutation){
  const
    playerRotation = player.getRotation().y,
    rotationY = Math.abs(playerRotation) < 45 ? 0 : Math.abs(playerRotation) > 135 ? 180 : playerRotation >= 45 ? 270 : 90;
  block.setPermutation(BlockPermutation.resolve(setBlockPermutation.type.id, {"wg:teste": rotationY }));
}

export function hakis(player) {
  if (player.getProperty('wesl3y:haki') != 0 && general.getScore('slotSkill2', player) == 0 && !player.isSneaking) player.runCommand('function new/hArm1');
  if (player.getProperty('wesl3y:haki') == 0 && player.getProperty('wesl3y:empty') == 0 && general.getScore('slotSkill2', player) <= 0 && general.getScore('2cooldown1', player) == 0 && !player.isSneaking) player.runCommand('function new/hArm2');
  if (general.getScore('hakiobs', player) != 0 && general.getScore('slotSkill2', player) == 1 && player.getProperty('wesl3y:hobs') == 1 && !player.isSneaking) player.runCommand('function new/hObs1');
  if (player.getProperty('wesl3y:empty') == 0 && general.getScore('hakiobs', player) != 0 && general.getScore('slotSkill2', player) == 1 && general.getScore('2cooldown2', player) == 0 && general.getScore('hurtCur', player) == 0 && player.getProperty('wesl3y:hobs') == 0 && !player.isSneaking) player.runCommand('function new/hObs2');
  if (player.getProperty('wesl3y:empty') == 0 && general.getScore('2cooldown3', player) == 0 && general.getScore('slotSkill2', player) >= 2 && !player.isSneaking) player.runCommand('function new/hKing');
}

export function black_leg(player) {
  const
    query = !player.isSneaking && !player.isRinding ? true : false;
  if (query == true) {
    general.skill2(player, 1, 1, "2cooldown1");
    general.skill2(player, 2, 50, "2cooldown2");
    general.skill2(player, 3, 100, "2cooldown3");
    if (player.getProperty('wesl3y:empty') == 0 && player.getProperty('wesl3y:skill') == 0 && general.getScore('slotSkill2', player) == 3 && general.getScore('2cooldown4', player) == 0 && general.getScore('hurtCur', player) == 0) {
      player.runCommandAsync(`tellraw @s[tag=!diablejumbe] {"rawtext":[{"text":"§c"}, {"translate":"text.requires"}, {"text":"Diable Jumbe Actived"}]}`);
      player.runCommandAsync(`tellraw @s[tag=diablejumbe,scores={styleMaes=..149}] {"rawtext":[{"text":"§c"}, {"translate":"text.requires"}, {"text":"Style 150"}]}`);
      player.runCommandAsync(`tellraw @s[tag=diablejumbe,scores={styleMaes=150..,energyCur=..49}] {"rawtext":[{"text":"§c"}, {"translate":"text.requires"}, {"text":"Energy 50"}]}`);
      player.runCommandAsync(`event entity @s[tag=diablejumbe,scores={styleMaes=150..,energyCur=50..}] wesl3y:skill4`);
    }
    if (player.getProperty('wesl3y:mode') == 43 && general.getScore('slotSkill2', player) == 4) {
      player.runCommandAsync(`tag @s remove diablejumbe`);
    }
    if (player.getProperty('wesl3y:empty') == 0 && player.getProperty('wesl3y:mode') == 0 && player.getProperty('wesl3y:skill') == 0 && general.getScore('slotSkill2', player) == 4 && general.getScore('2cooldown5', player) == 0) {
      player.runCommandAsync(`tellraw @s[scores={styleMaes=..199}] {\"rawtext\":[{\"text\":\"§c\"}, {\"translate\":\"text.requires\"}, {\"text\":\"Style 200\"}]}`);
      player.runCommandAsync(`tellraw @s[scores={styleMaes=200..,energyCur=..49}] {\"rawtext\":[{\"text\":\"§c\"}, {\"translate\":\"text.requires\"}, {\"text\":\"Energy 50\"}]}`);
      player.runCommandAsync(`playanimation @s[scores={styleMaes=200..,energyCur=50..}] animation.blackleg.transform wesl3y`);
      player.runCommandAsync(`tag @s[scores={styleMaes=200..,energyCur=50..}] add diablejumbe`);
    }
  }
}

export function kanabo(player) {
  const
    query = !player.isSneaking && !player.isRinding && !player.isInWater ? true : false;
  if (query == true) {
    general.skill2(player, 1, 1, "2cooldown1");
    general.skill2(player, 2, 50, "2cooldown2");
  }
}

export function enma(player) {
  const
    query = !player.isSneaking && !player.isRinding && !player.isInWater ? true : false,
    offhand = player.getComponent('equippable').getEquipment('Offhand');
  if (query == true && offhand.typeId == 'wesl3y:ame_no_habakiri') {
    general.skill2(player, 1, 1, "2cooldown1");
    general.skill2(player, 2, 50, "2cooldown2");
    general.skill2(player, 3, 100, "2cooldown3");
  }
}

export function mogura(player) {
  const
    query = !player.isSneaking && !player.isRinding && !player.isInWater ? true : false;
  if (query == true) {
    general.skill2(player, 1, 1, "2cooldown1");
    general.skill2(player, 2, 50, "2cooldown2");
    general.skill2(player, 3, 100, "2cooldown3");
  }
}

export function yoru(player) {
  const
    query = !player.isSneaking && !player.isRinding && !player.isInWater ? true : false;
  if (query == true) {
    general.skill2(player, 1, 50, "2cooldown1");
    general.skill2(player, 2, 100, "2cooldown2");
    general.skill2(player, 3, 150, "2cooldown3");
    general.skill2(player, 4, 200, "2cooldown4");
    general.skill2(player, 5, 250, "2cooldown5");
  }
}

export function yoru2(player) {
  const
    query = !player.isSneaking && !player.isRinding && !player.isInWater ? true : false;
  if (query == true) {
    general.skill2(player, 1, 50, "2cooldown1");
    general.skill2(player, 2, 100, "2cooldown2");
    general.skill2(player, 3, 150, "2cooldown3");
  }
}
















export function bara(player) {
  general.fruit(player, "bara");
    
}

export function bara_skills(player) {
  const
    query = !player.isSneaking && !player.isRinding && !player.isInWater ? true : false;
  if (query == true) {
    general.skill(player, 1, 1, "cooldown1");
    general.skill(player, 2, 70, "cooldown2");
    general.skill(player, 3, 140, "cooldown3");
    general.skill(player, 4, 210, "cooldown4");
    general.skill(player, 5, 50, "cooldown5");
  }
}

export function bomu(player) {
  general.fruit(player, "bomu");
    
}

export function bomu_skills(player) {
  const
    query = !player.isSneaking && !player.isRinding && !player.isInWater ? true : false;
  if (query == true) {
    general.skill(player, 1, 70, "cooldown1");
    general.skill(player, 2, 140, "cooldown2");
    general.skill(player, 3, 210, "cooldown3");
    general.skill(player, 4, 280, "cooldown4");
  }
}

export function gomu(player) {
  general.fruit(player, "gomu");
}

export function gomu_gears(player) {
  const
    query = !player.isSneaking && !player.isRinding && !player.isInWater ? true : false;
  if (query == true) {
    if (player.getProperty("wesl3y:mode") == 0) general.skill(player, 1, 320, "cooldown1");
    if (player.getProperty("wesl3y:mode") == 3 && general.getScore("slotSkill", player) == 0) {
      player.runCommand(`tag @s remove gear_second`);
      player.runCommand(`tag @s remove stop_air`);
      player.runCommand(`scoreboard players set @s cooldown1 15`);
      player.runCommand(`scoreboard players set @s cooldownmax1 15`);
    }
    if (player.getProperty("wesl3y:empty") == 0 && player.getProperty("wesl3y:skill") == 0 && general.getScore("slotSkill", player) == 1 && general.getScore("cooldown2", player) == 0 && general.getScore("hurtCur", player) == 0) {
    player.runCommand(`tellraw @s {"rawtext":[{"text":"§cNext Version"}]}`);
    }
    if (player.getProperty("wesl3y:empty") == 0 && player.getProperty("wesl3y:skill") == 0 && general.getScore("slotSkill", player) == 2 && general.getScore("cooldown3", player) == 0 && general.getScore("hurtCur", player) == 0) {
    player.runCommand(`tellraw @s {"rawtext":[{"text":"§cNext Version"}]}`);
    }
    if (player.getProperty("wesl3y:empty") == 0 && player.getProperty("wesl3y:skill") == 0 && general.getScore("slotSkill", player) == 3 && general.getScore("cooldown4", player) == 0 && general.getScore("hurtCur", player) == 0) {
    player.runCommand(`tellraw @s {"rawtext":[{"text":"§cNext Version"}]}`);
    }
    if (player.getProperty("wesl3y:empty") == 0 && player.getProperty("wesl3y:mode") == 0 && player.getProperty("wesl3y:skill") == 0 && general.getScore("slotSkill", player) == 4 && general.getScore("cooldown5", player) == 0 && general.getScore("hurtCur", player) == 0) {
    player.runCommand(`tellraw @s[scores={fruitMaes=..599}] {"rawtext":[{"text":"§c"}, {"translate":"text.requires"}, {"text":"Fruit 600"}]}`);
    player.runCommand(`tellraw @s[scores={fruitMaes=600..,energyCur=..49}] {"rawtext":[{"text":"§c"}, {"translate":"text.requires"}, {"text":"Energy 50"}]}`);
    player.runCommand(`tag @s[scores={fruitMaes=600..,energyCur=50..}] add gear_five`);
  } else if (player.getProperty("wesl3y:mode") == 8 && general.getScore("slotSkill", player) == 4) {
      player.runCommand(`tag @s remove gear_five`);
      player.runCommand(`tag @s remove stop_air`);
      player.runCommand(`scoreboard players set @s cooldown5 15`);
      player.runCommand(`scoreboard players set @s cooldownmax5 15`);
    }
  }
}

export function gomu_skills(player) {
  const
    query = !player.isSneaking && !player.isRinding && !player.isInWater ? true : false;
  if (query == true) {
    general.skill(player, 1, 70, "cooldown1");
    general.skill(player, 2, 140, "cooldown2");
    general.skill(player, 3, 210, "cooldown3");
    general.skill(player, 4, 280, "cooldown4");
    general.skill(player, 5, 50, "cooldown5");
  }
}

export function gomu2_skills(player) {
  const
    query = !player.isSneaking && !player.isRinding && !player.isInWater ? true : false;
  if (query == true) {
    general.skill(player, 1, 320, "cooldown1");
    general.skill(player, 2, 320, "cooldown2");
    general.skill(player, 3, 400, "cooldown3");
    general.skill(player, 4, 400, "cooldown4");
    general.skill(player, 5, 50, "cooldown5");
  }
}

export function gomu5_skills(player) {
  const
    query = !player.isSneaking && !player.isRinding && !player.isInWater ? true : false;
  if (query == true) {
    general.skill(player, 1, 600, "cooldown1", null, null, null, null, "all");
    general.skill(player, 2, 600, "cooldown2", null, null, null, null, "all");
    general.skill(player, 3, 600, "cooldown3", null, null, null, null, "all");
    general.skill(player, 4, 600, "cooldown4", null, null, null, null, "all");
    general.skill(player, 5, 600, "cooldown5", null, null, null, null, "all");
  }
}

export function goro(player) {
  general.fruit(player, "goro");
}

export function goro_skills(player) {
  const
    query = !player.isSneaking && !player.isRinding && !player.isInWater ? true : false;
  if (query == true) {
    general.skill(player, 1, 1, "cooldown1");
    general.skill(player, 1, 1, "cooldown1", null, null, null, null, 10);
    general.skill(player, 2, 100, "cooldown2");
    general.skill(player, 2, 100, "cooldown2", null, null, null, null, 10);
    general.skill(player, 3, 50, "cooldown3");
    general.skill(player, 3, 50, "cooldown3", null, null, null, null, 10);
  }
}

export function goro2_skills(player) {
  const
    query = !player.isSneaking && !player.isRinding && !player.isInWater ? true : false;
  if (query == true) {
    general.skill(player, 1, 200, "cooldown1");
    general.skill(player, 1, 200, "cooldown1", null, null, null, null, 10);
    general.skill(player, 2, 300, "cooldown2");
    general.skill(player, 2, 300, "cooldown2", null, null, null, null, 10);
    general.skill(player, 3, 400, "cooldown3");
    general.skill(player, 3, 400, "cooldown3", null, null, null, null, 10);
    general.skill(player, 4, 500, "cooldown4");
    general.skill(player, 4, 500, "cooldown4", null, null, null, null, 10);
    if (player.getProperty("wesl3y:empty") == 0 && player.getProperty("wesl3y:mode") == 0 && player.getProperty("wesl3y:skill") == 0 && general.getScore("slotSkill", player) == 4 && general.getScore("cooldown5", player) == 0 && general.getScore("hurtCur", player) == 0) {
      player.runCommand(`tellraw @s[scores={fruitMaes=..599}] {"rawtext":[{"text":"§c"}, {"translate":"text.requires"}, {"text":"Fruit 600"}]}`);
      player.runCommand(`tellraw @s[scores={fruitMaes=600..,energyCur=..49}] {"rawtext":[{"text":"§c"}, {"translate":"text.requires"}, {"text":"Energy 50"}]}`);
      player.runCommand(`tag @s[scores={fruitMaes=600..,energyCur=50..}] add goro_amaru`);
    } else if (player.getProperty("wesl3y:mode") == 10 && general.getScore("slotSkill", player) == 4) {
      player.runCommand(`tag @s remove goro_amaru`);
      player.runCommand(`tag @s remove stop_air`);
      player.runCommand(`scoreboard players set @s cooldown5 15`);
      player.runCommand(`scoreboard players set @s cooldownmax5 15`);
    }
  }
}

export function gura(player) {
  general.fruit(player, "gura");
}

export function gura_skills(player) {
  const
    query = !player.isSneaking && !player.isRinding && !player.isInWater ? true : false;
  if (query == true) {
    general.skill(player, 1, 1, "cooldown1");
    general.skill(player, 2, 70, "cooldown2");
    general.skill(player, 3, 140, "cooldown3");
    general.skill(player, 4, 210, "cooldown4");
    general.skill(player, 5, 280, "cooldown5");
  }
}

export function hie(player) {
  general.fruit(player, "hie");
}

export function hie_skills(player) {
  const
    query = !player.isSneaking && !player.isRinding && !player.isInWater ? true : false;
  if (query == true) {
    general.skill(player, 1, 1, "cooldown1");
    general.skill(player, 2, 100, "cooldown2");
    general.skill(player, 3, 200, "cooldown3");
    general.skill(player, 4, 300, "cooldown4");
    general.skill(player, 5, 400, "cooldown5");
  }
}

export function hie_block_tick(block) {
  const
    status = block.permutation.getState("wesl3y:block"),
    on = block.permutation.getState("wesl3y:on"),
    {x,y,z} = block.location;
  if (on == "despawn") {
    if (status == 0) block.dimension.runCommand(`execute positioned ${x} ${y} ${z} run fill ${x} ${y} ${z} ${x} ${y} ${z} grass`);
    if (status == 1) block.dimension.runCommand(`execute positioned ${x} ${y} ${z} run fill ${x} ${y} ${z} ${x} ${y} ${z} log`);
    if (status == 2) block.dimension.runCommand(`execute positioned ${x} ${y} ${z} run fill ${x} ${y} ${z} ${x} ${y} ${z} planks`);
    if (status == 3) block.dimension.runCommand(`execute positioned ${x} ${y} ${z} run fill ${x} ${y} ${z} ${x} ${y} ${z} stone`);
    if (status == 4) block.dimension.runCommand(`execute positioned ${x} ${y} ${z} run fill ${x} ${y} ${z} ${x} ${y} ${z} water`);
    if (status == 5) block.dimension.runCommand(`execute positioned ${x} ${y} ${z} run fill ${x} ${y} ${z} ${x} ${y} ${z} air`);
  }
  if (on == "placed") {
    block.setPermutation(BlockPermutation.resolve(block.type.id, {"wesl3y:on":"despawn"}));
  }
}

export function ito(player) {
  general.fruit(player, "ito");
}

export function ito_skills(player) {
  const
    query = !player.isSneaking && !player.isRinding && !player.isInWater ? true : false;
  if (query == true) {
    general.skill(player, 1, 1, "cooldown1");
    general.skill(player, 2, 70, "cooldown2");
    general.skill(player, 3, 50, "cooldown3");
  }
}

export function ito2_skills(player) {
  const
    query = !player.isSneaking && !player.isRinding && !player.isInWater ? true : false;
  if (query == true) {
    general.skill(player, 1, 70, "cooldown1");
    general.skill(player, 2, 140, "cooldown2");
    general.skill(player, 3, 210, "cooldown3");
    general.skill(player, 4, 280, "cooldown4");
  }
}

export function magu(player) {
  general.fruit(player, "magu");
}

export function magu_skills(player) {
  const
    query = !player.isSneaking && !player.isRinding && !player.isInWater ? true : false;
  if (query == true) {
    general.skill(player, 1, 1, "cooldown1");
    general.skill(player, 2, 100, "cooldown2");
    general.skill(player, 3, 200, "cooldown3");
    general.skill(player, 4, 300, "cooldown4");
    general.skill(player, 5, 50, "cooldown5");
  }
}

export function magu_block_tick(block) {
  const
    status = block.permutation.getState("wesl3y:block"),
    on = block.permutation.getState("wesl3y:on"),
    {x,y,z} = block.location;
  if (on == "despawn") {
    if (status == 0) block.dimension.runCommand(`execute positioned ${x} ${y} ${z} run fill ${x} ${y} ${z} ${x} ${y} ${z} grass`);
    if (status == 1) block.dimension.runCommand(`execute positioned ${x} ${y} ${z} run fill ${x} ${y} ${z} ${x} ${y} ${z} sand`);
    if (status == 2) block.dimension.runCommand(`execute positioned ${x} ${y} ${z} run fill ${x} ${y} ${z} ${x} ${y} ${z} stone`);
  }
  if (on == "placed") {
    block.setPermutation(BlockPermutation.resolve(block.type.id, {"wesl3y:on":"despawn"}));
  }
}

export function magu_block_step(block) {
  const
    status = block.permutation.getState("wesl3y:block"),
    on = block.permutation.getState("wesl3y:on"),
    {x,y,z} = block.location;
  block.dimension.runCommand(`execute positioned ${x} ${y} ${z} run execute as @e[r=1.5,tag=!magu_fruit,family=!attack,family=!magu] run particle wesl3y:magu_particle ~~1~`);
  block.dimension.runCommand(`execute positioned ${x} ${y} ${z} run effect @e[r=1.5,tag=!magu_fruit,family=!magu,type=!item,family=!attack,type=!xp_orb] wither 2 0 true`);
}

export function mera(player) {
  general.fruit(player, "mera");
}

export function mera_skills(player) {
  const
    query = !player.isSneaking && !player.isRinding && !player.isInWater ? true : false;
  if (query == true) {
    general.skill(player, 1, 1, "cooldown1");
    general.skill(player, 2, 100, "cooldown2");
    general.skill(player, 3, 200, "cooldown3");
    general.skill(player, 4, 300, "cooldown4");
    general.skill(player, 5, 50, "cooldown5");
  }
}

export function mochi(player) {
  general.fruit(player, "mochi");
}

export function mochi_skills(player) {
  const
    query = !player.isSneaking && !player.isRinding && !player.isInWater ? true : false;
  if (query == true) {
    general.skill(player, 1, 1, "cooldown1");
    general.skill(player, 2, 70, "cooldown2");
    general.skill(player, 3, 140, "cooldown3");
  }
}

export function mochi2_skills(player) {
  const
    query = !player.isSneaking && !player.isRinding && !player.isInWater ? true : false;
  if (query == true) {
    general.skill(player, 1, 70, "cooldown1");
    general.skill(player, 2, 140, "cooldown2");
    general.skill(player, 3, 210, "cooldown3");
    general.skill(player, 4, 280, "cooldown4");
    general.skill(player, 5, 50, "cooldown5");
  }
}

export function moku(player) {
  general.fruit(player, "moku");
}

export function moku_skills(player) {
  const
    query = !player.isSneaking && !player.isRinding && !player.isInWater ? true : false;
  if (query == true) {
    general.skill(player, 1, 1, "cooldown1");
    general.skill(player, 2, 100, "cooldown2");
    general.skill(player, 3, 200, "cooldown3");
    general.skill(player, 4, 300, "cooldown4");
    general.skill(player, 5, 400, "cooldown5");
  }
}

export function neko_leopard(player) {
  general.fruit(player, "neko_leopard");
}


export function neko_leopard_forms(player) {
  const
    query = !player.isSneaking && !player.isRinding && !player.isInWater ? true : false;
  if (query == true) {
    if (player.getProperty("wesl3y:empty") == 0 && player.getProperty("wesl3y:mode") == 0 && player.getProperty("wesl3y:skill") == 0 && general.getScore("slotSkill", player) == 0 && general.getScore("cooldown1", player) == 0 && general.getScore("hurtCur", player) == 0) {
      player.runCommand(`tellraw @s[scores={fruitMaes=..0}] {"rawtext":[{"text":"§c"}, {"translate":"text.requires"}, {"text":"Fruit 1"}]}`);
      player.runCommand(`tellraw @s[scores={fruitMaes=1..,energyCur=..49}] {"rawtext":[{"text":"§c"}, {"translate":"text.requires"}, {"text":"Energy 50"}]}`);
      player.runCommand(`tag @s[scores={fruitMaes=1..,energyCur=50..}] add neko_leopard`);
    }
    if (player.getProperty("wesl3y:mode") == 11 && general.getScore("slotSkill", player) == 0) {
      player.runCommand(`tag @s remove neko_leopard`);
      player.runCommand(`tag @s remove stop_air`);
      player.runCommand(`scoreboard players set @s cooldown1 15`);
      player.runCommand(`scoreboard players set @s cooldownmax1 15`);
    }
    if (player.getProperty("wesl3y:empty") == 0 && player.getProperty("wesl3y:mode") == 0 && player.getProperty("wesl3y:skill") == 0 && general.getScore("slotSkill", player) == 1 && general.getScore("cooldown2", player) == 0 && general.getScore("hurtCur", player) == 0) {
    player.runCommand(`tellraw @s[scores={fruitMaes=..79}] {"rawtext":[{"text":"§c"}, {"translate":"text.requires"}, {"text":"Fruit 80"}]}`);
    player.runCommand(`tellraw @s[scores={fruitMaes=80..,energyCur=..49}] {"rawtext":[{"text":"§c"}, {"translate":"text.requires"}, {"text":"Energy 50"}]}`);
    player.runCommand(`tag @s[scores={fruitMaes=80..,energyCur=50..}] add neko_leopard2`);
  } else if (player.getProperty("wesl3y:mode") == 12 && general.getScore("slotSkill", player) == 1) {
      player.runCommand(`tag @s remove neko_leopard2`);
      player.runCommand(`tag @s remove stop_air`);
      player.runCommand(`scoreboard players set @s cooldown2 20`);
      player.runCommand(`scoreboard players set @s cooldownmax2 20`);
    }
  }
}

export function neko_leopard_skills(player) {
  const
    query = !player.isSneaking && !player.isRinding && !player.isInWater ? true : false;
  if (query == true) {
    if (player.getProperty("wesl3y:mode") == 0 && general.getScore("slotSkill", player) == 0) { player.runCommand(`tellraw @s {"rawtext":[{"text":"§cActive Zoan Form"}]}`); } else general.skill(player, 1, 1, "cooldown1", null, null, null, null, "all");
    if (player.getProperty("wesl3y:mode") == 0 && general.getScore("slotSkill", player) == 1) { player.runCommand(`tellraw @s {"rawtext":[{"text":"§cActive Zoan Form"}]}`); } else general.skill(player, 2, 80, "cooldown2", null, null, null, null, "all");
    if (player.getProperty("wesl3y:mode") != 12 && general.getScore("slotSkill", player) == 2) { player.runCommand(`tellraw @s {"rawtext":[{"text":"§cActive Hybrid Form"}]}`); } else general.skill(player, 3, 260, "cooldown3", null, null, null, null, 12);
  }
}

export function ope(player) {
  general.fruit(player, "ope");
}

export function ope_room(player) {
  if (!player.isSneaking) {
    player.runCommandAsync(`execute at @s[tag=!room,scores={fruitMaes=..99}] run summon wesl3y:room ~~~ ~ 0 wesl3y:room1`);
    player.runCommandAsync(`execute at @s[tag=!room,scores={fruitMaes=100..249}] run summon wesl3y:room ~~~ ~ 0 wesl3y:room2`);
    player.runCommandAsync(`execute at @s[tag=!room,scores={fruitMaes=250..}] run summon wesl3y:room ~~~ ~ 0 wesl3y:room3`);
    player.runCommandAsync(`execute at @s[tag=!room] run playsound room_open @a[r=25]`);
    player.runCommandAsync(`give @s[tag=!room] wesl3y:ope_skills 1 0 {"item_lock": {"mode": "lock_in_inventory"},"keep_on_death":{}}`);
    player.runCommandAsync(`give @s[tag=!room] wesl3y:ope2_skills 1 0 {"item_lock": {"mode": "lock_in_inventory"},"keep_on_death":{}}`);
    player.runCommandAsync(`tag @s[tag=!room] add room`);
  } else {
    player.runCommandAsync(`event entity @e[type=wesl3y:room] wesl3y:despawn`);
    player.runCommandAsync(`execute at @s[tag=room] run playsound room_close @a[r=25]`);
    player.runCommandAsync(`clear @s wesl3y:ope_skills`);
    player.runCommandAsync(`clear @s wesl3y:ope2_skills`);
    player.runCommandAsync(`tag @s remove room1`);
  }
}

export function ope_skills(player) {
  const
    query = !player.isSneaking && !player.isRinding && !player.isInWater ? true : false;
  if (query == true) {
    if (player.hasTag("room")) {
      general.skill(player, 1, 1, "cooldown1");
      general.skill(player, 2, 70, "cooldown2");
      general.skill(player, 3, 50, "cooldown3");
    } else player.runCommandAsync(`tellraw @s[tag=!room] {"rawtext":[{"text":"§c"}, {"translate":"text.requires"}, {"text":"Room activated"}]}`);
  }
}

export function ope2_skills(player) {
  const
    query = !player.isSneaking && !player.isRinding && !player.isInWater ? true : false;
  if (query == true) {
    if (player.hasTag("room")) {
      general.skill(player, 1, 70, "cooldown1");
      general.skill(player, 2, 70, "cooldown2");
      general.skill(player, 3, 140, "cooldown3");
      general.skill(player, 4, 210, "cooldown4");
      general.skill(player, 5, 280, "cooldown5");
    } else player.runCommandAsync(`tellraw @s[tag=!room] {"rawtext":[{"text":"§c"}, {"translate":"text.requires"}, {"text":"Room activated"}]}`);
  }
}

export function pika(player) {
  general.fruit(player, "pika");
}

export function pika_skills(player) {
  const
    query = !player.isSneaking && !player.isRinding && !player.isInWater ? true : false;
  if (query == true) {
    general.skill(player, 1, 1, "cooldown1");
    general.skill(player, 2, 100, "cooldown2");
    general.skill(player, 3, 200, "cooldown3");
    general.skill(player, 4, 300, "cooldown4");
    general.skill(player, 5, 50, "cooldown5");
  }
}

export function suke(player) {
  general.fruit(player, "suke");
}

export function suke_skills(player) {
  const
    query = !player.isSneaking && !player.isRinding && !player.isInWater ? true : false;
  if (query == true) {
    if (player.getProperty("wesl3y:empty") == 0 && player.getProperty("wesl3y:mode") == 0 && player.getProperty("wesl3y:skill") == 0 && general.getScore("slotSkill", player) == 0 && general.getScore("cooldown1", player) == 0 && general.getScore("hurtCur", player) == 0) {
      player.runCommand(`tellraw @s[scores={fruitMaes=..0}] {"rawtext":[{"text":"§c"}, {"translate":"text.requires"}, {"text":"Fruit 1"}]}`);
      player.runCommand(`tellraw @s[scores={fruitMaes=1..,energyCur=..49}] {"rawtext":[{"text":"§c"}, {"translate":"text.requires"}, {"text":"Energy 50"}]}`);
      player.runCommand(`tag @s[scores={fruitMaes=1..,energyCur=50..}] add suke_invisible`);
    }
    if (player.getProperty("wesl3y:mode") == 42 && general.getScore("slotSkill", player) == 0) {
      player.runCommand(`tag @s remove suke_invisible`);
      player.runCommand(`tag @s remove stop_air`);
      player.runCommand(`scoreboard players set @s cooldown1 15`);
      player.runCommand(`scoreboard players set @s cooldownmax1 15`);
    }
  }
}

export function suna(player) {
  general.fruit(player, "suna");
}

export function suna_skills(player) {
  const
    query = !player.isSneaking && !player.isRinding && !player.isInWater ? true : false;
  if (query == true) {
    general.skill(player, 1, 1, "cooldown1");
    general.skill(player, 2, 100, "cooldown2");
    general.skill(player, 3, 200, "cooldown3");
    general.skill(player, 4, 300, "cooldown4");
    general.skill(player, 5, 50, "cooldown5");
  }
}

export function suna_block_tick(block) {
  const
    status = block.permutation.getState("wesl3y:block"),
    on = block.permutation.getState("wesl3y:on"),
    {x,y,z} = block.location;
  if (on == "despawn") {
    if (status == 0) block.dimension.runCommand(`execute positioned ${x} ${y} ${z} run fill ${x} ${y} ${z} ${x} ${y} ${z} grass`);
    if (status == 1) block.dimension.runCommand(`execute positioned ${x} ${y} ${z} run fill ${x} ${y} ${z} ${x} ${y} ${z} sand`);
    if (status == 2) block.dimension.runCommand(`execute positioned ${x} ${y} ${z} run fill ${x} ${y} ${z} ${x} ${y} ${z} stone`);
  }
  if (on == "placed") {
    block.setPermutation(BlockPermutation.resolve(block.type.id, {"wesl3y:on":"despawn"}));
  }
}

export function suna_block_step(block) {
  const
    status = block.permutation.getState("wesl3y:block"),
    on = block.permutation.getState("wesl3y:on"),
    {x,y,z} = block.location;
  block.dimension.runCommand(`execute positioned ${x} ${y} ${z} run execute as @e[r=1.5,tag=!suna_fruit,family=!attack,family=!suna] run particle wesl3y:suna_particle ~~1~`);
  block.dimension.runCommand(`execute positioned ${x} ${y} ${z} run effect @e[r=1.5,tag=!suna_fruit,family=!suna,type=!item,family=!attack,type=!xp_orb] wither 2 0 true`);
}

export function tori_phoenix(player) {
  general.fruit(player, "tori_phoenix");
}


export function tori_phoenix_forms(player) {
  const
    query = !player.isSneaking && !player.isRinding && !player.isInWater ? true : false;
  if (query == true) {
    if (player.getProperty("wesl3y:empty") == 0 && player.getProperty("wesl3y:mode") == 0 && player.getProperty("wesl3y:skill") == 0 && general.getScore("slotSkill", player) == 0 && general.getScore("cooldown1", player) == 0 && general.getScore("hurtCur", player) == 0) {
      player.runCommand(`tellraw @s[scores={fruitMaes=..0}] {"rawtext":[{"text":"§c"}, {"translate":"text.requires"}, {"text":"Fruit 1"}]}`);
      player.runCommand(`tellraw @s[scores={fruitMaes=1..,energyCur=..49}] {"rawtext":[{"text":"§c"}, {"translate":"text.requires"}, {"text":"Energy 50"}]}`);
      player.runCommand(`tag @s[scores={fruitMaes=1..,energyCur=50..}] add tori_phoenix`);
    }
    if (player.getProperty("wesl3y:mode") == 25 && general.getScore("slotSkill", player) == 0) {
      player.runCommand(`tag @s remove tori_phoenix`);
      player.runCommand(`tag @s remove stop_air`);
      player.runCommand(`scoreboard players set @s cooldown1 15`);
      player.runCommand(`scoreboard players set @s cooldownmax1 15`);
    }
    if (player.getProperty("wesl3y:empty") == 0 && player.getProperty("wesl3y:mode") == 0 && player.getProperty("wesl3y:skill") == 0 && general.getScore("slotSkill", player) == 1 && general.getScore("cooldown2", player) == 0 && general.getScore("hurtCur", player) == 0) {
    player.runCommand(`tellraw @s[scores={fruitMaes=..79}] {"rawtext":[{"text":"§c"}, {"translate":"text.requires"}, {"text":"Fruit 80"}]}`);
    player.runCommand(`tellraw @s[scores={fruitMaes=80..,energyCur=..49}] {"rawtext":[{"text":"§c"}, {"translate":"text.requires"}, {"text":"Energy 50"}]}`);
    player.runCommand(`tag @s[scores={fruitMaes=80..,energyCur=50..}] add tori_phoenix2`);
  } else if (player.getProperty("wesl3y:mode") == 26 && general.getScore("slotSkill", player) == 1) {
      player.runCommand(`tag @s remove tori_phoenix2`);
      player.runCommand(`tag @s remove stop_air`);
      player.runCommand(`scoreboard players set @s cooldown2 20`);
      player.runCommand(`scoreboard players set @s cooldownmax2 20`);
    }
  }
}

export function tori_phoenix_skills(player) {
  const
    query = !player.isSneaking && !player.isRinding && !player.isInWater ? true : false;
  if (query == true) {
    general.skill(player, 1, 1, "cooldown1");
    if (player.getProperty("wesl3y:mode") == 0 && general.getScore("slotSkill", player) == 1) { player.runCommand(`tellraw @s {"rawtext":[{"text":"§cActive Zoan Form"}]}`); } else general.skill(player, 2, 80, "cooldown2", null, null, null, null, "all");
    if (player.getProperty("wesl3y:mode") != 26 && general.getScore("slotSkill", player) == 2) { player.runCommand(`tellraw @s {"rawtext":[{"text":"§cActive Hybrid Form"}]}`); } else general.skill(player, 3, 160, "cooldown3", null, null, null, null, 26);
  }
}

export function uo_dragon(player) {
  general.fruit(player, "uo_dragon");
}


export function uo_dragon_forms(player) {
  const
    query = !player.isSneaking && !player.isRinding && !player.isInWater ? true : false;
  if (query == true) {
    if (player.getProperty("wesl3y:empty") == 0 && player.getProperty("wesl3y:mode") == 0 && player.getProperty("wesl3y:skill") == 0 && general.getScore("slotSkill", player) == 0 && general.getScore("cooldown1", player) == 0 && general.getScore("hurtCur", player) == 0) {
      player.runCommand(`tellraw @s[scores={fruitMaes=..0}] {"rawtext":[{"text":"§c"}, {"translate":"text.requires"}, {"text":"Fruit 1"}]}`);
      player.runCommand(`tellraw @s[scores={fruitMaes=1..,energyCur=..49}] {"rawtext":[{"text":"§c"}, {"translate":"text.requires"}, {"text":"Energy 50"}]}`);
      player.runCommand(`tag @s[scores={fruitMaes=1..,energyCur=50..}] add uo_dragon`);
    }
    if (player.getProperty("wesl3y:mode") == 29 && general.getScore("slotSkill", player) == 0) {
      player.runCommand(`tag @s remove uo_dragon`);
      player.runCommand(`tag @s remove stop_air`);
      player.runCommand(`scoreboard players set @s cooldown1 15`);
      player.runCommand(`scoreboard players set @s cooldownmax1 15`);
    }
    if (player.getProperty("wesl3y:empty") == 0 && player.getProperty("wesl3y:mode") == 0 && player.getProperty("wesl3y:skill") == 0 && general.getScore("slotSkill", player) == 1 && general.getScore("cooldown2", player) == 0 && general.getScore("hurtCur", player) == 0) {
    player.runCommand(`tellraw @s[scores={fruitMaes=..79}] {"rawtext":[{"text":"§c"}, {"translate":"text.requires"}, {"text":"Fruit 80"}]}`);
    player.runCommand(`tellraw @s[scores={fruitMaes=80..,energyCur=..49}] {"rawtext":[{"text":"§c"}, {"translate":"text.requires"}, {"text":"Energy 50"}]}`);
    player.runCommand(`tag @s[scores={fruitMaes=80..,energyCur=50..}] add uo_dragon2`);
  } else if (player.getProperty("wesl3y:mode") == 30 && general.getScore("slotSkill", player) == 1) {
      player.runCommand(`tag @s remove uo_dragon2`);
      player.runCommand(`tag @s remove stop_air`);
      player.runCommand(`scoreboard players set @s cooldown2 20`);
      player.runCommand(`scoreboard players set @s cooldownmax2 20`);
    }
  }
}

export function uo_dragon_skills(player) {
  const
    query = !player.isSneaking && !player.isRinding && !player.isInWater ? true : false;
  if (query == true) {
    if (player.isRiding) player.runCommand("ride @s stop_riding");
    if (player.getProperty("wesl3y:mode") != 29 && general.getScore("slotSkill", player) == 0) { player.runCommand(`tellraw @s {"rawtext":[{"text":"§cActive Complet Form"}]}`); } else general.skill(player, 1, 1, "cooldown1", null, null, null, null, 29);
    if (player.getProperty("wesl3y:mode") == 0 && general.getScore("slotSkill", player) == 1) { player.runCommand(`tellraw @s {"rawtext":[{"text":"§cActive Zoan Form"}]}`); } else general.skill(player, 2, 80, "cooldown2", null, null, null, null, "all");
    if (player.getProperty("wesl3y:mode") == 0 && general.getScore("slotSkill", player) == 2) { player.runCommand(`tellraw @s {"rawtext":[{"text":"§cActive Zoan Form"}]}`); } else general.skill(player, 3, 160, "cooldown3", null, null, null, null, "all");
    if (player.getProperty("wesl3y:mode") == 0 && general.getScore("slotSkill", player) == 3) { player.runCommand(`tellraw @s {"rawtext":[{"text":"§cActive Zoan Form"}]}`); } else general.skill(player, 4, 240, "cooldown4", null, null, null, null, "all");
  }
}

export function yami(player) {
  general.fruit(player, "yami");
}

export function yami_skills(player) {
  const
    query = !player.isSneaking && !player.isRinding && !player.isInWater ? true : false;
  if (query == true) {
    general.skill(player, 1, 1, "cooldown1");
    general.skill(player, 2, 100, "cooldown2");
    general.skill(player, 3, 200, "cooldown3");
    general.skill(player, 4, 300, "cooldown4");
  }
}

export function zou_elephant(player) {
  general.fruit(player, "zou_elephant");
}


export function zou_elephant_forms(player) {
  const
    query = !player.isSneaking && !player.isRinding && !player.isInWater ? true : false;
  if (query == true) {
    if (player.getProperty("wesl3y:empty") == 0 && player.getProperty("wesl3y:mode") == 0 && player.getProperty("wesl3y:skill") == 0 && general.getScore("slotSkill", player) == 0 && general.getScore("cooldown1", player) == 0 && general.getScore("hurtCur", player) == 0) {
      player.runCommand(`tellraw @s[scores={fruitMaes=..0}] {"rawtext":[{"text":"§c"}, {"translate":"text.requires"}, {"text":"Fruit 1"}]}`);
      player.runCommand(`tellraw @s[scores={fruitMaes=1..,energyCur=..49}] {"rawtext":[{"text":"§c"}, {"translate":"text.requires"}, {"text":"Energy 50"}]}`);
      player.runCommand(`tag @s[scores={fruitMaes=1..,energyCur=50..}] add zou_elephant`);
    }
    if (player.getProperty("wesl3y:mode") == 34 && general.getScore("slotSkill", player) == 0) {
      player.runCommand(`tag @s remove zou_elephant`);
      player.runCommand(`tag @s remove stop_air`);
      player.runCommand(`scoreboard players set @s cooldown1 15`);
      player.runCommand(`scoreboard players set @s cooldownmax1 15`);
    }
    if (player.getProperty("wesl3y:empty") == 0 && player.getProperty("wesl3y:mode") == 0 && player.getProperty("wesl3y:skill") == 0 && general.getScore("slotSkill", player) == 1 && general.getScore("cooldown2", player) == 0 && general.getScore("hurtCur", player) == 0) {
    player.runCommand(`tellraw @s[scores={fruitMaes=..79}] {"rawtext":[{"text":"§c"}, {"translate":"text.requires"}, {"text":"Fruit 80"}]}`);
    player.runCommand(`tellraw @s[scores={fruitMaes=80..,energyCur=..49}] {"rawtext":[{"text":"§c"}, {"translate":"text.requires"}, {"text":"Energy 50"}]}`);
    player.runCommand(`tag @s[scores={fruitMaes=80..,energyCur=50..}] add zou_elephant2`);
  } else if (player.getProperty("wesl3y:mode") == 35 && general.getScore("slotSkill", player) == 1) {
      player.runCommand(`tag @s remove zou_elephant2`);
      player.runCommand(`tag @s remove stop_air`);
      player.runCommand(`scoreboard players set @s cooldown2 20`);
      player.runCommand(`scoreboard players set @s cooldownmax2 20`);
    }
  }
}

export function zou_elephant_skills(player) {
  const
    query = !player.isSneaking && !player.isRinding && !player.isInWater ? true : false;
  if (query == true) {
    if (player.getProperty("wesl3y:mode") == 0 && general.getScore("slotSkill", player) == 0) { player.runCommand(`tellraw @s {"rawtext":[{"text":"§cActive Zoan Form"}]}`); } else general.skill(player, 1, 1, "cooldown1", null, null, null, null, "all");
    if (player.getProperty("wesl3y:mode") != 34 && general.getScore("slotSkill", player) == 1) { player.runCommand(`tellraw @s {"rawtext":[{"text":"§cActive Complet Form"}]}`); } else general.skill(player, 2, 80, "cooldown2", null, null, null, null, 34);
  }
}

export function zushi(player) {
  general.fruit(player, "zushi");
}

export function zushi_skills(player) {
  const
    query = !player.isSneaking && !player.isRinding && !player.isInWater ? true : false;
  if (query == true) {
    general.skill(player, 1, 1, "cooldown1");
    general.skill(player, 2, 80, "cooldown2");
    general.skill(player, 3, 160, "cooldown3");
    general.skill(player, 4, 240, "cooldown4");
    general.skill(player, 5, 320, "cooldown5");
  }
}