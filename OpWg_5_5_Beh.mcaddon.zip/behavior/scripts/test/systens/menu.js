import * as mc from "@minecraft/server";
import * as ui from "@minecraft/server-ui";
import * as general from "../general.js";

export function custom(player) {
  player.addTag("custom2");
  const form = new ui.ActionFormData();
  form.title("Start");
  form.body(`§bOne Piece Wg Versão Survival§r\nExplore o mundo de One Piece no Minecraft, procure navios, casas e até ilhas no céu... derrote inimigos e crie uma tripulação, seja o mais livre, aquele que terá o maior Tesouro do Mundo... O One Piece.`);
  form.button("");
  form.button("");
  form.show(player).then((r) => {
    if (r.canceled) {
      custom(player);
    }
    if (r.selection === 0) {
      player.runCommandAsync("event entity @s wesl3y:random_race");
      player.runCommandAsync(`tellraw @s {"rawtext":[{"text":"§eDefeat pirates, sailors and level up to level 10"}]}`);
      player.addTag("custom");
      player.removeTag("custom2");
      player.addTag("pirate");
      player.removeTag("bounty_hunter");
      player.removeTag("marine");
      player.removeTag("revolutionary");
    }
    if (r.selection === 1) {
      player.runCommandAsync("event entity @s wesl3y:random_race");
      player.runCommandAsync(`tellraw @s {"rawtext":[{"text":"§cDefeat pirates, sailors and level up to level 10"}]}`);
      player.addTag("custom");
      player.removeTag("custom2");
      player.addTag("marine");
      player.removeTag("bounty_hunter");
      player.removeTag("pirate");
      player.removeTag("revolutionary");
    }
  }
);}

export function menu(player) {
  const form = new ui.ActionFormData();
  form.title("Menu");
  form.body(`§eName:§f ${player.nameTag}\n§eFaction:§f ${player.hasTag("pirate") ? "Pirate" : player.hasTag("marine") ? "Marine" : ""}\n§eRace:§f ${player.hasTag("fishman") ? "Fishman" : player.hasTag("mink") ? "Mink" : player.hasTag("lunarian") ? "Lunarian" : "Human"}\n§eRank:§f ${player.hasTag("haki_killer") ? "§cHaki Killer§r" : player.hasTag("best_swordsman") ? "Best Swordman" : player.hasTag("strongest_man") ? "Strongest Man" : player.hasTag("strongest_creature") ? "Strongest Creature" : "null"}\n\n${player.hasTag("pirate") ? "§7Mostre ao mundo quem será o pirata mais forte." : "§7Torne-se um Almirante e mostre a verdadeira Justiça."}\n${player.hasTag("pirate") ? "§7Show the world who will be the strongest pirate." : "§7Become an Admiral and show true justice."}`);
  form.button("");//Status
  form.button("");//Achievements
  form.button("");//Configurations
  form.show(player).then((r) => {
    if (r.selection === 0) {
      menu_status(player);
    }
    if (r.selection === 1) {
      menu_achievements(player);
    }
    if (r.selection === 2) {
      menu_config(player);
    }
  });
}
  
export function menu_status(player) {
  const form = new ui.ActionFormData();
  form.title("Status");
  form.body(`§f${general.number(general.getScore("point", player))}§7\n\n                  ${general.getScore("healthStats", player) < 9 ? " " : ""}§fLv§r.${general.getScore("healthStats", player)}\n                  ${general.getScore("energyStats", player) < 9 ? " " : ""}§fLv§r.${general.getScore("energyStats", player)}\n                  ${general.getScore("fruitMaes", player) < 9 ? " " : ""}§fLv§r.${general.getScore("fruitMaes", player)}\n                  ${general.getScore("styleMaes", player) < 9 ? " " : ""}§fLv§r.${general.getScore("styleMaes", player)}\n                  ${general.getScore("hakiMaes", player) < 9 ? " " : ""}§fLv§r.${general.getScore("hakiMaes", player)}`);
  form.button("§0+");
  form.button("§0+");
  form.button("§0+");
  form.button("§0+");
  form.button("§0+");
  console.log(`${general.getScore("fruitNew", player)} e ${general.getScore("fruitNew2", player)}\n${general.getScore("styleNew", player)} e ${general.getScore("styleNew2", player)}`);
  form.show(player).then((r) => {
    if (r.selection === 0) {
      if (general.getScore("healthStats", player) <= 99 && general.getScore("point", player) >= 1) {
        player.runCommandAsync("scoreboard players add @s healthStats 1");
        player.runCommandAsync("scoreboard players remove @s point 1");
        player.runCommandAsync("tag @s add update_stats");
        menu(player);
      } else player.runCommandAsync(`tellraw @s[scores={healthStats=!200..}] {"rawtext": [{"text":"§c"},{"translate":"text.requires"},{"text": "1 Point"}]}`);
    }
    if (r.selection === 1) {
      if (general.getScore("energyStats", player) <= 99 && general.getScore("point", player) >= 1) {
        player.runCommandAsync("scoreboard players add @s energyStats 1");
        player.runCommandAsync("scoreboard players remove @s point 1");
        player.runCommandAsync("tag @s add update_stats");
        menu(player);
      } else player.runCommandAsync(`tellraw @s[scores={energyStats=!100..}] {"rawtext": [{"text":"§c"},{"translate":"text.requires"},{"text": "1 Point"}]}`);
    }
    if (r.selection === 2) {
      if (general.getScore("fruitNew", player) <= 99 && general.getScore("point", player) >= 1) {
        player.runCommandAsync("scoreboard players add @s fruitMaes 1");
        player.runCommandAsync("scoreboard players add @s fruitNew 1");
        player.runCommandAsync("scoreboard players remove @s point 1");
        player.runCommandAsync("tag @s add update_stats");
        menu(player);
      } else player.runCommandAsync(`tellraw @s[scores={fruitNew=!100..}] {"rawtext": [{"text":"§c"},{"translate":"text.requires"},{"text": "1 Point"}]}`);
    }
    if (r.selection === 3) {
      if (general.getScore("styleNew", player) <= 599 && general.getScore("point", player) >= 1) {
        player.runCommandAsync("scoreboard players add @s styleMaes 1");
        player.runCommandAsync("scoreboard players add @s styleNew 1");
        player.runCommandAsync("scoreboard players remove @s point 1");
        player.runCommandAsync("tag @s add update_stats");
        menu(player);
      } else player.runCommandAsync(`tellraw @s[scores={styleNew=!600..}] {"rawtext": [{"text":"§c"},{"translate":"text.requires"},{"text": "1 Point"}]}`);
    }
    if (r.selection === 4) {
      if (general.getScore("hakiMaes", player) <= 599 && general.getScore("point", player) >= 1) {
        player.runCommandAsync("scoreboard players add @s hakiMaes 1");
        player.runCommandAsync("scoreboard players remove @s point 1");
        player.runCommandAsync("tag @s add update_stats");
        menu(player);
      } else player.runCommandAsync(`tellraw @s[scores={hakiMaes=!600..}] {"rawtext": [{"text":"§c"},{"translate":"text.requires"},{"text": "1 Point"}]}`);
    }
  }
);}
  
export function menu_achievements(player) {
  const form = new ui.ActionFormData();
  form.title("Achievements");
  form.body(`§r• Use Punch Combat to defeat enemies if you don't have a sword\n§r• Up "Style" to deal more damage on hit\n§r• Up haki 45 to awaken Armament haki\n§r• Up haki 80 to awaken observation haki\n§r• Find chests in Baratie or Arlong Park`);
  form.button("§0<");
  form.button("§0Pt");
  form.show(player).then((r) => {
    if (r.selection === 0) {
      menu(player);
    }
    if (r.selection === 1) {
      menu_achievements2(player);
    }
  }
);}
  
export function menu_achievements2(player) {
  const form = new ui.ActionFormData();
  form.title("Achievements");
  form.body(`§r• Use Punch Combat para derrotar os inimigos se você não tiver uma espada\n§r• Aumente o "Estilo" para causar mais dano ao acertar\n§r• Suba o haki 45 para despertar o Haki do Armamento\n§r• Suba o haki 80 para despertar o Haki da Observação\n§r• Encontre baús no Baratie ou Arlong Park`);
  form.button("§0<");
  form.button("§0Eng");
  form.show(player).then((r) => {
    if (r.selection === 0) {
      menu(player);
    }
    if (r.selection === 1) {
      menu_achievements(player);
    }
  }
);}

export function menu_achievements3(player) {
  const form = new ui.ActionFormData();
  form.title("Achievements");
  form.body(`§r• Defeat ${player.hasTag("achi.luffy") ? "§aLuffy" : "§cLuffy"}\n§r• Defeat ${player.hasTag("achi.katakuri") ? "§aKatakuri" : "§cKatakuri"}\n§r• Defeat ${player.hasTag("achi.shanks") ? "§aShanks" : "§cShanks"}\n§r• Item ${player.hasTag("achi.cigarette") ? "§aCigarette Sanji" : "§cCigarette Sanji"}\n§r• Level ${general.getScore("level", player) >= 200 ? "§a200" : "§c200"}`);
  form.button("§0<");
  form.show(player).then((r) => {
    if (r.selection === 0) {
      menu(player);
    }
  }
);}

export function menu_config(player) {
  const form = new ui.ActionFormData();
  form.title("Config");
  form.body(`§rFire Faction: ${player.hasTag("fire_faction") ? "§aOn": "§cOff"}\n§rFruit Skill change: ${general.getScore("changeskill", player) == 0 ? "§aShift": "§aClick"}\n§rStyle Skill change: ${general.getScore("changeskill2", player) == 0 ? "§aShift": "§aClick"}\n§rCamera mode: ${player.hasTag("camera_mode") ? "§aOn": "§cOff"}`);
  form.button("§0x");
  form.button("§0x");
  form.button("§0x");
  form.button("§0x");
  form.show(player).then((r) => {
    if (r.selection === 0) {
      if (player.hasTag("fire_faction")) {
        player.runCommandAsync("tag @s remove fire_faction");
      } else player.runCommandAsync("tag @s add fire_faction");
    }
    if (r.selection === 1) {
      if (general.getScore("changeskill", player) == 0) {
        player.runCommandAsync("scoreboard players set @s changeskill 1");
      } else player.runCommandAsync("scoreboard players set @s changeskill 0");
    }
    if (r.selection === 2) {
      if (general.getScore("changeskill2", player) == 0) {
        player.runCommandAsync("scoreboard players set @s changeskill2 1");
      } else player.runCommandAsync("scoreboard players set @s changeskill2 0");
    }
    if (r.selection === 3) {
      if (player.hasTag("camera_mode")) {
        player.runCommandAsync("tag @s remove camera_mode");
      } else player.runCommandAsync("tag @s add camera_mode");
    }
  }
);}

mc.world.afterEvents.entityHitEntity.subscribe(data => {
  let hit = data.hitEntity;
  let player = data.damagingEntity;
  if(!hit || hit?.typeId != "wesl3y:npc" || player.typeId != "minecraft:player") return;
  if(player?.typeId == "minecraft:player" && hit?.typeId == "wesl3y:npc") {
    const tag = hit.hasTag("wg_baratie") ? "wg_baratie" : hit.hasTag("wg_arlong") ? "wg_arlong" : hit.hasTag("baratie") ? "baratie" : hit.hasTag("arlong_park") ? "arlong_park" : hit.hasTag("loguetown") ? "loguetown" : "";
    switch (tag) {
      case "wg_baratie":
        wg_baratie(player);
      break
      case "wg_arlong":
        wg_arlong(player);
      break
      case "baratie":
        baratie1(player);
      break
      case "arlong_park":
        arlong_park1(player);
      break
    }
  }
});

export function wg_baratie(player) {
  const form = new ui.ActionFormData();
  form.title("Shop");
  form.body(`O que deseja?`);
  form.button(`§f5 Salmon\nPrice: ${general.getScore("belly", player) >= 75 ? "§a75" : "§c75"}`);
  form.button(`§f3 Bread\nPrice: ${general.getScore("belly", player) >= 100 ? "§a100" : "§c100"}`);
  form.button(`§f1 Golden Key\nPrice: ${general.getScore("belly", player) >= 300 ? "§a300" : "§c300"}`);
  form.button("back");
  form.show(player).then((r) => {
    if (r.selection === 0) {
      if (general.getScore("belly", player) >= 75) {
        player.runCommandAsync("give @s cooked_salmon 5");
        player.runCommandAsync("scoreboard players remove @s belly 75");
      } else player.runCommandAsync(`tellraw @s {"rawtext": [{"text": "§c"}, {"translate": "text.requires"}, {"text": " 75 belly"}]}`);
    }
    if (r.selection === 1) {
      if (general.getScore("belly", player) >= 100) {
        player.runCommandAsync("give @s bread 3");
        player.runCommandAsync("scoreboard players remove @s belly 100");
      } else player.runCommandAsync(`tellraw @s {"rawtext": [{"text": "§c"}, {"translate": "text.requires"}, {"text": " 100 belly"}]}`);
    }
    if (r.selection === 2) {
      if (general.getScore("belly", player) >= 300) {
        player.runCommandAsync("give @s wesl3y:key_chest 1");
        player.runCommandAsync("scoreboard players remove @s belly 300");
      } else player.runCommandAsync(`tellraw @s {"rawtext": [{"text": "§c"}, {"translate": "text.requires"}, {"text": " 300 belly"}]}`);
    }
  }
);}

export function wg_arlong(player) {
  const form = new ui.ActionFormData();
  form.title("Shop");
  form.body(`O que deseja?`);
  form.button(`§f1 Pirate Haori\nPrice: ${general.getScore("belly", player) >= 500 ? "§a500" : "§c500"}`);
  form.button(`§f1 Katana\nPrice: ${general.getScore("belly", player) >= 300 ? "§a300" : "§c300"}`);
  form.button(`§f1 Golden Apple\nPrice: ${general.getScore("belly", player) >= 150 ? "§a150" : "§c150"}`);
  form.button(`§f1 Sake\nPrice: ${general.getScore("belly", player) >= 300 ? "§a300" : "§c300"}`);
  form.show(player).then((r) => {
    if (r.selection === 0) {
      if (general.getScore("belly", player) >= 500) {
        player.runCommandAsync("give @s wesl3y:pirate_haori 1");
        player.runCommandAsync("scoreboard players remove @s belly 500");
      } else player.runCommandAsync(`tellraw @s {"rawtext": [{"text": "§c"}, {"translate": "text.requires"}, {"text": " 500 belly"}]}`);
    }
    if (r.selection === 1) {
      if (general.getScore("belly", player) >= 300) {
        player.runCommandAsync("give @s wesl3y:katana 1");
        player.runCommandAsync("scoreboard players remove @s belly 300");
      } else player.runCommandAsync(`tellraw @s {"rawtext": [{"text": "§c"}, {"translate": "text.requires"}, {"text": " 300 belly"}]}`);
    }
    if (r.selection === 2) {
      if (general.getScore("belly", player) >= 150) {
        player.runCommandAsync("give @s golden_apple 1");
        player.runCommandAsync("scoreboard players remove @s belly 150");
      } else player.runCommandAsync(`tellraw @s {"rawtext": [{"text": "§c"}, {"translate": "text.requires"}, {"text": " 150 belly"}]}`);
    }
    if (r.selection === 3) {
      if (general.getScore("belly", player) >= 300) {
        player.runCommandAsync("give @s wesl3y:sake 1");
        player.runCommandAsync("scoreboard players remove @s belly 300");
      } else player.runCommandAsync(`tellraw @s {"rawtext": [{"text": "§c"}, {"translate": "text.requires"}, {"text": " 300 belly"}]}`);
    }
  }
);}

export function baratie1(player) {
  const form = new ui.ActionFormData();
  form.title("Mission");
  form.body(`             Quest Don Kriet\n\nLevel Required: 15\nDefeat: Gin\nDefeat: Don Krieg.\nReward:\n§a$100\n§e50 Exp\n§rDrop <§7Golden Armor§r>.`);
  form.button("Don Krieg");
  form.button("Sanji");
  form.button("Mihawk");
  form.button("Esquecer");
  form.button("Confirm");
  form.show(player).then((r) => {
    if (r.selection === 0) {
      baratie1(player);
    }
    if (r.selection === 1) {
      baratie2(player);
    }
    if (r.selection === 2) {
      baratie3(player);
    }
    if (r.selection === 3) {}
    if (r.selection === 4) {
      if (!player.hasTag("in_mission") && general.getScore("level", player) >= 15 && general.getScore("level", player) <= 50) {
        player.runCommandAsync("scoreboard players set @s mission 0");
        player.runCommandAsync("function mission/start");
      } else {
        player.runCommandAsync(`tellraw @s[tag=in_mission] {"rawtext":[{"translate": "mission.in"},{"text": "§f"}]}`);
        player.runCommandAsync(`tellraw @s[scores={level=!15..50}] {"rawtext":[{"text": "§c"},{"translate": "text.requires"},{"text": "Level 15..50§f"}]}`); }
    }
  }
);}

export function baratie2(player) {
  const form = new ui.ActionFormData();
  form.title("Mission");
  form.body(`             Quest Sanji\n\nLevel Required: 30\nDefeat: Sanji.\nReward:\n§a$60\n§e30 Exp\n§rDrop <§5Cigarette§r>\nDrop <§5Black Leg§r>.`);
  form.button("Don Krieg");
  form.button("Sanji");
  form.button("Mihawk");
  form.button("Esquecer");
  form.button("Confirm");
  form.show(player).then((r) => {
    if (r.selection === 0) {
      baratie1(player);
    }
    if (r.selection === 1) {
      baratie2(player);
    }
    if (r.selection === 2) {
      baratie3(player);
    }
    if (r.selection === 3) {}
    if (r.selection === 4) {
      if (!player.hasTag("in_mission") && general.getScore("level", player) >= 30) {
        player.runCommandAsync("scoreboard players set @s mission 1");
        player.runCommandAsync("function mission/start");
      } else {
        player.runCommandAsync(`tellraw @s[tag=in_mission] {"rawtext":[{"translate": "mission.in"},{"text": "§f"}]}`);
        player.runCommandAsync(`tellraw @s[scores={level=!30..}] {"rawtext":[{"text": "§c"},{"translate": "text.requires"},{"text": "Level 30§f"}]}`); }
    }
  }
);}

export function baratie3(player) {
  const form = new ui.ActionFormData();
  form.title("Mission");
  form.body(`             Quest Mihawk\n\nLevel Required: 100\nDefeat: Mihawk.\nReward:\n§a$200\n§e100 Exp\n§rDrop <§5Mihawk Coat§r>\n§rDrop <§5Mihawk Hat§r>\nDrop <§aYoru§r>.`);
  form.button("Don Krieg");
  form.button("Sanji");
  form.button("Mihawk");
  form.button("Esquecer");
  form.button("Confirm");
  form.show(player).then((r) => {
    if (r.selection === 0) {
      baratie1(player);
    }
    if (r.selection === 1) {
      baratie2(player);
    }
    if (r.selection === 2) {
      baratie3(player);
    }
    if (r.selection === 3) {}
    if (r.selection === 4) {
      if (!player.hasTag("in_mission") && general.getScore("level", player) >= 100) {
        player.runCommandAsync("scoreboard players set @s mission 2");
        player.runCommandAsync("function mission/start");
      } else {
        player.runCommandAsync(`tellraw @s[tag=in_mission] {"rawtext":[{"translate": "mission.in"},{"text": "§f"}]}`);
        player.runCommandAsync(`tellraw @s[scores={level=!100..}] {"rawtext":[{"text": "§c"},{"translate": "text.requires"},{"text": "Level 100§f"}]}`); }
    }
  }
);}

export function arlong_park1(player) {
  const form = new ui.ActionFormData();
  form.title("Mission");
  form.body(`             Quest Chew\n\nLevel Required: 50\nDefeat: Chew.\nReward:\n§a$90\n§e45 Exp.`);
  form.button("Chew");
  form.button("Kuroobi");
  form.button("Arlong");
  form.button("Esquecer");
  form.button("Confirm");
  form.show(player).then((r) => {
    if (r.selection === 0) {
      arlong_park1(player);
    }
    if (r.selection === 1) {
      arlong_park2(player);
    }
    if (r.selection === 2) {
      arlong_park3(player);
    }
    if (r.selection === 3) {}
    if (r.selection === 4) {
      if (!player.hasTag("in_mission") && general.getScore("level", player) >= 50 && general.getScore("level", player) <= 70) {
        player.runCommandAsync("scoreboard players set @s mission 3");
        player.runCommandAsync("function mission/start");
      } else {
        player.runCommandAsync(`tellraw @s[tag=in_mission] {"rawtext":[{"translate": "mission.in"},{"text": "§f"}]}`);
        player.runCommandAsync(`tellraw @s[scores={level=!50..70}] {"rawtext":[{"text": "§c"},{"translate": "text.requires"},{"text": "Level 50..70§f"}]}`); }
    }
  }
);}

export function arlong_park2(player) {
  const form = new ui.ActionFormData();
  form.title("Mission");
  form.body(`             Quest Kuroobi\n\nLevel Required: 55\nDefeat: Kuroobi.\nReward:\n§a$110\n§e55 Exp.`);
  form.button("Chew");
  form.button("Kuroobi");
  form.button("Arlong");
  form.button("Esquecer");
  form.button("Confirm");
  form.show(player).then((r) => {
    if (r.selection === 0) {
      arlong_park1(player);
    }
    if (r.selection === 1) {
      arlong_park2(player);
    }
    if (r.selection === 2) {
      arlong_park3(player);
    }
    if (r.selection === 3) {}
    if (r.selection === 4) {
      if (!player.hasTag("in_mission") && general.getScore("level", player) >= 55 && general.getScore("level", player) <= 70) {
        player.runCommandAsync("scoreboard players set @s mission 4");
        player.runCommandAsync("function mission/start");
      } else {
        player.runCommandAsync(`tellraw @s[tag=in_mission] {"rawtext":[{"translate": "mission.in"},{"text": "§f"}]}`);
        player.runCommandAsync(`tellraw @s[scores={level=!55..70}] {"rawtext":[{"text": "§c"},{"translate": "text.requires"},{"text": "Level 55..70§f"}]}`); }
    }
  }
);}

export function arlong_park3(player) {
  const form = new ui.ActionFormData();
  form.title("Mission");
  form.body(`             Quest Arlong\n\nLevel Required: 60\nDefeat: Arlong.\nReward:\n§a$130\n§e65 Exp\n§rDrop <§rKiribachi§r>.`);
  form.button("Chew");
  form.button("Kuroobi");
  form.button("Arlong");
  form.button("Esquecer");
  form.button("Confirm");
  form.show(player).then((r) => {
    if (r.selection === 0) {
      arlong_park1(player);
    }
    if (r.selection === 1) {
      arlong_park2(player);
    }
    if (r.selection === 2) {
      arlong_park3(player);
    }
    if (r.selection === 3) {}
    if (r.selection === 4) {
      if (!player.hasTag("in_mission") && general.getScore("level", player) >= 60 && general.getScore("level", player) >= 70) {
        player.runCommandAsync("scoreboard players set @s mission 5");
        player.runCommandAsync("function mission/start");
      } else {
        player.runCommandAsync(`tellraw @s[tag=in_mission] {"rawtext":[{"translate": "mission.in"},{"text": "§f"}]}`);
        player.runCommandAsync(`tellraw @s[scores={level=!60..70}] {"rawtext":[{"text": "§c"},{"translate": "text.requires"},{"text": "Level 60..70§f"}]}`); }
    }
  }
);}