import * as mc from "@minecraft/server";
import * as ui from "@minecraft/server-ui";

export function addScore(objective) { mc.world.scoreboard.addObjective(objective, objective); }

export function getScore(objective, player) { try { return mc.world.scoreboard.getObjective(objective).getScore(player.scoreboardIdentity); } catch (error) { return 0; } }

export const overworld = mc.world.getDimension("overworld"), nether = mc.world.getDimension("nether"), theEnd = mc.world.getDimension("the end");

export function number(value) { const ranges = [ { divider: 1e9, suffix: "b" }, { divider: 1e6, suffix: "m" }, { divider: 1e3, suffix: "k" }, ]; for (const range of ranges) if (value >= range.divider) return ((value / range.divider).toFixed(1) + range.suffix).toString(); return value; }

export function tick1(callback) { mc.system.runInterval((data) => { for (const player of mc.world.getPlayers()) { callback(player); } }, 1); }

export function tick5(callback) { mc.system.runInterval((data) => { for (const player of mc.world.getPlayers()) { callback(player); } }, 5); }

export function tick10(callback) { mc.system.runInterval((data) => { for (const player of mc.world.getPlayers()) { callback(player); } }, 10); }

export function random(min, max) { return Math.floor(Math.random() * (max - min + 1)) + min; }

export function fruit(player, fruit) {
  player.runCommand(`clear @s wesl3y:${fruit}_fruit 0 1`);
  player.runCommand(`kill @s[tag=devil_fruit]`);
  player.runCommand(`execute at @s[m=1] run function player/fruit/reset`);
  player.runCommand(`tag @s[m=1] remove devil_fruit`);
  player.runCommand(`execute if entity @e[tag=${fruit}_fruit] at @s run tellraw @s {"rawtext":[{"text":"Devil Fruit Used"}]}`);
  player.runCommand(`execute unless entity @e[tag=${fruit}_fruit] run tag @s[tag=!devil_fruit] add ${fruit}_fruit`);
  player.runCommand(`event entity @s[tag=!devil_fruit,tag=${fruit}_fruit] wesl3y:devil_fruit`);
}

export function skill(player, skill, skillCur, cooldown, commando1, commando2, commando3, commando4, mode) {
  const
    emptyProperty = player.getProperty("wesl3y:empty"),
    modeProperty = player.getProperty("wesl3y:mode"),
    skillProperty = player.getProperty("wesl3y:skill"),
    slotSkillProperty = getScore("slotSkill", player),
    cooldownScore = getScore(cooldown, player),
    skillC = skill - 1,
    hurt = getScore("hurtCur", player),
    modeC = mode == "all" ? "all" : mode > 0 ? mode : "0";
  if (mode == "all") {
    if (emptyProperty == 0 && modeProperty != 0 && skillProperty == 0 && slotSkillProperty == skillC && cooldownScore == 0 && hurt == 0) {
      player.runCommand(`tellraw @s[scores={fruitMaes=..${skillCur - 1}}] {"rawtext":[{"text":"§c"}, {"translate":"text.requires"}, {"text":"Fruit ${skillCur}"}]}`);
      player.runCommand(`tellraw @s[scores={fruitMaes=${skillCur}..,energyCur=..49}] {"rawtext":[{"text":"§c"}, {"translate":"text.requires"}, {"text":"Energy 50"}]}`);
      player.runCommand(`event entity @s[scores={fruitMaes=${skillCur}..,energyCur=50..}] wesl3y:skill${skill}`);
    }
  } else {
    if (emptyProperty == 0 && modeProperty == modeC && skillProperty == 0 && slotSkillProperty == skillC && cooldownScore == 0 && hurt == 0) {
      player.runCommand(`tellraw @s[scores={fruitMaes=..${skillCur - 1}}] {"rawtext":[{"text":"§c"}, {"translate":"text.requires"}, {"text":"Fruit ${skillCur}"}]}`);
      player.runCommand(`tellraw @s[scores={fruitMaes=${skillCur}..,energyCur=..49}] {"rawtext":[{"text":"§c"}, {"translate":"text.requires"}, {"text":"Energy 50"}]}`);
      player.runCommand(`event entity @s[scores={fruitMaes=${skillCur}..,energyCur=50..}] wesl3y:skill${skill}`);
    }
  }
}

export function skill2(player, skill, skillCur, cooldown, commando1, commando2, commando3, commando4) {
  const
    emptyProperty = player.getProperty("wesl3y:empty"),
    skillProperty = player.getProperty("wesl3y:skill"),
    slotSkillProperty = getScore("slotSkill2", player),
    cooldownScore = getScore(cooldown, player),
    skillC = skill - 1,
    hurt = getScore("hurtCur", player);
  if (emptyProperty == 0 && skillProperty == 0 && slotSkillProperty == skillC && cooldownScore == 0 && hurt == 0) {
      player.runCommand(`tellraw @s[scores={styleMaes=..${skillCur - 1}}] {"rawtext":[{"text":"§c"}, {"translate":"text.requires"}, {"text":"Style ${skillCur}"}]}`);
      player.runCommand(`tellraw @s[scores={styleMaes=${skillCur}..,energyCur=..49}] {"rawtext":[{"text":"§c"}, {"translate":"text.requires"}, {"text":"Energy 50"}]}`);
      player.runCommand(`event entity @s[scores={styleMaes=${skillCur}..,energyCur=50..}] wesl3y:skill${skill}`);
  }
}