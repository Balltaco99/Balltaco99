import * as general from "./general.js";

export const QUEST = {
  list: [
/*  {
      belly: 20% da vida total
      point: 1 ou 2
      reward: raiz quadrada da recompensa vdd
      text: "mission."
      xp: 50% do belly
      enemies: [
        "wesl3y:"
      ]
    },*/
    {
      belly: 100,
      summon: false,
      point: 4,
      reward: 0,
      text: "mission.don_krieg",
      xpmin: 50,
      xpmax: 70,
      enemies: [
        "wesl3y:gin",
        "wesl3y:don_krieg"
      ]
    },
    {
      belly: 60,
      summon: true,
      point: 2,
      reward: 0,
      text: "mission.sanji",
      xpmin: 30,
      xpmax: 50,
      enemies: [
        "wesl3y:sanji"
      ]
    },
    {
      belly: 200,
      summon: true,
      point: 4,
      reward: 0,
      text: "mission.yoru",
      xpmin: 100,
      xpmax: 120,
      event: "minecraft:mission",
      enemies: [
        "wesl3y:mihawk"
      ]
    },
    {
      belly: 90,
      summon: true,
      point: 1,
      reward: 0,
      text: "mission.chew",
      xpmin: 45,
      xpmax: 65,
      enemies: [
        "wesl3y:chew"
      ]
    },
    {
      belly: 110,
      levelmin: 50,
      levelmax: 200,
      summon: true,
      point: 2,
      reward: 0,
      text: "mission.kuroobi",
      xpmin: 55,
      xpmax: 75,
      enemies: [
        "wesl3y:kuroobi"
      ]
    },
    {
      belly: 130,
      levelmin: 60,
      levelmax: 200,
      summon: true,
      point: 3,
      reward: 0,
      text: "mission.arlong",
      xpmin: 65,
      xpmax: 85,
      enemies: [
        "wesl3y:arlong"
      ]
    }
  ]
};