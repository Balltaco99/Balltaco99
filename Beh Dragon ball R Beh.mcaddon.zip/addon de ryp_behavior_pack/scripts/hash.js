import * as mc from "@minecraft/server";

export function random(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

export function getScore(player, objective) {
  try {
    return mc.world.scoreboard.getObjective(objective).getScore(player.scoreboardIdentity)
  } catch (error) {
    return 0
  } 
}

export function addScore(player, objective, value) {
  player.runCommandAsync("scoreboard players add @s " + objective + " " + value)
}

export function removeScore(player, objective, value) {
  player.runCommandAsync("scoreboard players remove @s " + objective + " " + value)
}

export function setScore(player, objective, value) {
  player.runCommandAsync("scoreboard players set @s " + objective + " " + value)
}