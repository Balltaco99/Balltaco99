import { world, system, EntityDamageCause } from '@minecraft/server'

world.afterEvents.entityHurt.subscribe((data) => {
    if (data.hurtEntity.typeId != 'dmgnumbers:damage_number') {
        const loc = data.hurtEntity.location
        const dmgnumber = world.getDimension(data.hurtEntity.dimension.id).spawnEntity('dmgnumbers:damage_number', { x: loc.x, y: loc.y + 0, z: loc.z })
        const number = Math.floor(data.damage * 10) / 10
        let color = '§e'
        if (number > 9.9) {
            color = '§c'
        }
        if (number > 19.9) {
            color = '§4'
        }
        if (data.damageSource.cause == EntityDamageCause.fire || data.damageSource.cause == EntityDamageCause.fireTick) {
            color = '§6'
        } else if (data.damageSource.cause == EntityDamageCause.drowning) {
            color = '§9'
        }
        dmgnumber.applyImpulse({
            x: -data.hurtEntity.getVelocity().x * 1.2, y: 0.5, z: -data.hurtEntity.getVelocity().z * 1.2
        })
        dmgnumber.nameTag = color + JSON.stringify(number)
        system.runTimeout(() => {
            dmgnumber.remove()
        }, 20)
    }
})