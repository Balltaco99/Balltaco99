import * as mc from "@minecraft/server";
import * as ui from "@minecraft/server-ui";
import * as hs from "./hash.js";

mc.world.afterEvents.entityHitEntity.subscribe((data) => {
    const player = data.damagingEntity;
    const hitEntity = data.hitEntity;
    if (player && hitEntity && hitEntity.typeId === "stk:freezanpc") {
        menu(player);
    }
});

function menu(player) {
  const data = new ui.ActionFormData()
    .title("menu")
    .body("")
    .button("shop", "textures/custom/npc/shop")
    .button("techniques", "textures/custom/npc/tech")
    .show(player).then((r) => {
      switch (r.selection) {
      }
      if (r.selection === 0) {
        shop(player);
      }
      if (r.selection === 1) {
        technpc(player);
      }
    })
}
function shop(player) {
  const data = new ui.ActionFormData()
    .title("menu")
    .body("")
    .button("armor \nzeni: 100", "textures/items/armor")
    .button("armor \nzeni: 100", "textures/items/armor2")
    .button("armor \nzeni: 100", "textures/items/armor3")
    .button("armor \nzeni: 100", "textures/items/armor4")
    .button("armor \nzeni: 100", "textures/items/armor4_1")
    .button("armor \nzeni: 100", "textures/items/armor5")
    .button("armor \nzeni: 100", "textures/items/armor5_1")
    .button("armor \nzeni: 100", "textures/items/armor6")
    .button("armor \nzeni: 100", "textures/items/armor6_1")
    .button("armor \nzeni: 100", "textures/items/armor7")
    .button("Saibaman seed \nzeni: 100", "textures/items/saibaegg")
    .show(player).then((r) => {
      switch (r.selection) {
      }
      if (r.selection === 0) {
        player.runCommandAsync(`give @p[scores={zeni=100..}] stk:armor`);
      }
      if (r.selection === 0) {
        player.runCommandAsync(`scoreboard players remove @p[scores={zeni=100..}] zeni 100`);
      }
      if (r.selection === 1) {
        player.runCommandAsync(`give @p[scores={zeni=100..}] stk:armor2`);
      }
      if (r.selection === 1) {
        player.runCommandAsync(`scoreboard players remove @p[scores={zeni=100..}] zeni 100`);
      }
      if (r.selection === 2) {
        player.runCommandAsync(`give @p[scores={zeni=100..}] stk:armor3`);
      }
      if (r.selection === 2) {
        player.runCommandAsync(`scoreboard players remove @p[scores={zeni=100..}] zeni 100`);
      }
      if (r.selection === 3) {
        player.runCommandAsync(`give @p[scores={zeni=100..}] stk:armor4`);
      }
      if (r.selection === 3) {
        player.runCommandAsync(`scoreboard players remove @p[scores={zeni=100..}] zeni 100`);
      }
      if (r.selection === 4) {
        player.runCommandAsync(`give @p[scores={zeni=100..}] stk:armor4_1`);
      }
      if (r.selection === 4) {
        player.runCommandAsync(`scoreboard players remove @p[scores={zeni=100..}] zeni 100`);
      }
      if (r.selection === 5) {
        player.runCommandAsync(`give @p[scores={zeni=100..}] stk:armor5`);
      }
      if (r.selection === 5) {
        player.runCommandAsync(`scoreboard players remove @p[scores={zeni=100..}] zeni 100`);
      }
      if (r.selection === 6) {
        player.runCommandAsync(`give @p[scores={zeni=100..}] stk:armor5_1`);
      }
      if (r.selection === 6) {
        player.runCommandAsync(`scoreboard players remove @p[scores={zeni=100..}] zeni 100`);
      }
      if (r.selection === 7) {
        player.runCommandAsync(`give @p[scores={zeni=100..}] stk:armor6`);
      }
      if (r.selection === 7) {
        player.runCommandAsync(`scoreboard players remove @p[scores={zeni=100..}] zeni 100`);
      }
      if (r.selection === 8) {
        player.runCommandAsync(`give @p[scores={zeni=100..}] stk:armor6_1`);
      }
      if (r.selection === 8) {
        player.runCommandAsync(`scoreboard players remove @p[scores={zeni=100..}] zeni 100`);
      }
      if (r.selection === 9) {
        player.runCommandAsync(`give @p[scores={zeni=100..}] stk:armor7`);
      }
      if (r.selection === 9) {
        player.runCommandAsync(`scoreboard players remove @p[scores={zeni=100..}] zeni 100`);
      }
      if (r.selection === 10) {
        player.runCommandAsync(`give @p[scores={zeni=100..}] stk:saibamen_spawn_egg 6`);
      }
      if (r.selection === 10) {
        player.runCommandAsync(`scoreboard players remove @p[scores={zeni=100..}] zeni 100`);
      }
    })
}
function technpc(player) {
  const data = new ui.ActionFormData()
    .title("menu")
    .body("")
    .button("supernova \nzeni: 10000", "textures/items/supernova")
    .show(player).then((r) => {
      switch (r.selection) {
      }
      if (r.selection === 0) {
        player.runCommandAsync(`give @p[scores={zeni=10000..}] stnk:supernova`);
      }
      if (r.selection === 0) {
        player.runCommandAsync(`scoreboard players remove @p[scores={zeni=10000..}] zeni 10000`);
      }
    })
}