import * as mc from "@minecraft/server";
import * as ui from "@minecraft/server-ui";
import * as hs from "./hash.js";

mc.world.afterEvents.entityHitEntity.subscribe((data) => {
    const player = data.damagingEntity;
    const hitEntity = data.hitEntity;
    if (player && hitEntity && hitEntity.typeId === "stk:trunksnpc") {
        menu(player);
    }
});

function menu(player) {
  const data = new ui.ActionFormData()
    .title("menu")
    .body("")
    .button("techniques", "textures/custom/npc/tech")
    .show(player).then((r) => {
      switch (r.selection) {
      }
      if (r.selection === 0) {
        technpc(player);
      }
    })
}
function technpc(player) {
  const data = new ui.ActionFormData()
    .title("menu")
    .body("")
    .button("kiblast \nzeni: 100", "textures/items/kiblast")
    .button("Galick ho \nzeni: 5000", "textures/items/galick")
    .button("Masenko \nzeni: 5000", "textures/items/masenko")
    .button("Final shine \nzeni: 5000", "textures/items/fshine")
    .button("Ki scythe \nzeni: 20000 \nRose fragment", "textures/items/kifoice")
    .button("Mirai sword \nzeni: 15000 \nBroken sword", "textures/items/msword")
    .show(player).then((r) => {
      switch (r.selection) {
      }
      if (r.selection === 0) {
        player.runCommandAsync(`give @p[scores={zeni=100..}] stnk:kiblast`);
      }
      if (r.selection === 0) {
        player.runCommandAsync(`scoreboard players remove @p[scores={zeni=100..}] zeni 100`);
      }
      if (r.selection === 1) {
        player.runCommandAsync(`give @p[scores={zeni=5000..}] stk:galick`);
      }
      if (r.selection === 1) {
        player.runCommandAsync(`scoreboard players remove @p[scores={zeni=5000..}] zeni 5000`);
      }
      if (r.selection === 2) {
        player.runCommandAsync(`give @p[scores={zeni=5000..}] stk:masenko`);
      }
      if (r.selection === 2) {
        player.runCommandAsync(`scoreboard players remove @p[scores={zeni=5000..}] zeni 5000`);
      }
      if (r.selection === 3) {
        player.runCommandAsync(`give @p[scores={zeni=5000..}] stk:fshine`);
      }
      if (r.selection === 3) {
        player.runCommandAsync(`scoreboard players remove @p[scores={zeni=5000..}] zeni 5000`);
      }
      if (r.selection === 4) {
        player.runCommandAsync(`function bkifoice`);
      }
      if (r.selection === 5) {
        player.runCommandAsync(`function bmsword`);
      }
    })
}