import * as mc from "@minecraft/server";
import * as ui from "@minecraft/server-ui";
import * as hs from "./hash.js";

mc.world.afterEvents.itemUse.subscribe((data) => {
  const player = data.source;
  if (player && data.itemStack.typeId?.toLowerCase() === "n:menu")
    custom(player);
});

function custom(player) {
  const data = new ui.ActionFormData()
    .title("custom")
    .body("")
    .button("raca", "textures/custom/raca/uii.2")
    .button("color", "textures/custom/color/uii.2")
    .button("hair", "textures/custom/hair/uii.2")
    .button("camisa", "textures/custom/camisa/uii.2")
    .button("calca", "textures/custom/calca/uii.2")
    .button("complete", "textures/custom/ceta")
    .show(player).then((r) => {
      switch (r.selection) {
      }
      if (r.selection === 0) {
        raca(player);
      }
      if (r.selection === 1) {
        color(player);
      }
      if (r.selection === 2) {
        hair(player);
      }
      if (r.selection === 3) {
        camisa(player);
      }
      if (r.selection === 4) {
        calca(player);
      }
      if (r.selection === 5) {
        player.runCommandAsync(`function givemenu`);
      }
    })
}
function customfiza(player) {
  const data = new ui.ActionFormData()
    .title("custom")
    .body("")
    .button("raca", "textures/custom/raca/uii.2")
    .button("color", "textures/custom/color/uii.2")
    .button("camisa", "textures/custom/camisa/uii.2")
    .button("calca", "textures/custom/calca/uii.2")
    .button("complete", "textures/custom/ceta")
    .show(player).then((r) => {
      switch (r.selection) {
      }
      if (r.selection === 0) {
        raca(player);
      }
      if (r.selection === 1) {
        colorfiza(player);
      }
      if (r.selection === 2) {
        camisafiza(player);
      }
      if (r.selection === 3) {
        calcafiza(player);
      }
      if (r.selection === 4) {
        player.runCommandAsync(`function givemenu`);
      }
    })
}
function customnamek(player) {
  const data = new ui.ActionFormData()
    .title("custom")
    .body("")
    .button("raca", "textures/custom/raca/uii.2")
    .button("color", "textures/custom/color/uii.2")
    .button("camisa", "textures/custom/camisa/uii.2")
    .button("calca", "textures/custom/calca/uii.2")
    .button("complete", "textures/custom/ceta")
    .show(player).then((r) => {
      switch (r.selection) {
      }
      if (r.selection === 0) {
        raca(player);
      }
      if (r.selection === 1) {
        colornamek(player);
      }
      if (r.selection === 2) {
        camisafiza(player);
      }
      if (r.selection === 3) {
        calcafiza(player);
      }
      if (r.selection === 4) {
        player.runCommandAsync(`function givemenu`);
      }
    })
}
function raca(player, btns) {
  const data = new ui.ActionFormData()
    .title("raca")
    .body("")
    .button("saiyajin", "textures/custom/raca/ui.0")
    .button("human", "textures/custom/raca/ui.1")
    .button("arcosian", "textures/custom/raca/ui.2")
    .button("arcosian", "textures/custom/raca/ui.3")
    .show(player).then((r) => {
      switch (r.selection) {
      }
      if (r.selection === 0) {
          custom(player);
        player.runCommandAsync(`event entity @s saiyan`);
      }
      if (r.selection === 0) {
          custom(player);
        player.runCommandAsync(`function saiyan`);
      }
      if (r.selection === 1) {
          custom(player);
        player.runCommandAsync(`event entity @s humano`);
      }
      if (r.selection === 1) {
          custom(player);
        player.runCommandAsync(`function human`);
      }
      if (r.selection === 2) {
          customfiza(player);
        player.runCommandAsync(`event entity @s arcosian`);
      }
      if (r.selection === 2) {
          custom(player);
        player.runCommandAsync(`function arcosian`);
      }
      if (r.selection === 3) {
          customnamek(player);
        player.runCommandAsync(`event entity @s namek`);
      }
      if (r.selection === 3) {
          custom(player);
        player.runCommandAsync(`function namek`);
      }
    })
}
function color(player, btns) {
  const data = new ui.ActionFormData()
    .title("color")
    .body("")
    .button("cor", "textures/custom/color/ui.0")
    .button("cor2", "textures/custom/color/ui.1")
    .button("cor3", "textures/custom/color/ui.2")
    .show(player).then((r) => {
      switch (r.selection) {
      }
      if (r.selection === 0) {
          custom(player);
        player.runCommandAsync(`event entity @s cor0`);
      }
      if (r.selection === 1) {
          custom(player);
        player.runCommandAsync(`event entity @s cor1`);
      }
      if (r.selection === 2) {
          custom(player);
        player.runCommandAsync(`event entity @s cor2`);
      }
    })
}
function colorfiza(player, btns) {
  const data = new ui.ActionFormData()
    .title("color")
    .body("")
    .button("cor", "textures/custom/color/fiza")
    .button("cor2", "textures/custom/color/fiza1")
    .button("cor3", "textures/custom/color/fiza2")
    .button("cor4", "textures/custom/color/fiza3")
    .button("cor5", "textures/custom/color/fiza4")
    .show(player).then((r) => {
      switch (r.selection) {
      }
      if (r.selection === 0) {
          custom(player);
        player.runCommandAsync(`event entity @s cor0`);
      }
      if (r.selection === 1) {
          customfiza(player);
        player.runCommandAsync(`event entity @s cor1`);
      }
      if (r.selection === 2) {
          customfiza(player);
        player.runCommandAsync(`event entity @s cor2`);
      }
      if (r.selection === 3) {
          customfiza(player);
        player.runCommandAsync(`event entity @s f`);
      }
      if (r.selection === 4) {
          customfiza(player);
        player.runCommandAsync(`event entity @s f2`);
      }
    })
}
function colornamek(player, btns) {
  const data = new ui.ActionFormData()
    .title("color")
    .body("")
    .button("cor", "textures/custom/color/namek")
    .button("cor2", "textures/custom/color/namek1")
    .button("cor3", "textures/custom/color/namek2")
    .show(player).then((r) => {
      switch (r.selection) {
      }
      if (r.selection === 0) {
          customnamek(player);
        player.runCommandAsync(`event entity @s cor0`);
      }
      if (r.selection === 1) {
          customnamek(player);
        player.runCommandAsync(`event entity @s cor1`);
      }
      if (r.selection === 2) {
          customnamek(player);
        player.runCommandAsync(`event entity @s cor2`);
      }
    })
}
function hair(player, btns) {
  const data = new ui.ActionFormData()
    .title("hair")
    .body("")
    .button("goku", "textures/custom/hair/ui.0")
    .button("gohan", "textures/custom/hair/ui.1")
    .button("trunks", "textures/custom/hair/ui.2")
    .button("android", "textures/custom/hair/ui.3")
    .button("vegeta", "textures/custom/hair/ui.4")
    .button("teengohan", "textures/custom/hair/ui.6")
    .button("goten", "textures/custom/hair/ui.7")
    .button("bald", "textures/custom/hair/ui.5")
    .show(player).then((r) => {
      switch (r.selection) {
      }
      if (r.selection === 0) {
          custom(player);
        player.runCommandAsync(`event entity @s hair0`);
      }
      if (r.selection === 1) {
          custom(player);
        player.runCommandAsync(`event entity @s hair1`);
      }
      if (r.selection === 2) {
          custom(player);
        player.runCommandAsync(`event entity @s hair2`);
      }
      if (r.selection === 3) {
          custom(player);
        player.runCommandAsync(`event entity @s hair3`);
      }
      if (r.selection === 4) {
          custom(player);
        player.runCommandAsync(`event entity @s hair4`);
      }
      if (r.selection === 5) {
          custom(player);
        player.runCommandAsync(`event entity @s hair6`);
      }
      if (r.selection === 6) {
          custom(player);
        player.runCommandAsync(`event entity @s hair7`);
      }
      if (r.selection === 7) {
          custom(player);
        player.runCommandAsync(`event entity @s hair.no`);
        
      }
    })
}
function camisa(player) {
  const data = new ui.ActionFormData()
    .title("camisa")
    .body("")
    .button("goku", "textures/custom/camisa/ui.0")
    .button("goku black", "textures/custom/camisa/ui.1")
    .button("gohan", "textures/custom/camisa/ui.2")
    .button("trunks", "textures/custom/camisa/ui.3")
    .button("metadinha", "textures/custom/camisa/ui.4")
    .button("vegeta", "textures/custom/camisa/ui.5")
    .button("vegeta (buu)", "textures/custom/camisa/mvegeta")
    .button("goku (Black)", "textures/custom/camisa/bgoku")
    .button("trunks (Future)", "textures/custom/camisa/mtrunks")
    .button("trunks (kid)", "textures/custom/camisa/ktrunks")
    .button("goten", "textures/custom/camisa/goten")
    .button("ryp", "textures/custom/camisa/ryp")
    .button("nobody", "textures/custom/hair/ui.5")
    
    .show(player).then((r) => {
      switch (r.selection) {
      }
      if (r.selection === 0) {
          custom(player);
        player.runCommandAsync(`event entity @s goku`);
      }
      if (r.selection === 1) {
          custom(player);
        player.runCommandAsync(`event entity @s gokub`);
      }
      if (r.selection === 2) {
          custom(player);
        player.runCommandAsync(`event entity @s gohan`);
      }
      if (r.selection === 3) {
          custom(player);
        player.runCommandAsync(`event entity @s trunks`);
      }
      if (r.selection === 4) {
          custom(player);
        player.runCommandAsync(`event entity @s strong`);
      }
      if (r.selection === 5) {
          custom(player);
        player.runCommandAsync(`event entity @s vegeta`);
      }
      if (r.selection === 6) {
          custom(player);
        player.runCommandAsync(`event entity @s mvegeta`);
      }
      if (r.selection === 7) {
          custom(player);
        player.runCommandAsync(`event entity @s bgoku`);
      }
      if (r.selection === 8) {
          custom(player);
        player.runCommandAsync(`event entity @s mtrunks`);
      }
      if (r.selection === 9) {
          custom(player);
        player.runCommandAsync(`event entity @s ktrunks`);
      }
      if (r.selection === 10) {
          custom(player);
        player.runCommandAsync(`event entity @s goten`);
      }
      if (r.selection === 11) {
          custom(player);
        player.runCommandAsync(`event entity @s ryp`);
      }
      if (r.selection === 12) {
          custom(player);
        player.runCommandAsync(`event entity @s body.no`);
        
      }
    })
}
function calca(player) {
  const data = new ui.ActionFormData()
    .title("calca")
    .body("")
    .button("goku", "textures/custom/calca/ui.0")
    .button("goku black", "textures/custom/calca/ui.1")
    .button("gohan", "textures/custom/calca/ui.2")
    .button("trunks", "textures/custom/calca/ui.3")
    .button("metadinha", "textures/custom/calca/ui.4")
    .button("vegeta", "textures/custom/calca/ui.5")
    .button("goku (black)", "textures/custom/calca/bgokul")
    .button("trunks (kid)", "textures/custom/calca/ktrunksl")
    .button("goten", "textures/custom/calca/gotenl")
    .button("ryp", "textures/custom/calca/rypl")
    .button("nolegs", "textures/custom/hair/ui.5")
    .show(player).then((r) => {
      switch (r.selection) {
      }
      if (r.selection === 0) {
          custom(player);
        player.runCommandAsync(`event entity @s gokul`);
      }
      if (r.selection === 1) {
          custom(player);
        player.runCommandAsync(`event entity @s gokubl`);
      }
      if (r.selection === 2) {
          custom(player);
        player.runCommandAsync(`event entity @s gohanl`);
      }
      if (r.selection === 3) {
          custom(player);
        player.runCommandAsync(`event entity @s trunksl`);
      }
      if (r.selection === 4) {
          custom(player);
        player.runCommandAsync(`event entity @s strongl`);
      }
      if (r.selection === 5) {
          custom(player);
        player.runCommandAsync(`event entity @s vegetal`);
      }
      if (r.selection === 6) {
          custom(player);
        player.runCommandAsync(`event entity @s bgokul`);
      }
      if (r.selection === 7) {
          custom(player);
        player.runCommandAsync(`event entity @s ktrunksl`);
      }
      if (r.selection === 8) {
          custom(player);
        player.runCommandAsync(`event entity @s gotenl`);
      }
      if (r.selection === 9) {
          custom(player);
        player.runCommandAsync(`event entity @s rypl`);
      }
      if (r.selection === 10) {
          custom(player);
        player.runCommandAsync(`event entity @s leg.no`);
        
      }
    })
}
function camisafiza(player) {
  const data = new ui.ActionFormData()
    .title("camisa")
    .body("")
    .button("goku", "textures/custom/camisa/ui.0")
    .button("goku black", "textures/custom/camisa/ui.1")
    .button("gohan", "textures/custom/camisa/ui.2")
    .button("trunks", "textures/custom/camisa/ui.3")
    .button("metadinha", "textures/custom/camisa/ui.4")
    .button("vegeta", "textures/custom/camisa/ui.5")
    .button("vegeta (buu)", "textures/custom/camisa/mvegeta")
    .button("goku (Black)", "textures/custom/camisa/bgoku")
    .button("trunks (Future)", "textures/custom/camisa/mtrunks")
    .button("trunks (kid)", "textures/custom/camisa/ktrunks")
    .button("goten", "textures/custom/camisa/goten")
    .button("ryp", "textures/custom/camisa/ryp")
    .button("nobody", "textures/custom/hair/ui.5")
    
    .show(player).then((r) => {
      switch (r.selection) {
      }
      if (r.selection === 0) {
          customfiza(player);
        player.runCommandAsync(`event entity @s goku`);
      }
      if (r.selection === 1) {
          customfiza(player);
        player.runCommandAsync(`event entity @s gokub`);
      }
      if (r.selection === 2) {
          customfiza(player);
        player.runCommandAsync(`event entity @s gohan`);
      }
      if (r.selection === 3) {
          customfiza(player);
        player.runCommandAsync(`event entity @s trunks`);
      }
      if (r.selection === 4) {
          customfiza(player);
        player.runCommandAsync(`event entity @s strong`);
      }
      if (r.selection === 5) {
          customfiza(player);
        player.runCommandAsync(`event entity @s vegeta`);
      }
      if (r.selection === 6) {
          customfiza(player);
        player.runCommandAsync(`event entity @s mvegeta`);
      }
      if (r.selection === 7) {
          customfiza(player);
        player.runCommandAsync(`event entity @s bgoku`);
      }
      if (r.selection === 8) {
          customfiza(player);
        player.runCommandAsync(`event entity @s mtrunks`);
      }
      if (r.selection === 9) {
          customfiza(player);
        player.runCommandAsync(`event entity @s ktrunks`);
      }
      if (r.selection === 10) {
          customfiza(player);
        player.runCommandAsync(`event entity @s goten`);
      }
      if (r.selection === 11) {
          customfiza(player);
        player.runCommandAsync(`event entity @s ryp`);
      }
      if (r.selection === 12) {
          customfiza(player);
        player.runCommandAsync(`event entity @s body.no`);
        
      }
    })
}
function calcafiza(player) {
  const data = new ui.ActionFormData()
    .title("calca")
    .body("")
    .button("goku", "textures/custom/calca/ui.0")
    .button("goku black", "textures/custom/calca/ui.1")
    .button("gohan", "textures/custom/calca/ui.2")
    .button("trunks", "textures/custom/calca/ui.3")
    .button("metadinha", "textures/custom/calca/ui.4")
    .button("vegeta", "textures/custom/calca/ui.5")
    .button("goku (black)", "textures/custom/calca/bgokul")
    .button("trunks (kid)", "textures/custom/calca/ktrunksl")
    .button("goten", "textures/custom/calca/gotenl")
    .button("ryp", "textures/custom/calca/rypl")
    .button("nolegs", "textures/custom/hair/ui.5")
    .show(player).then((r) => {
      switch (r.selection) {
      }
      if (r.selection === 0) {
          customfiza(player);
        player.runCommandAsync(`event entity @s gokul`);
      }
      if (r.selection === 1) {
          customfiza(player);
        player.runCommandAsync(`event entity @s gokubl`);
      }
      if (r.selection === 2) {
          customfiza(player);
        player.runCommandAsync(`event entity @s gohanl`);
      }
      if (r.selection === 3) {
          customfiza(player);
        player.runCommandAsync(`event entity @s trunksl`);
      }
      if (r.selection === 4) {
          customfiza(player);
        player.runCommandAsync(`event entity @s strongl`);
      }
      if (r.selection === 5) {
          customfiza(player);
        player.runCommandAsync(`event entity @s vegetal`);
      }
      if (r.selection === 6) {
          customfiza(player);
        player.runCommandAsync(`event entity @s bgokul`);
      }
      if (r.selection === 7) {
          customfiza(player);
        player.runCommandAsync(`event entity @s ktrunksl`);
      }
      if (r.selection === 8) {
          customfiza(player);
        player.runCommandAsync(`event entity @s gotenl`);
      }
      if (r.selection === 9) {
          customfiza(player);
        player.runCommandAsync(`event entity @s rypl`);
      }
      if (r.selection === 10) {
          customfiza(player);
        player.runCommandAsync(`event entity @s leg.no`);
        
      }
    })
}
function camisanamek(player) {
  const data = new ui.ActionFormData()
    .title("camisa")
    .body("")
    .button("goku", "textures/custom/camisa/ui.0")
    .button("goku black", "textures/custom/camisa/ui.1")
    .button("gohan", "textures/custom/camisa/ui.2")
    .button("trunks", "textures/custom/camisa/ui.3")
    .button("metadinha", "textures/custom/camisa/ui.4")
    .button("vegeta", "textures/custom/camisa/ui.5")
    .button("vegeta (buu)", "textures/custom/camisa/mvegeta")
    .button("goku (Black)", "textures/custom/camisa/bgoku")
    .button("trunks (Future)", "textures/custom/camisa/mtrunks")
    .button("trunks (kid)", "textures/custom/camisa/ktrunks")
    .button("goten", "textures/custom/camisa/goten")
    .button("ryp", "textures/custom/camisa/ryp")
    .button("nobody", "textures/custom/hair/ui.5")
    
    .show(player).then((r) => {
      switch (r.selection) {
      }
      if (r.selection === 0) {
          customnamek(player);
        player.runCommandAsync(`event entity @s goku`);
      }
      if (r.selection === 1) {
          customnamek(player);
        player.runCommandAsync(`event entity @s gokub`);
      }
      if (r.selection === 2) {
          customnamek(player);
        player.runCommandAsync(`event entity @s gohan`);
      }
      if (r.selection === 3) {
          customnamek(player);
        player.runCommandAsync(`event entity @s trunks`);
      }
      if (r.selection === 4) {
          customnamek(player);
        player.runCommandAsync(`event entity @s strong`);
      }
      if (r.selection === 5) {
          customnamek(player);
        player.runCommandAsync(`event entity @s vegeta`);
      }
      if (r.selection === 6) {
          customnamek(player);
        player.runCommandAsync(`event entity @s mvegeta`);
      }
      if (r.selection === 7) {
          customnamek(player);
        player.runCommandAsync(`event entity @s bgoku`);
      }
      if (r.selection === 8) {
          customnamek(player);
        player.runCommandAsync(`event entity @s mtrunks`);
      }
      if (r.selection === 9) {
          customnamek(player);
        player.runCommandAsync(`event entity @s ktrunks`);
      }
      if (r.selection === 10) {
          customnamek(player);
        player.runCommandAsync(`event entity @s goten`);
      }
      if (r.selection === 11) {
          customnamek(player);
        player.runCommandAsync(`event entity @s ryp`);
      }
      if (r.selection === 12) {
          customnamek(player);
        player.runCommandAsync(`event entity @s body.no`);
        
      }
    })
}
function calcanamek(player) {
  const data = new ui.ActionFormData()
    .title("calca")
    .body("")
    .button("goku", "textures/custom/calca/ui.0")
    .button("goku black", "textures/custom/calca/ui.1")
    .button("gohan", "textures/custom/calca/ui.2")
    .button("trunks", "textures/custom/calca/ui.3")
    .button("metadinha", "textures/custom/calca/ui.4")
    .button("vegeta", "textures/custom/calca/ui.5")
    .button("goku (black)", "textures/custom/calca/bgokul")
    .button("trunks (kid)", "textures/custom/calca/ktrunksl")
    .button("goten", "textures/custom/calca/gotenl")
    .button("ryp", "textures/custom/calca/rypl")
    .button("nolegs", "textures/custom/hair/ui.5")
    .show(player).then((r) => {
      switch (r.selection) {
      }
      if (r.selection === 0) {
          customnamek(player);
        player.runCommandAsync(`event entity @s gokul`);
      }
      if (r.selection === 1) {
          customnamek(player);
        player.runCommandAsync(`event entity @s gokubl`);
      }
      if (r.selection === 2) {
          customnamek(player);
        player.runCommandAsync(`event entity @s gohanl`);
      }
      if (r.selection === 3) {
          customnamek(player);
        player.runCommandAsync(`event entity @s trunksl`);
      }
      if (r.selection === 4) {
          customnamek(player);
        player.runCommandAsync(`event entity @s strongl`);
      }
      if (r.selection === 5) {
          customnamek(player);
        player.runCommandAsync(`event entity @s vegetal`);
      }
      if (r.selection === 6) {
          customnamek(player);
        player.runCommandAsync(`event entity @s bgokul`);
      }
      if (r.selection === 7) {
          customnamek(player);
        player.runCommandAsync(`event entity @s ktrunksl`);
      }
      if (r.selection === 8) {
          customnamek(player);
        player.runCommandAsync(`event entity @s gotenl`);
      }
      if (r.selection === 9) {
          customnamek(player);
        player.runCommandAsync(`event entity @s rypl`);
      }
      if (r.selection === 10) {
          customnamek(player);
        player.runCommandAsync(`event entity @s leg.no`);
        
      }
    })
}