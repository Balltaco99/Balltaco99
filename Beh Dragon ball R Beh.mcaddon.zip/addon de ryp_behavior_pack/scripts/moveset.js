import * as mc from "@minecraft/server";

mc.system.runInterval(() => {
  for (const player of mc.world.getPlayers()) {
    moveset(player);
  }
}, 1);

async function moveset(player) {
  if (player.typeId === 'minecraft:player') {
    if (player.isOnGround && player.hasTag("dash")) {
      player.applyKnockback(player.getVelocity().x, player.getVelocity().z, 10, 0);
      await player.runCommandAsync("tag @s remove dash");
    } else if (!player.isOnGround && player.hasTag("dash") && !player.hasTag("kick_slam")) {
      player.applyKnockback(player.getVelocity().x, player.getVelocity().z, 3.4, 0);
      await player.runCommandAsync("tag @s remove dash");
    }
  }
}