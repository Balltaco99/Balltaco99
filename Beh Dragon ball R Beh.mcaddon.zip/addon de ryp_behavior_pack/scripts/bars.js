import * as mc from "@minecraft/server"
import * as hash from "./hash.js";

//title and subtitle
mc.system.runInterval(() => {
  for (const player of mc.world.getPlayers()) {
    player.onScreenDisplay.setTitle(
      "STM" + hash.getScore(player, "stm2") +
      "\n" +
      "XP" + hash.getScore(player, "xp2") +
      "\n" +
      "HP" + hash.getScore(player, "hh")
    );
  }
},1)

mc.system.runInterval(() => {
  for (const player of mc.world.getPlayers()) {
    if (hash.getScore(player, "stm") > hash.getScore(player, "stmax")) {
      player.runCommandAsync(`scoreboard players set @s stm` + " " + hash.getScore(player, "stmax"))
    }
    
    if (hash.getScore(player, "stm") < hash.getScore(player, "stmax")) {
      player.runCommandAsync(`scoreboard players add @s stm 0`)
    }
  }
},1)
