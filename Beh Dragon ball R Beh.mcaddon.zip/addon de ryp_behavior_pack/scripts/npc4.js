import * as mc from "@minecraft/server";
import * as ui from "@minecraft/server-ui";
import * as hs from "./hash.js";

mc.world.afterEvents.entityHitEntity.subscribe((data) => {
    const player = data.damagingEntity;
    const hitEntity = data.hitEntity;
    if (player && hitEntity && hitEntity.typeId === "stk:gokunpc") {
        menu(player);
    }
});

function menu(player) {
  const data = new ui.ActionFormData()
    .title("menu")
    .body("")
    .button("shop", "textures/custom/npc/shop")
    .button("techniques", "textures/custom/npc/tech")
    .show(player).then((r) => {
      switch (r.selection) {
      }
      if (r.selection === 0) {
        shop(player);
      }
      if (r.selection === 1) {
        technpc(player);
      }
    })
}
        function shop(player) {
  const data = new ui.ActionFormData()
    .title("menu")
    .body("")
    .button("remove tail", "textures/custom/tech/b")
    .show(player).then((r) => {
      switch (r.selection) {
      }
      if (r.selection === 0) {
        player.runCommandAsync(`event entity @p saiyanoff`);
      }
    })
}
function technpc(player) {
  const data = new ui.ActionFormData()
    .title("menu")
    .body("")
    .button("kiblast \nzeni: 100", "textures/items/kiblast")
    .button("Kamehameha \nzeni: 5000", "textures/items/kame")
    .button("Goku fighting style \nzeni: 15000", "textures/items/gokuf")
    .button("kienzan \nzeni: 500", "textures/items/kienzan")
    .button("Genki dama \nzeni: 70000", "textures/items/blue")
    .button("Vegetto fighting style \nzeni: 15000", "textures/items/vegettof")
    .button("Kaioken \nzeni: 10000", "textures/items/kaioken")
    .show(player).then((r) => {
      switch (r.selection) {
      }
      if (r.selection === 0) {
        player.runCommandAsync(`give @p[scores={zeni=100..}] stnk:kiblast`);
      }
      if (r.selection === 0) {
        player.runCommandAsync(`scoreboard players remove @p[scores={zeni=100..}] zeni 100`);
      }
      if (r.selection === 1) {
        player.runCommandAsync(`give @p[scores={zeni=5000..}] stk:kame`);
      }
      if (r.selection === 1) {
        player.runCommandAsync(`scoreboard players remove @p[scores={zeni=5000..}] zeni 5000`);
      }
      if (r.selection === 2) {
        player.runCommandAsync(`give @p[scores={zeni=15000..}] stk:gokuf`);
      }
      if (r.selection === 2) {
        player.runCommandAsync(`scoreboard players remove @p[scores={zeni=15000..}] zeni 15000`);
      }
      if (r.selection === 3) {
        player.runCommandAsync(`give @p[scores={zeni=500..}] stk:kienzan`);
      }
      if (r.selection === 3) {
        player.runCommandAsync(`scoreboard players remove @p[scores={zeni=500..}] zeni 500`);
      }
      if (r.selection === 4) {
        player.runCommandAsync(`give @p[scores={zeni=70000..}] stk:gdama`);
      }
      if (r.selection === 4) {
        player.runCommandAsync(`scoreboard players remove @p[scores={zeni=70000..}] zeni 70000`);
      }
      if (r.selection === 5) {
        player.runCommandAsync(`give @p[scores={zeni=15000..}] stk:vegettof`);
      }
      if (r.selection === 5) {
        player.runCommandAsync(`scoreboard players remove @p[scores={zeni=15000..}] zeni 15000`);
      }
      if (r.selection === 6) {
        player.runCommandAsync(`tag @p[scores={zeni=10000..}] add kaioun`);
      }
      if (r.selection === 6) {
        player.runCommandAsync(`scoreboard players remove @p[scores={zeni=10000..}] zeni 10000`);
      }
    })
}