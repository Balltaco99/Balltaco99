import * as mc from "@minecraft/server";
import * as ui from "@minecraft/server-ui";
import * as hs from "./hash.js";

mc.world.afterEvents.itemUse.subscribe((data) => {
  const player = data.source;
  if (player && data.itemStack.typeId?.toLowerCase() === "stk:menu3")
    menu(player);
});

function menu(player) {
  const data = new ui.ActionFormData()
    .title("menu")
    .body("")
    .button("capsules", "textures/custom/capsule/caps")
    .button("techniques", "textures/custom/tech/kaioken")
    .button("shirt", "textures/custom/camisa/uii.2")
    .button("pants", "textures/custom/calca/uii.2")
    .show(player).then((r) => {
      switch (r.selection) {
      }
      if (r.selection === 0) {
        caps(player);
      }
      if (r.selection === 1) {
        tech(player);
      }
      if (r.selection === 2) {
        camisa(player);
      }
      if (r.selection === 3) {
        calca(player);
      }
    })
}
function caps(player, btns) {
  const data = new ui.ActionFormData()
    .title("caps")
    .body("")
    .button("life1", "textures/custom/capsule/life1")
    .button("life2", "textures/custom/capsule/life2")
    .button("life3", "textures/custom/capsule/life3")
    .show(player).then((r) => {
      switch (r.selection) {
      }
      if (r.selection === 0) {
        player.runCommandAsync(`function life1`);
      }
      if (r.selection === 1) {
        player.runCommandAsync(`function life2`);
      }
      if (r.selection === 2) {
        player.runCommandAsync(`function life3`);
      }
    })
}
function tech(player, btns) {
  const data = new ui.ActionFormData()
    .title("tech")
    .body("")
    .button("kaioken", "textures/custom/tech/kaioken")
    .button("majin", "textures/custom/tech/majin")
    .button("deactive", "textures/custom/tech/b")
    .show(player).then((r) => {
      switch (r.selection) {
      }
      if (r.selection === 0) {
        player.runCommandAsync(`event entity @s[tag=kaioun] kaiot`);
      }
      if (r.selection === 1) {
        player.runCommandAsync(`event entity @s majin`);
      }
      if (r.selection === 2) {
        player.runCommandAsync(`function teno`);
      }
    })
}
function camisa(player) {
  const data = new ui.ActionFormData()
    .title("camisa")
    .body("")
    .button("goku", "textures/custom/camisa/ui.0")
    .button("goku black", "textures/custom/camisa/ui.1")
    .button("gohan", "textures/custom/camisa/ui.2")
    .button("trunks", "textures/custom/camisa/ui.3")
    .button("metadinha", "textures/custom/camisa/ui.4")
    .button("vegeta", "textures/custom/camisa/ui.5")
    .button("vegeta (buu)", "textures/custom/camisa/mvegeta")
    .button("goku (Black)", "textures/custom/camisa/bgoku")
    .button("trunks (Future)", "textures/custom/camisa/mtrunks")
    .button("trunks (kid)", "textures/custom/camisa/ktrunks")
    .button("goten", "textures/custom/camisa/goten")
    .button("ryp", "textures/custom/camisa/ryp")
    .button("nobody", "textures/custom/hair/ui.5")
    
    .show(player).then((r) => {
      switch (r.selection) {
      }
      if (r.selection === 0) {
          menu(player);
        player.runCommandAsync(`event entity @s goku`);
      }
      if (r.selection === 1) {
          menu(player);
        player.runCommandAsync(`event entity @s gokub`);
      }
      if (r.selection === 2) {
          menu(player);
        player.runCommandAsync(`event entity @s gohan`);
      }
      if (r.selection === 3) {
          menu(player);
        player.runCommandAsync(`event entity @s trunks`);
      }
      if (r.selection === 4) {
          menu(player);
        player.runCommandAsync(`event entity @s strong`);
      }
      if (r.selection === 5) {
          menu(player);
        player.runCommandAsync(`event entity @s vegeta`);
      }
      if (r.selection === 6) {
          menu(player);
        player.runCommandAsync(`event entity @s mvegeta`);
      }
      if (r.selection === 7) {
          menu(player);
        player.runCommandAsync(`event entity @s bgoku`);
      }
      if (r.selection === 8) {
          menu(player);
        player.runCommandAsync(`event entity @s mtrunks`);
      }
      if (r.selection === 9) {
          menu(player);
        player.runCommandAsync(`event entity @s ktrunks`);
      }
      if (r.selection === 10) {
          menu(player);
        player.runCommandAsync(`event entity @s goten`);
      }
      if (r.selection === 11) {
          menu(player);
        player.runCommandAsync(`event entity @s ryp`);
      }
      if (r.selection === 12) {
          menu(player);
        player.runCommandAsync(`event entity @s body.no`);
        
      }
    })
}
function calca(player) {
  const data = new ui.ActionFormData()
    .title("calca")
    .body("")
    .button("goku", "textures/custom/calca/ui.0")
    .button("goku black", "textures/custom/calca/ui.1")
    .button("gohan", "textures/custom/calca/ui.2")
    .button("trunks", "textures/custom/calca/ui.3")
    .button("metadinha", "textures/custom/calca/ui.4")
    .button("vegeta", "textures/custom/calca/ui.5")
    .button("goku (black)", "textures/custom/calca/bgokul")
    .button("trunks (kid)", "textures/custom/calca/ktrunksl")
    .button("goten", "textures/custom/calca/gotenl")
    .button("ryp", "textures/custom/calca/rypl")
    .button("nolegs", "textures/custom/hair/ui.5")
    .show(player).then((r) => {
      switch (r.selection) {
      }
      if (r.selection === 0) {
          menu(player);
        player.runCommandAsync(`event entity @s gokul`);
      }
      if (r.selection === 1) {
          menu(player);
        player.runCommandAsync(`event entity @s gokubl`);
      }
      if (r.selection === 2) {
          menu(player);
        player.runCommandAsync(`event entity @s gohanl`);
      }
      if (r.selection === 3) {
          menu(player);
        player.runCommandAsync(`event entity @s trunksl`);
      }
      if (r.selection === 4) {
          menu(player);
        player.runCommandAsync(`event entity @s strongl`);
      }
      if (r.selection === 5) {
          menu(player);
        player.runCommandAsync(`event entity @s vegetal`);
      }
      if (r.selection === 6) {
          menu(player);
        player.runCommandAsync(`event entity @s bgokul`);
      }
      if (r.selection === 7) {
          menu(player);
        player.runCommandAsync(`event entity @s ktrunksl`);
      }
      if (r.selection === 8) {
          menu(player);
        player.runCommandAsync(`event entity @s gotenl`);
      }
      if (r.selection === 9) {
          menu(player);
        player.runCommandAsync(`event entity @s rypl`);
      }
      if (r.selection === 10) {
          menu(player);
        player.runCommandAsync(`event entity @s leg.no`);
        
      }
    })
}