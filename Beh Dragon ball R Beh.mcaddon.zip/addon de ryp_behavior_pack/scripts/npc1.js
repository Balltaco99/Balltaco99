import * as mc from "@minecraft/server";
import * as ui from "@minecraft/server-ui";
import * as hs from "./hash.js";

mc.world.afterEvents.entityHitEntity.subscribe((data) => {
    const player = data.damagingEntity;
    const hitEntity = data.hitEntity;
    if (player && hitEntity && hitEntity.typeId === "stk:piccolo") {
        menu(player);
    }
});

function menu(player) {
  const data = new ui.ActionFormData()
    .title("menu")
    .body("")
    .button("techniques", "textures/custom/npc/tech")
    .show(player).then((r) => {
      switch (r.selection) {
      }
      if (r.selection === 0) {
        technpc(player);
      }
    })
}
function technpc(player) {
  const data = new ui.ActionFormData()
    .title("menu")
    .body("")
    .button("kiblast \nzeni: 100", "textures/items/kiblast")
    .button("meditation \nzeni: 300", "textures/items/meditation")
    .show(player).then((r) => {
      switch (r.selection) {
      }
      if (r.selection === 0) {
        player.runCommandAsync(`give @p[scores={zeni=100..}] stnk:kiblast`);
      }
      if (r.selection === 0) {
        player.runCommandAsync(`scoreboard players remove @p[scores={zeni=100..}] zeni 100`);
      }
      if (r.selection === 1) {
        player.runCommandAsync(`give @p[scores={zeni=300..}] stnk:meditation`);
      }
      if (r.selection === 1) {
        player.runCommandAsync(`scoreboard players remove @p[scores={zeni=300..}] zeni 300`);
      }
    })
}