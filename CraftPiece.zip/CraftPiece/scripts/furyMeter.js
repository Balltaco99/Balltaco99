import {
    world,
    system
} from '@minecraft/server';
import {
    getScore
} from './getScore';


system.runInterval(() => {
    for (const player of world.getPlayers()) {
    if (player.hasTag(`doku`)) {
      player.runCommandAsync(`scoreboard players add @s[scores={fury_meter=..999},tag=!transformed] fury_meter 5`);
      player.runCommandAsync(`scoreboard players remove @s[tag=transformed] fury_meter 5`);
    };
}}, 12);


system.runInterval(() => {
    for (const player of world.getPlayers()) {
        
    if (player.hasTag(`doku`)) {
     fury(player);
     player.runCommandAsync(`scoreboard players set @s[scores={fury_meter=1000..}] fury_meter 1000`);
    if (getScore(player, "fury_meter") < 10) {
     player.runCommandAsync(`execute @s[tag=!h] ~~~ function vremove`);
     player.runCommandAsync(`event entity @e[type=stk:venomt,r=2] despawn`);
     player.addTag(`h`);
        }
    } else 
        {
            nofury(player);
        }
        }}, 4);

function fury(player) {
    const fury_meter = getScore(player, "fury_meter"),
    fury_meter_max = getScore(player, "fury_meter_max");
    player.onScreenDisplay.setTitle(`[FuryMeter:${Math.round(fury_meter * 100 / fury_meter_max)}] [FuryMeterActive]`);
};
function nofury(player) {
 player.onScreenDisplay.setTitle(` `);
};