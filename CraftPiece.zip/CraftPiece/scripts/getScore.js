import {
	system,
	world
} from "@minecraft/server";
export function getScore(target, objective) {
	try {
		return world.scoreboard.getObjective(objective).getScore(target.scoreboard);
	} catch (error) {
		return 0;
	}
};