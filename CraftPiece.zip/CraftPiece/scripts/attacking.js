import {
    world
} from "@minecraft/server";

world.events.entityHurt.subscribe(data => {
    if (data.hurtEntity === undefined || data.damageSource.damagingEntity === undefined) {
        return;
    }
    if (data.damageSource.damagingEntity.typeId == "minecraft:player") {
        data.damageSource.damagingEntity.runCommandAsync(`scoreboard players add @s hitcounter ${data.damage}`);
        data.damageSource.damagingEntity.runCommandAsync("scoreboard players set @s hitcounter_time 15");
    };
});