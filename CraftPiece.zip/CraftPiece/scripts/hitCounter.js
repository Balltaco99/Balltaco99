import {
	world,
	system
} from "@minecraft/server";
import {
	getScore
} from "./getScore";


system.runInterval(() => {
    for (const player of world.getPlayers()) {
        if (getScore(player, "hitcounter_time") > 0) {
            titles(player);
        }
}});

function titles(player) {
    const hitcounter = getScore(player, "hitcounter") > 0 && getScore(player, "hitcounter") < 9 ? `§f${Math.round(getScore(player, "hitcounter"))}` : getScore(player, "hitcounter") > 9 && getScore(player, "hitcounter") < 19 ? `§a${Math.round(getScore(player, "hitcounter"))}` : getScore(player, "hitcounter") > 19 && getScore(player, "hitcounter") < 39 ? `§e${Math.round(getScore(player, "hitcounter"))}` : getScore(player, "hitcounter") > 39 && getScore(player, "hitcounter") < 69 ? `§4${Math.round(getScore(player, "hitcounter"))}` : getScore(player, "hitcounter") > 69 ? `§d${Math.round(getScore(player, "hitcounter"))}` : "";
		player.onScreenDisplay.updateSubtitle(`${hitcounter}`);
}
system.runInterval(() => {
    for (const player of world.getPlayers()) {
            player.runCommandAsync(`scoreboard players remove @s hitcounter_time 1`);
            player.runCommandAsync(`scoreboard players set @s[scores={hitcounter_time=..0}] hitcounter 0`);
}}, 5);
